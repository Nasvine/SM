package com.example.smart_service

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
