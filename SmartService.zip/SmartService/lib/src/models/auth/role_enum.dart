
import 'package:flutter/material.dart';

class RoleEnum{
  static const String Role_1 = "Super Admin";
  static const String Role_2 = "Admin";
  static const String Role_3 = "Client";
  static const String Role_4 = "Deliver";
}