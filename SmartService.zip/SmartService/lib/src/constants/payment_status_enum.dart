


 import 'package:flutter/material.dart';

class PaymentStatusEnum{
  static const String Pending = "Pending";
  static const String Success = "Success";
  static const String Finish = "Finish";
}