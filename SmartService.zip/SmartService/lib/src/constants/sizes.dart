// App default Sizing

const tDefaultSize = 30.0;
const tButtonHeight = 15.0;
const tFormHeight = 30.0;