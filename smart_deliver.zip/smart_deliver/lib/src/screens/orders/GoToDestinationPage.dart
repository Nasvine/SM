import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:location/location.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/models/order_model.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';

class GoToDestinationPage extends StatefulWidget {
  final OrderModel order;
  final String googleApiKey;

  const GoToDestinationPage({
    Key? key,
    required this.order,
    required this.googleApiKey,
  }) : super(key: key);

  @override
  State<GoToDestinationPage> createState() => _GoToDestinationPageState();
}

class _GoToDestinationPageState extends State<GoToDestinationPage> {
  GoogleMapController? _mapController;
  Location _location = Location();
  StreamSubscription<LocationData>? _locationSub;

  LatLng? _currentPos;
  List<LatLng> _polylineCoords = [];
  Set<Polyline> _polylines = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _initTracking();
  }

  Future<void> _initTracking() async {
    setState(() => _isLoading = true);
    // Vérifier permissions
    final perm = await _location.requestPermission();
    if (perm != PermissionStatus.granted) return;

    final service = await _location.requestService();
    if (!service) return;

    // Ecoute en temps réel
    _locationSub = _location.onLocationChanged.listen((loc) async {
      final newPos = LatLng(loc.latitude!, loc.longitude!);

      setState(() {
        _currentPos = newPos;
        _isLoading = false;
      });
      _updatePolyline();

      // 🔴 Nouvelle partie : push Firestore en continu
      final deliverLocation = PlaceLocation(
        latitude: newPos.latitude,
        longitude: newPos.longitude,
        address: "Position actuelle du livreur",
      );

      await FirebaseFirestore.instance
          .collection("orders")
          .doc(widget.order.uid)
          .update({"deliverLocation": deliverLocation.toMap()});
    });
  }

  Future<void> _updatePolyline() async {
    if (_currentPos == null) return;
    final start = PointLatLng(_currentPos!.latitude, _currentPos!.longitude);
    final end = PointLatLng(
      widget.order.destinationLocation.latitude,
      widget.order.destinationLocation.longitude,
    );

    final result = await PolylinePoints().getRouteBetweenCoordinates(
      googleApiKey: widget.googleApiKey,
      request: PolylineRequest(
        origin: start,
        destination: end,
        mode: TravelMode.driving,
      ),
    );

    if (result.points.isNotEmpty) {
      setState(() {
        _polylineCoords = result.points
            .map((p) => LatLng(p.latitude, p.longitude))
            .toList();
        _polylines = {
          Polyline(
            polylineId: const PolylineId("route"),
            color: Colors.red,
            width: 4,
            points: _polylineCoords,
          ),
        };
      });
    }
  }

  Future<void> _confirmArrival() async {
    if (_currentPos == null) return;

    final deliverLocation = PlaceLocation(
      latitude: _currentPos!.latitude,
      longitude: _currentPos!.longitude,
      address: "Position actuelle du livreur",
    );

    await FirebaseFirestore.instance
        .collection("orders")
        .doc(widget.order.uid)
        .update({
          "deliverLocation": deliverLocation.toMap(),
          "status": "pending", // ou confirmed
          "startTime": Timestamp.now(),
        });

    Navigator.pop(context); // ou redirection vers Page 2
  }

  @override
  void dispose() {
    _locationSub?.cancel();
    _mapController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final withdrawalLatLng = LatLng(
      widget.order.destinationLocation.latitude,
      widget.order.destinationLocation.longitude,
    );

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: Icon(
            LineAwesomeIcons.angle_left_solid,
            color: THelperFunctions.isDarkMode(context)
                ? ColorApp.tWhiteColor
                : ColorApp.tBlackColor,
          ),
        ),
        centerTitle: true,
        title: const Text("Aller au point de destination"),
      ),
      body: Stack(
        children: [
          if (_isLoading) const Center(child: CircularProgressIndicator()),
          if (!_isLoading)
            GoogleMap(
              initialCameraPosition: CameraPosition(
                target: withdrawalLatLng,
                zoom: 14,
              ),
              onMapCreated: (c) => _mapController = c,
              markers: {
                if (_currentPos != null)
                  Marker(
                    markerId: const MarkerId("me"),
                    position: _currentPos!,
                    infoWindow: InfoWindow(title: "Ma Position actuelle"),
                  ),
                Marker(
                  markerId: const MarkerId("withdrawal"),
                  position: withdrawalLatLng,
                  infoWindow: InfoWindow(title: "Point de destination"),
                ),
              },
              polylines: _polylines,
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
            ),
          /* Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: ElevatedButton(
              onPressed: _confirmArrival,
              child: const Text("Confirmer réception"),
            ),
          ), */
        ],
      ),
    );
  }
}
