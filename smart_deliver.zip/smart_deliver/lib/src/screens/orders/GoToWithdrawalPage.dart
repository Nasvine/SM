import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:location/location.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:smart_deliver/notification_services.dart';
import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/models/auth/notification_model.dart';
import 'package:smart_deliver/src/models/auth/user_model.dart';
import 'package:smart_deliver/src/models/order_model.dart';
import 'package:smart_deliver/src/screens/tabs.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';
import 'package:smart_deliver/src/utils/texts/text_form_field_simple_custom.dart';
import 'package:smart_deliver/src/utils/validators/validator.dart';

class GoToWithdrawalPage extends StatefulWidget {
  final OrderModel order;
  final String googleApiKey;

  const GoToWithdrawalPage({
    Key? key,
    required this.order,
    required this.googleApiKey,
  }) : super(key: key);

  @override
  State<GoToWithdrawalPage> createState() => _GoToWithdrawalPageState();
}

class _GoToWithdrawalPageState extends State<GoToWithdrawalPage> {
  final firebase = FirebaseFirestore.instance;
  GoogleMapController? _mapController;
  final Location _location = Location();
  StreamSubscription<LocationData>? _locationSub;
  final purchaseAmount = TextEditingController();
  OrderModel orderData = OrderModel.empty();
  UserModel clientInfo = UserModel.empty();

  LatLng? _currentPos;
  List<LatLng> _polylineCoords = [];
  Set<Polyline> _polylines = {};
  bool _isLoading = true;
  bool _isLoadingTwo = false;
  bool _hasPolylineError = false;
  String _polylineError = '';

  // Configuration pour les requêtes de polyligne
  static const int _maxRetries = 3;
  static const Duration _retryDelay = Duration(seconds: 2);
  int _currentRetry = 0;

  @override
  void initState() {
    super.initState();
    _initTracking();
    _fetchOrderDetails();
    _getClientInfo();
  }

  void _fetchOrderDetails() async {
    final data = await firebase
        .collection('orders')
        .doc(widget.order.uid)
        .get();

    if (data.exists) {
      final order = OrderModel.fromSnapshot(data);
      setState(() {
        orderData = order;
      });
    }
  }

  void _getClientInfo() async {
    final data = await firebase
        .collection("users")
        .doc(widget.order.userRef!.id)
        .get();
    if (data.exists) {
      final client = UserModel.fromSnapshot(data);
      setState(() {
        clientInfo = client;
      });
    }
  }

  Future<void> _initTracking() async {
    try {
      final perm = await _location.requestPermission();
      if (perm != PermissionStatus.granted) {
        _showLocationError("Permission de localisation refusée");
        return;
      }

      final service = await _location.requestService();
      if (!service) {
        _showLocationError("Service de localisation désactivé");
        return;
      }

      // Obtenir la position initiale
      final initialLocation = await _location.getLocation();
      setState(() {
        _currentPos = LatLng(initialLocation.latitude!, initialLocation.longitude!);
      });

      // Mettre à jour la polyligne initiale
      await _updatePolylineWithRetry();

      // Écoute position en temps réel
      _locationSub = _location.onLocationChanged.listen((loc) async {
        final newPos = LatLng(loc.latitude!, loc.longitude!);
        setState(() {
          _currentPos = newPos;
        });

        // Mettre à jour la polyligne périodiquement (pas à chaque update pour éviter les requêtes excessives)
        if (_currentRetry == 0) { // Seulement si pas d'erreur en cours
          await _updatePolylineWithRetry();
        }

        // Cacher le loader dès qu'on a une première position
        if (_isLoading) {
          setState(() {
            _isLoading = false;
          });
        }
      });
    } catch (e) {
      _showLocationError("Erreur d'initialisation: $e");
    }
  }

  Future<void> _updatePolylineWithRetry() async {
    for (int i = 0; i < _maxRetries; i++) {
      try {
        await _updatePolyline();
        if (mounted) {
          setState(() {
            _hasPolylineError = false;
            _polylineError = '';
            _currentRetry = 0;
          });
        }
        break; // Sortir de la boucle si réussi
      } catch (e) {
        _currentRetry = i + 1;
        if (mounted) {
          setState(() {
            _hasPolylineError = true;
            _polylineError = e.toString();
          });
        }
        
        if (i < _maxRetries - 1) {
          await Future.delayed(_retryDelay);
        } else {
          // Dernière tentative échouée
          _showPolylineError();
        }
      }
    }
  }

  Future<void> _updatePolyline() async {
    if (_currentPos == null) return;

    final start = PointLatLng(_currentPos!.latitude, _currentPos!.longitude);
    final end = PointLatLng(
      widget.order.withdrawalPoint.latitude,
      widget.order.withdrawalPoint.longitude,
    );

    // Vérifier que la clé API est valide
    if (widget.googleApiKey.isEmpty) {
      throw Exception("Clé API Google manquante");
    }

    final result = await PolylinePoints().getRouteBetweenCoordinates(
      googleApiKey: widget.googleApiKey,
      request: PolylineRequest(
        origin: start,
        destination: end,
        mode: TravelMode.driving,
      ),
    );

    if (result.points.isNotEmpty) {
      if (mounted) {
        setState(() {
          _polylineCoords = result.points
              .map((p) => LatLng(p.latitude, p.longitude))
              .toList();
          _polylines = {
            Polyline(
              polylineId: const PolylineId("route"),
              color: ColorApp.tPrimaryColor,
              width: 5,
              points: _polylineCoords,
            ),
          };
          _hasPolylineError = false;
          _polylineError = '';
        });
      }
    } else {
      throw Exception("Aucun itinéraire trouvé");
    }
  }

  void _showLocationError(String message) {
    if (mounted) {
      setState(() {
        _isLoading = false;
        _hasPolylineError = true;
        _polylineError = message;
      });
    }
  }

  void _showPolylineError() {
    Get.snackbar(
      'Information',
      'Impossible de charger l\'itinéraire. La carte fonctionne toujours.',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.orange,
      colorText: Colors.white,
      duration: const Duration(seconds: 5),
    );
  }

  Future<void> _confirmArrival() async {
    if (_currentPos == null) return;

    final deliverLocation = PlaceLocation(
      latitude: _currentPos!.latitude,
      longitude: _currentPos!.longitude,
      address: "Position actuelle du livreur",
    );

    await FirebaseFirestore.instance
        .collection("orders")
        .doc(widget.order.uid)
        .update({
          "deliverLocation": deliverLocation.toMap(),
          "status": "pending",
          "startTime": Timestamp.now(),
        });

    Navigator.pop(context);
  }

  @override
  void dispose() {
    _locationSub?.cancel();
    _mapController?.dispose();
    purchaseAmount.dispose();
    super.dispose();
  }

  void showPurchaseModal(BuildContext context) async {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Prix des achats effectués",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              Text(
                "NB: Si vous n'avez pas fait d'achats, entrez 0 dans le champs.",
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.normal,
                  color: Colors.red,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),

              TextFormFieldSimpleCustom(
                keyboardType: TextInputType.number,
                obscureText: false,
                borderRadiusBorder: 10,
                cursorColor: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tWhiteColor
                    : ColorApp.tBlackColor,
                borderSideRadiusBorder: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tsecondaryColor
                    : ColorApp.tSombreColor,
                borderRadiusFocusedBorder: 10,
                borderSideRadiusFocusedBorder:
                    THelperFunctions.isDarkMode(context)
                    ? ColorApp.tsecondaryColor
                    : ColorApp.tSombreColor,
                controller: purchaseAmount,
                labelText: 'Entrez le montant',
                labelStyleColor: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tWhiteColor
                    : ColorApp.tBlackColor,
                hintText: 'Entrez le montant',
                hintStyleColor: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tWhiteColor
                    : ColorApp.tBlackColor,
                validator: (value) =>
                    TValidator.validationEmptyText("Montant", value),
              ),
              const SizedBox(height: 10),

              // 📤 Bouton d'envoi
              SizedBox(
                width: double.infinity,
                child: _isLoadingTwo 
                    ? const CircularProgressIndicator() 
                    : ElevatedButton(
                  onPressed: () async {
                    await _handlePurchaseConfirmation();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ColorApp.tsecondaryColor,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text("Continuer"),
                ),
              ),
              SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }

  Future<void> _handlePurchaseConfirmation() async {
    setState(() {
      _isLoadingTwo = true;
    });

    try {
      if (purchaseAmount.text.isEmpty) {
        Get.snackbar(
          'Attention',
          "Veuillez entrer le montant des achats, sinon 0.",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.redAccent,
          colorText: Colors.white,
        );
        return;
      }

      final amount = double.tryParse(purchaseAmount.text.trim()) ?? 0.0;

      if (_currentPos == null) {
        Get.snackbar(
          'Erreur',
          "Position actuelle non disponible",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.redAccent,
          colorText: Colors.white,
        );
        return;
      }

      final deliverLocation = PlaceLocation(
        latitude: _currentPos!.latitude,
        longitude: _currentPos!.longitude,
        address: "Position actuelle du livreur",
      );

      await firebase.collection('orders').doc(widget.order.uid).update({
        'status': "pending",
        'purchasePrice': amount,
        'totalPrice': amount + orderData.amount,
        'deliverLocation': deliverLocation.toMap(),
      });

      final notification = NotificationModel(
        senderRef: FirebaseFirestore.instance
            .collection('users')
            .doc(FirebaseAuth.instance.currentUser!.uid),
        receiverRef: clientInfo.ref,
        title: 'Prise de Colis 🥗',
        message: "Le Livreur vient de prendre votre colis.",
        type: "Location",
        isRead: false,
        createdAt: Timestamp.now(),
      );

      await FirebaseFirestore.instance
          .collection('notifications')
          .add(notification.toJson());

      NotificationServices().sendPushNotification(
        deviceToken: clientInfo.fcmToken!,
        title: "Prise de Colis 🥗",
        body: "Le Livreur vient de prendre votre colis. Patientez il est en route 🙂.",
      );

      Get.snackbar(
        'Succès',
        'Colis confirmé avec succès',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );

      Get.offAll(() => TabsScreen(initialIndex: 1));
    } catch (e) {
      Get.snackbar(
        'Erreur',
        "Erreur lors de la confirmation: $e",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingTwo = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final withdrawalLatLng = LatLng(
      widget.order.withdrawalPoint.latitude,
      widget.order.withdrawalPoint.longitude,
    );

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Get.back(),
          icon: Icon(
            Icons.arrow_back_ios_new_rounded,
            color: THelperFunctions.isDarkMode(context)
                ? ColorApp.tWhiteColor
                : ColorApp.tBlackColor,
          ),
        ),
        centerTitle: true,
        title: const Text("Aller au point de retrait"),
      ),
      body: Stack(
        children: [
          // Carte Google Maps
          if (!_isLoading)
            GoogleMap(
              initialCameraPosition: CameraPosition(
                target: _currentPos ?? withdrawalLatLng,
                zoom: 14,
              ),
              onMapCreated: (c) => _mapController = c,
              markers: {
                if (_currentPos != null)
                  Marker(
                    markerId: const MarkerId("me"),
                    position: _currentPos!,
                    infoWindow: const InfoWindow(title: "Ma Position actuelle"),
                    icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
                  ),
                Marker(
                  markerId: const MarkerId("withdrawal"),
                  position: withdrawalLatLng,
                  infoWindow: const InfoWindow(title: "Point de retrait"),
                  icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
                ),
              },
              polylines: _polylines,
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
            ),

          // Indicateur de chargement
          if (_isLoading) 
            const Center(child: CircularProgressIndicator()),

          // Message d'erreur pour la polyligne
          if (_hasPolylineError && !_isLoading)
            Positioned(
              top: 20,
              left: 20,
              right: 20,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.warning_amber_rounded, color: Colors.white),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        "Itinéraire non disponible",
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      onPressed: () {
                        setState(() {
                          _hasPolylineError = false;
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),

          // Bouton de confirmation
          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: ElevatedButton(
              onPressed: _currentPos == null ? null : () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text(
                      "Confirmation",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    content: const Text(
                      "Voulez-vous vraiment confirmer la réception du colis ?",
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text("Annuler"),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text(
                          "Confirmer",
                          style: TextStyle(color: Colors.green),
                        ),
                      ),
                    ],
                  ),
                );

                if (confirm == true) {
                  showPurchaseModal(context);
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: ColorApp.tPrimaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                "Confirmer réception du colis",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}