import 'dart:math';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:smart_deliver/notification_services.dart';
import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/models/auth/notification_model.dart';
import 'package:smart_deliver/src/models/auth/user_model.dart';
import 'package:smart_deliver/src/models/order_model.dart';
import 'package:smart_deliver/src/repository/authentification_repository.dart';
import 'package:smart_deliver/src/screens/tabs.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';
import 'package:smart_deliver/src/utils/texts/button_custom.dart';
import 'package:smart_deliver/src/utils/texts/button_custom_outlined.dart';
import 'package:smart_deliver/src/utils/texts/text_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/foundation.dart';
import 'package:iconsax/iconsax.dart';

import 'dart:math';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:smart_deliver/notification_services.dart';
import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/models/auth/notification_model.dart';
import 'package:smart_deliver/src/models/auth/user_model.dart';
import 'package:smart_deliver/src/models/order_model.dart';
import 'package:smart_deliver/src/repository/authentification_repository.dart';
import 'package:smart_deliver/src/screens/tabs.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';
import 'package:smart_deliver/src/utils/texts/button_custom.dart';
import 'package:smart_deliver/src/utils/texts/button_custom_outlined.dart';
import 'package:smart_deliver/src/utils/texts/text_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/foundation.dart';
import 'package:iconsax/iconsax.dart';

class OrderDetailScreen extends StatefulWidget {
  const OrderDetailScreen({
    super.key,
    required this.startLocation,
    required this.endLocation,
    required this.userCreatedId,
    required this.orderId,
  });

  final PlaceLocation startLocation;
  final PlaceLocation endLocation;
  final String userCreatedId;
  final String orderId;

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final firebase = FirebaseFirestore.instance;
  OrderModel orderData = OrderModel.empty();
  GoogleMapController? _mapController;
  double _distanceKm = 0.0;
  UserModel clientInfo = UserModel.empty();

  @override
  void initState() {
    super.initState();
    _calculateDistance();
    _getClientInfo();
    _fetchOrderDetails();
  }

  double _calculateDistanceBetween(
    double lat1,
    double lon1,
    double lat2,
    double lon2,
  ) {
    const p = 0.017453292519943295;
    final a =
        0.5 -
        cos((lat2 - lat1) * p) / 2 +
        cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a));
  }

  void _calculateDistance() {
    _distanceKm = _calculateDistanceBetween(
      widget.startLocation.latitude,
      widget.startLocation.longitude,
      widget.endLocation.latitude,
      widget.endLocation.longitude,
    );
  }

  void _getClientInfo() async {
    final data = await firebase
        .collection("users")
        .doc(widget.userCreatedId)
        .get();
    if (data.exists) {
      final client = UserModel.fromSnapshot(data);
      setState(() {
        clientInfo = client;
      });
    }
  }

  Stream<OrderModel> fetchOrderDetails() {
    return FirebaseFirestore.instance
        .collection('orders')
        .doc(widget.orderId)
        .snapshots()
        .map((snapshot) => OrderModel.fromSnapshot(snapshot));
  }

  void _fetchOrderDetails() async {
    final data = await firebase.collection('orders').doc(widget.orderId).get();
    if (data.exists) {
      final order = OrderModel.fromSnapshot(data);
      setState(() {
        orderData = order;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = THelperFunctions.isDarkMode(context);
    final LatLng startLatLng = LatLng(
      widget.startLocation.latitude,
      widget.startLocation.longitude,
    );
    final LatLng endLatLng = LatLng(
      widget.endLocation.latitude,
      widget.endLocation.longitude,
    );

    return Scaffold(
      backgroundColor: isDark ? ColorApp.tDarkBgColor : Colors.grey[50],
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Get.back(),
          icon: Icon(
            Icons.arrow_back_ios_new_rounded,
            color: isDark ? ColorApp.tWhiteColor : ColorApp.tBlackColor,
            size: 20,
          ),
        ),
        centerTitle: true,
        title: Text(
          "Détails de la course",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: isDark ? Colors.white : Colors.black,
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      body: StreamBuilder(
        stream: fetchOrderDetails(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return _buildLoadingState();
          }

          if (!snapshot.hasData || snapshot.data == null) {
            return _buildErrorState("Course non trouvée");
          }

          final order = snapshot.data!;
          return Column(
            children: [
              // Carte
              _buildMapSection(startLatLng, endLatLng, isDark),
              
              // Détails de la course
              Expanded(
                child: _buildOrderDetails(order, isDark),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildMapSection(LatLng startLatLng, LatLng endLatLng, bool isDark) {
    return Container(
      height: 280,
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: GoogleMap(
          initialCameraPosition: CameraPosition(
            target: LatLng(
              (startLatLng.latitude + endLatLng.latitude) / 2,
              (startLatLng.longitude + endLatLng.longitude) / 2,
            ),
            zoom: 12,
          ),
          onMapCreated: (controller) => _mapController = controller,
          markers: {
            Marker(
              markerId: const MarkerId("start"),
              position: startLatLng,
              infoWindow: InfoWindow(
                title: "Point de départ",
                snippet: widget.startLocation.address,
              ),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueGreen,
              ),
            ),
            Marker(
              markerId: const MarkerId("end"),
              position: endLatLng,
              infoWindow: InfoWindow(
                title: "Destination",
                snippet: widget.endLocation.address,
              ),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueRed,
              ),
            ),
          },
          polylines: {
            Polyline(
              polylineId: const PolylineId("route"),
              color: ColorApp.tPrimaryColor,
              width: 5,
              points: [startLatLng, endLatLng],
            ),
          },
          zoomGesturesEnabled: true,
          scrollGesturesEnabled: true,
          rotateGesturesEnabled: true,
          tiltGesturesEnabled: true,
          compassEnabled: true,
          myLocationButtonEnabled: true,
          myLocationEnabled: true,
        ),
      ),
    );
  }

  Widget _buildOrderDetails(OrderModel order, bool isDark) {
    return Container(
      decoration: BoxDecoration(
        color: isDark ? Colors.grey[900] : Colors.white,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
      ),
      child: Column(
        children: [
          // En-tête des détails
          _buildDetailsHeader(order, isDark),
          
          // Liste des informations
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  _buildInfoItem(
                    icon: Iconsax.profile_2user,
                    title: "Client",
                    value: clientInfo.fullName,
                    isDark: isDark,
                  ),
                  _buildInfoItem(
                    icon: Iconsax.call,
                    title: "Téléphone",
                    value: clientInfo.phoneNumber ?? "Non renseigné",
                    isDark: isDark,
                  ),
                  _buildInfoItem(
                    icon: Iconsax.location,
                    title: "Adresse de retrait",
                    value: order.withdrawalPoint.address,
                    isDark: isDark,
                  ),
                  _buildInfoItem(
                    icon: Iconsax.location_add,
                    title: "Adresse de livraison",
                    value: order.deliverLocation.address,
                    isDark: isDark,
                  ),
                  _buildInfoItem(
                    icon: Iconsax.document_text,
                    title: "Instructions",
                    value: order.message,
                    isDark: isDark,
                    maxLines: 3,
                  ),
                  _buildInfoItem(
                    icon: Iconsax.box,
                    title: "Type de colis",
                    value: _getPackageTypeName(order.deliveryType),
                    isDark: isDark,
                  ),
                  _buildInfoItem(
                    icon: Iconsax.route_square,
                    title: "Distance",
                    value: "${order.distance.toStringAsFixed(2)} Km",
                    isDark: isDark,
                  ),
                  _buildInfoItem(
                    icon: Iconsax.money,
                    title: "Prix de la course",
                    value: "${order.amount.toStringAsFixed(0)} FCFA",
                    isDark: isDark,
                    valueColor: Colors.green,
                  ),
                ],
              ),
            ),
          ),
          
          // Boutons d'action (uniquement pour les statuts appropriés)
          if (_shouldShowActionButtons(order.status))
            _buildActionButtons(order, isDark),
        ],
      ),
    );
  }

  Widget _buildDetailsHeader(OrderModel order, bool isDark) {
    // Gestion sécurisée de l'ID de commande
    final orderIdDisplay = order.orderId.length > 8 
        ? "#${order.orderId.substring(0, 8)}..."
        : "#${order.orderId}";

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: ColorApp.tPrimaryColor.withOpacity(0.1),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: ColorApp.tPrimaryColor,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Iconsax.box,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Course $orderIdDisplay",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : Colors.black,
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _getStatusColor(order.status),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    _getStatusText(order.status),
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem({
    required IconData icon,
    required String title,
    required String value,
    required bool isDark,
    int maxLines = 1,
    Color? valueColor,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: ColorApp.tPrimaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: ColorApp.tPrimaryColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: isDark ? Colors.white : Colors.black,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value.isNotEmpty ? value : "Non renseigné",
                  style: TextStyle(
                    fontSize: 14,
                    color: valueColor ?? (isDark ? Colors.grey[400] : Colors.grey[700]),
                    height: 1.4,
                  ),
                  maxLines: maxLines,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(OrderModel order, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey[800] : Colors.white,
        border: Border(
          top: BorderSide(
            color: Colors.grey.withOpacity(0.2),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () => _showDeclineConfirmation(order),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                side: BorderSide(color: Colors.red.shade400),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Iconsax.close_circle,
                    color: Colors.red.shade400,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Refuser',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.red.shade400,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton(
              onPressed: () => _showAcceptConfirmation(order),
              style: ElevatedButton.styleFrom(
                backgroundColor: ColorApp.tPrimaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Iconsax.tick_circle,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Accepter',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: ColorApp.tPrimaryColor.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: const CircularProgressIndicator(
              color: ColorApp.tPrimaryColor,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Chargement des détails...',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(String message) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Iconsax.close_circle,
              size: 50,
              color: Colors.red,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            message,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => Get.back(),
            style: ElevatedButton.styleFrom(
              backgroundColor: ColorApp.tPrimaryColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text('Retour'),
          ),
        ],
      ),
    );
  }

  void _showDeclineConfirmation(OrderModel order) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => _buildConfirmationDialog(
        title: "Refuser la course",
        content: "Êtes-vous sûr de vouloir refuser cette course ?",
        confirmText: "Refuser",
        confirmColor: Colors.red,
        icon: Iconsax.close_circle,
      ),
    );

    if (confirm == true) {
      await _declineOrder(order);
    }
  }

  void _showAcceptConfirmation(OrderModel order) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => _buildConfirmationDialog(
        title: "Accepter la course",
        content: "Êtes-vous sûr de vouloir accepter cette course ?",
        confirmText: "Accepter",
        confirmColor: ColorApp.tPrimaryColor,
        icon: Iconsax.tick_circle,
      ),
    );

    if (confirm == true) {
      await _acceptOrder(order);
    }
  }

  Widget _buildConfirmationDialog({
    required String title,
    required String content,
    required String confirmText,
    required Color confirmColor,
    required IconData icon,
  }) {
    final isDark = THelperFunctions.isDarkMode(context);
    
    return Dialog(
      backgroundColor: isDark ? Colors.grey[900] : Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: confirmColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: confirmColor,
                size: 30,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              content,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context, false),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text("Annuler"),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: confirmColor,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      confirmText,
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _declineOrder(OrderModel order) async {
    try {
      await firebase.collection('orders').doc(widget.orderId).update({
        'status': "refused",
        'deliverRef': null,
        'managerRef': null,
        'isDriverAssigned': false,
      });

      Get.snackbar(
        'Succès',
        'Course refusée avec succès',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
        borderRadius: 12,
      );

      Get.offAll(() => TabsScreen(initialIndex: 1));
    } catch (e) {
      Get.snackbar(
        'Erreur',
        'Erreur lors du refus de la course',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  Future<void> _acceptOrder(OrderModel order) async {
    try {
      await firebase.collection('orders').doc(widget.orderId).update({
        'status': "accepted"
      });

      await firebase.collection('users').doc(
        FirebaseAuth.instance.currentUser!.uid,
      ).update({'isAvailable': false});

      final notification = NotificationModel(
        senderRef: FirebaseFirestore.instance.collection('users').doc(
          FirebaseAuth.instance.currentUser!.uid,
        ),
        receiverRef: clientInfo.ref,
        title: 'Course acceptée ✅',
        message: "Votre course a été acceptée par un livreur. Livraison en cours.",
        type: "delivery",
        isRead: false,
        createdAt: Timestamp.now(),
      );

      await FirebaseFirestore.instance.collection('notifications').add(
        notification.toJson(),
      );

      NotificationServices().sendPushNotification(
        deviceToken: clientInfo.fcmToken!,
        title: "Course acceptée ✅",
        body: "Votre course a été acceptée par un livreur. Livraison en cours.",
      );

      Get.snackbar(
        'Succès',
        'Course acceptée avec succès',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
        borderRadius: 12,
      );

      Get.offAll(() => TabsScreen(initialIndex: 1));
    } catch (e) {
      Get.snackbar(
        'Erreur',
        'Erreur lors de l\'acceptation de la course',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  bool _shouldShowActionButtons(String status) {
    // Afficher les boutons uniquement pour les statuts où le livreur peut agir
    return status == "assigned" || status == "neworder";
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'neworder':
        return Colors.blue;
      case 'assigned':
        return Colors.orange;
      case 'accepted':
        return Colors.purple;
      case 'pending':
        return Colors.yellow[700]!;
      case 'delivered':
        return Colors.teal;
      case 'paymentstep':
        return Colors.indigo;
      case 'finish':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      case 'refused':
        return Colors.red[400]!;
      default:
        return Colors.grey;
    }
  }

  String _getStatusText(String status) {
    switch (status.toLowerCase()) {
      case 'neworder':
        return 'Nouvelle commande';
      case 'assigned':
        return 'Assignée';
      case 'accepted':
        return 'Acceptée';
      case 'pending':
        return 'En attente';
      case 'delivered':
        return 'Livrée';
      case 'paymentstep':
        return 'Paiement';
      case 'finish':
        return 'Terminée';
      case 'cancelled':
        return 'Annulée';
      case 'refused':
        return 'Refusée';
      default:
        return status;
    }
  }

  String _getPackageTypeName(String type) {
    switch (type.toLowerCase()) {
      case 'food':
        return 'Repas';
      case 'supermarket':
        return 'SuperMarché';
      case 'package':
        return 'Colis';
      case 'administrativecourse':
        return 'Course Administrative';
      default:
        return type;
    }
  }
}