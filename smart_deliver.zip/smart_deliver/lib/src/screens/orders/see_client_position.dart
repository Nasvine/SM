import 'dart:async';
import 'dart:math' show cos, sqrt, asin;
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:geolocator/geolocator.dart';
import 'package:smart_deliver/src/models/order_model.dart';

class SeeClientPositionScreen extends StatefulWidget {
  final PlaceLocation startLocation; // Position initiale livreur
  final PlaceLocation endLocation; // Destination
  final String googleApiKey;

  const SeeClientPositionScreen({
    super.key,
    required this.startLocation,
    required this.endLocation,
    required this.googleApiKey,
  });

  @override
  State<SeeClientPositionScreen> createState() => _SeeClientPositionScreenState();
}

class _SeeClientPositionScreenState extends State<SeeClientPositionScreen> {
  GoogleMapController? _mapController;
  StreamSubscription<Position>? _positionStream;
  Set<Marker> _markers = {};
  Map<PolylineId, Polyline> _polylines = {};
  List<LatLng> _polylineCoords = [];

  double _distanceKm = 0.0;

  @override
  void initState() {
    super.initState();
    _loadInitialRoute();
    _startListeningPosition();
  }

  @override
  void dispose() {
    _positionStream?.cancel();
    super.dispose();
  }

  // ---- Calcul distance Haversine ----
  double _calculateDistance(lat1, lon1, lat2, lon2) {
    const p = 0.017453292519943295; // PI / 180
    final c = cos;
    final a =
        0.5 -
        c((lat2 - lat1) * p) / 2 +
        c(lat1 * p) * c(lat2 * p) * (1 - c((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a)); // 2 * R * asin...
  }

  Future<void> _loadInitialRoute() async {
    final startLatLng = LatLng(
      widget.startLocation.latitude,
      widget.startLocation.longitude,
    );
    final endLatLng = LatLng(
      widget.endLocation.latitude,
      widget.endLocation.longitude,
    );

    // Charger polyline avec Google Directions API
    final polylinePoints = PolylinePoints();
    final result = await polylinePoints.getRouteBetweenCoordinates(
      request: PolylineRequest(
        origin: PointLatLng(startLatLng.latitude, startLatLng.longitude),
        destination: PointLatLng(endLatLng.latitude, endLatLng.longitude),
        mode: TravelMode.driving,
      ),
      googleApiKey: widget.googleApiKey,
    );

    if (result.points.isNotEmpty) {
      _polylineCoords = result.points
          .map((p) => LatLng(p.latitude, p.longitude))
          .toList();

      final polylineId = PolylineId('route');
      final polyline = Polyline(
        polylineId: polylineId,
        color: Colors.red,
        width: 4,
        points: _polylineCoords,
      );
      _polylines[polylineId] = polyline;
    }

    // Ajouter marker départ et arrivée
    _markers.add(
      Marker(
        markerId: const MarkerId('start'),
        position: startLatLng,
        infoWindow: InfoWindow(
          title: 'Livreur',
          snippet: widget.startLocation.address,
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      ),
    );

    _markers.add(
      Marker(
        markerId: const MarkerId('end'),
        position: endLatLng,
        infoWindow: InfoWindow(
          title: 'Client',
          snippet: widget.endLocation.address,
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
      ),
    );

    // Distance initiale
    _distanceKm = _calculateDistance(
      startLatLng.latitude,
      startLatLng.longitude,
      endLatLng.latitude,
      endLatLng.longitude,
    );

    setState(() {});
  }

  void _startListeningPosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      return;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
    }
    if (permission == LocationPermission.deniedForever) return;

    _positionStream =
        Geolocator.getPositionStream(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 5, // Mise à jour tous les 5m
          ),
        ).listen((Position pos) {
          final newLatLng = LatLng(pos.latitude, pos.longitude);

          // Mettre à jour le marker livreur
          _markers.removeWhere((m) => m.markerId.value == 'start');
          _markers.add(
            Marker(
              markerId: const MarkerId('start'),
              position: newLatLng,
              infoWindow: const InfoWindow(title: 'Livreur (en déplacement)'),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueBlue,
              ),
            ),
          );

          // Recalculer la distance jusqu'au client
          _distanceKm = _calculateDistance(
            pos.latitude,
            pos.longitude,
            widget.endLocation.latitude,
            widget.endLocation.longitude,
          );

          // Déplacer la caméra
          _mapController?.animateCamera(CameraUpdate.newLatLng(newLatLng));

          setState(() {});
        });
  }

  @override
  Widget build(BuildContext context) {
    final startLatLng = LatLng(
      widget.startLocation.latitude,
      widget.startLocation.longitude,
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Suivi du livreur')),
      body: Column(
        children: [
          // --- Google Map ---
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.6,
              child: GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: startLatLng,
                  zoom: 14,
                ),
                onMapCreated: (controller) => _mapController = controller,
                markers: _markers,
                polylines: Set<Polyline>.of(_polylines.values),
                myLocationEnabled: false,
                zoomControlsEnabled: false,
              ),
            ),
          ),

          // --- Infos et boutons ---
          Expanded(
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Distance restante : ${_distanceKm.toStringAsFixed(2)} km',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            // Continuer
                          },
                          child: const Text('Continuer'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                          ),
                          onPressed: () {
                            // Abandonner
                          },
                          child: const Text('Abandonner'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
