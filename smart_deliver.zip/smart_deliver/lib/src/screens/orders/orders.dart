import 'package:lottie/lottie.dart';
import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/models/order_model.dart';
import 'package:smart_deliver/src/screens/orders/order_step.dart';
import 'package:smart_deliver/src/utils/texts/text_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  final User? _currentUser = FirebaseAuth.instance.currentUser;

  // Couleurs personnalisées
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _infoColor = Colors.blue;

  Stream<List<OrderModel>> _getOrderList() {
    if (_currentUser == null) {
      return Stream.value([]);
    }

    final firebase = FirebaseFirestore.instance;
    return firebase
        .collection('orders')
        .orderBy('createdAt', descending: true)
        .where(
          'deliverRef',
          isEqualTo: firebase.collection('users').doc(_currentUser!.uid),
        )
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((order) => OrderModel.fromSnapshot(order))
              .toList(),
        );
  }

  // Fonction pour obtenir les informations du statut
  Map<String, dynamic> _getStatusInfo(String status) {
    final statusLower = status.toLowerCase();

    switch (statusLower) {
      case 'neworder':
        return {
          'text': 'Nouvelle',
          'color': _infoColor,
          'icon': Icons.assignment_outlined,
          'description': 'En attente d\'acceptation',
        };
      case 'assigned':
        return {
          'text': 'Assignée',
          'color': _warningColor,
          'icon': Icons.person_outline,
          'description': 'Assignée à vous',
        };
      case 'accepted':
        return {
          'text': 'Acceptée',
          'color': Colors.blue,
          'icon': Icons.thumb_up_outlined,
          'description': 'Vous avez accepté',
        };
      case 'pending':
        return {
          'text': 'En cours',
          'color': Colors.purple,
          'icon': Icons.delivery_dining_outlined,
          'description': 'En livraison',
        };
      case 'delivered':
        return {
          'text': 'Livrée',
          'color': Colors.teal,
          'icon': Icons.check_circle_outlined,
          'description': 'Colis livré',
        };
      case 'paymentstep':
        return {
          'text': 'Paiement',
          'color': Colors.indigo,
          'icon': Icons.payment_outlined,
          'description': 'En attente de paiement',
        };
      case 'finish':
      case 'completed':
        return {
          'text': 'Terminée',
          'color': _successColor,
          'icon': Icons.celebration_outlined,
          'description': 'Course terminée',
        };
      case 'cancelled':
        return {
          'text': 'Annulée',
          'color': _errorColor,
          'icon': Icons.cancel_outlined,
          'description': 'Course annulée',
        };
      case 'refused':
        return {
          'text': 'Refusée',
          'color': _errorColor,
          'icon': Icons.block_outlined,
          'description': 'Course refusée',
        };
      default:
        return {
          'text': status,
          'color': Colors.grey,
          'icon': Icons.help_outline,
          'description': 'Statut inconnu',
        };
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(10),
            child: Column(
              children: [
                const SizedBox(height: 10),
                Container(
                  height: 45,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Colors.orange.shade50,
                    border: Border.all(color: Colors.orange.shade200),
                  ),
                  child: TabBar(
                    indicatorSize: TabBarIndicatorSize.tab,
                    dividerColor: Colors.transparent,
                    indicator: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_secondaryColor, _primaryColor],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: _secondaryColor.withOpacity(0.3),
                          blurRadius: 8,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    labelColor: Colors.white,
                    unselectedLabelColor: Colors.grey.shade700,
                    labelStyle: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                    unselectedLabelStyle: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.normal,
                    ),
                    tabs: const [
                      Tab(
                        icon: Icon(Icons.local_shipping_outlined, size: 20),
                        text: "En Cours",
                      ),
                      Tab(
                        icon: Icon(Icons.history_outlined, size: 20),
                        text: "Historique",
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
        body: StreamBuilder<List<OrderModel>>(
          stream: _getOrderList(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return _buildLoadingState();
            }

            if (snapshot.hasError) {
              return _buildErrorState();
            }

            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return _buildNoDataWidget("Aucune mission trouvée");
            }

            final allOrders = snapshot.data!;

            // Séparation des commandes
            final mesCourses = allOrders
                .where(
                  (order) =>
                      order.status.toLowerCase() != "completed" &&
                      order.status.toLowerCase() != "finish" &&
                      order.status.toLowerCase() != "cancelled" &&
                      order.status.toLowerCase() != "refused",
                )
                .toList();

            final historiques = allOrders
                .where(
                  (order) =>
                      order.status.toLowerCase() == "completed" ||
                      order.status.toLowerCase() == "finish" ||
                      order.status.toLowerCase() == "cancelled" ||
                      order.status.toLowerCase() == "refused",
                )
                .toList();

            return TabBarView(
              children: [
                // Onglet "En Cours"
                _buildOrderList(mesCourses, "Aucune mission en cours"),
                // Onglet "Historique"
                _buildOrderList(historiques, "Aucun historique de missions"),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/success_register.json',
            height: 120,
            width: 120,
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 20),
          TextCustom(
            TheText: "Chargement des missions...",
            TheTextSize: 16,
            TheTextColor: Colors.grey.shade600,
          ),
          const SizedBox(height: 10),
          CircularProgressIndicator(color: _primaryColor, strokeWidth: 2),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/no_data.json',
            height: 150,
            width: 150,
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 20),
          TextCustom(
            TheText: "Erreur de chargement",
            TheTextSize: 18,
            TheTextFontWeight: FontWeight.bold,
            TheTextColor: _errorColor,
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: TextCustom(
              TheText:
                  "Impossible de charger vos missions. Veuillez réessayer.",
              TheTextSize: 14,
              TheTextColor: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: () => setState(() {}),
            style: ElevatedButton.styleFrom(
              backgroundColor: _primaryColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text("Réessayer"),
          ),
        ],
      ),
    );
  }

  Widget _buildNoDataWidget(String message) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/no_data.json',
            height: 200,
            width: 200,
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 20),
          TextCustom(
            TheText: message,
            TheTextSize: 16,
            TheTextFontWeight: FontWeight.bold,
            TheTextColor: Colors.grey.shade600,
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: TextCustom(
              TheText:
                  "Les nouvelles missions apparaîtront ici automatiquement",
              TheTextSize: 14,
              TheTextColor: Colors.grey.shade500,
              
            ),
          ),
        ],
      ),
    );
  }

  // Widget réutilisable pour afficher une liste de commandes
  Widget _buildOrderList(List<OrderModel> orders, String emptyMessage) {
    if (orders.isEmpty) {
      return _buildEmptyState(emptyMessage);
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      separatorBuilder: (_, __) => const SizedBox(height: 5),
      itemCount: orders.length,
      itemBuilder: (_, index) {
        final order = orders[index];
        return _buildOrderCard(order);
      },
    );
  }

  Widget _buildEmptyState(String message) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.inventory_2_outlined,
              size: 64,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 16),
            Text(
              message,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              "Patientez ou rafraîchissez la page",
              style: TextStyle(fontSize: 14, color: Colors.grey.shade500),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderCard(OrderModel order) {
    final statusInfo = _getStatusInfo(order.status);
    final isCompleted =
        order.status.toLowerCase() == "completed" ||
        order.status.toLowerCase() == "finish";

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: () {
          Get.to(
            () => OrderStep(
              status: order.status,
              orderId: order.uid!,
              amount: order.amount,
              carId: '',
              userCreatedId: order.userRef!.id,
              managerRef: order.managerRef,
              deliverRef: order.deliverRef,
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: isCompleted
                ? LinearGradient(
                    colors: [Colors.green.shade50, Colors.green.shade100],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : LinearGradient(
                    colors: [Colors.white, Colors.grey.shade50],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // En-tête avec numéro de commande et statut
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Row(
                        children: [
                          Icon(
                            Icons.local_shipping_rounded,
                            size: 20,
                            color: _primaryColor,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Mission #${order.orderId}',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: statusInfo['color'].withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: statusInfo['color'] as Color,
                          width: 1.5,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            statusInfo['icon'],
                            size: 14,
                            color: statusInfo['color'] as Color,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            statusInfo['text'],
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: statusInfo['color'] as Color,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Description du statut
                Text(
                  statusInfo['description'],
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey.shade600,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 16),

                // Informations détaillées
                _buildInfoRow(
                  icon: Icons.calendar_today_outlined,
                  label: 'Date',
                  value: DateFormat(
                    'dd/MM/yyyy',
                  ).format(order.createdAt.toDate()),
                ),
                const SizedBox(height: 8),

                _buildInfoRow(
                  icon: Icons.access_time_outlined,
                  label: 'Heure',
                  value: DateFormat('HH:mm').format(order.createdAt.toDate()),
                ),
                const SizedBox(height: 8),

                _buildInfoRow(
                  icon: Icons.attach_money_outlined,
                  label: 'Gains',
                  value: '${order.amount.toStringAsFixed(0)} FCFA',
                  valueStyle: TextStyle(
                    color: _successColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 8),

                // Prix total si disponible
                if (order.totalPrice > order.amount)
                  _buildInfoRow(
                    icon: Icons.shopping_cart_outlined,
                    label: 'Total avec achats',
                    value: '${order.totalPrice.toStringAsFixed(0)} FCFA',
                    valueStyle: TextStyle(
                      color: _secondaryColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),

                const SizedBox(height: 12),

                // Bouton d'action
                Container(
                  width: double.infinity,
                  height: 40,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_primaryColor, _secondaryColor],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: _primaryColor.withOpacity(0.3),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      Get.to(
                        () => OrderStep(
                          status: order.status,
                          orderId: order.uid!,
                          amount: order.amount,
                          carId: '',
                          userCreatedId: order.userRef!.id,
                          managerRef: order.managerRef,
                          deliverRef: order.deliverRef,
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: EdgeInsets.zero,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Voir les détails',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Icon(Icons.arrow_forward_ios_rounded, size: 14),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
    TextStyle? valueStyle,
  }) {
    return Row(
      children: [
        Icon(icon, size: 16, color: Colors.grey.shade500),
        const SizedBox(width: 8),
        Text(
          '$label : ',
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey.shade600,
            fontWeight: FontWeight.w500,
          ),
        ),
        Expanded(
          child: Text(
            value,
            style:
                valueStyle ??
                TextStyle(
                  fontSize: 13,
                  color: Colors.grey.shade800,
                  fontWeight: FontWeight.w600,
                ),
            textAlign: TextAlign.right,
          ),
        ),
      ],
    );
  }
}
