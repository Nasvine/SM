import 'package:smart_deliver/notification_services.dart';
import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/controllers/OrdersController.dart';
import 'package:smart_deliver/src/models/auth/notification_model.dart';
import 'package:smart_deliver/src/models/auth/user_model.dart';
import 'package:smart_deliver/src/models/order_model.dart';
import 'package:smart_deliver/src/models/transactions/transaction_model.dart';
import 'package:smart_deliver/src/models/wallet/wallet_model.dart';
import 'package:smart_deliver/src/repository/authentification_repository.dart';
import 'package:smart_deliver/src/screens/chat/chat_screen.dart';
import 'package:smart_deliver/src/screens/orders/GoToWithdrawalPage.dart';
import 'package:smart_deliver/src/screens/orders/GoToDestinationPage.dart';
import 'package:smart_deliver/src/screens/orders/order_detail.dart';
import 'package:smart_deliver/src/screens/tabs.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';
import 'package:smart_deliver/src/utils/texts/button_custom.dart';
import 'package:smart_deliver/src/utils/texts/button_custom_outlined.dart';
import 'package:smart_deliver/src/utils/texts/text_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:smart_deliver/src/utils/texts/text_form_field_simple_custom.dart';
import 'package:smart_deliver/src/utils/validators/validator.dart';
import 'package:location/location.dart';
import 'package:lottie/lottie.dart';
import 'package:confetti/confetti.dart';

final ordersController = Get.put(Orderscontroller());

class OrderStep extends StatefulWidget {
  const OrderStep({
    super.key,
    required this.status,
    required this.orderId,
    required this.amount,
    required this.carId,
    required this.userCreatedId,
    required this.managerRef,
    required this.deliverRef,
  });

  final String status;
  final String carId;
  final String orderId;
  final String userCreatedId;
  final double amount;
  final DocumentReference? managerRef;
  final DocumentReference? deliverRef;

  @override
  State<OrderStep> createState() => _OrderStepState();
}

class _OrderStepState extends State<OrderStep> {
  final firebase = FirebaseFirestore.instance;
  OrderModel orderData = OrderModel.empty();
  int currentStep = 0;
  var user = {};
  String userName = "";
  String userEmail = "";
  String userPhone = "";
  final purchaseAmount = TextEditingController();
  double userLatitude = 0.0;
  double userLontitude = 0.0;
  String userAdress = '';
  UserModel clientInfo = UserModel.empty();
  String fcmDeliver = "";
  String fcmManager = "";
  late ConfettiController _confettiController;

  // Couleurs personnalisées pour le design
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _disabledColor = Colors.grey;

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: const Duration(seconds: 3));
    _getUserInfo();
    _getClientInfo();
    _getCurrentLocation();
    _fetchOrderDetails();
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  void _getUserInfo() async {
    final auth = FirebaseAuth.instance.currentUser!;
    final data = await AuthentificationRepository.instance.getUserInfo(auth.uid);
    if (data.isNotEmpty) {
      setState(() {
        user = data;
        userName = user['fullName'];
        userEmail = user['email'];
      });
    }
  }

  Future<String> getFCM_Deliver(String userId) async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(userId).get();
    if (doc.exists) {
      final data = UserModel.fromSnapshot(doc);
      setState(() {
        fcmDeliver = data.fcmToken!;
      });
      return data.fcmToken!;
    }
    return '';
  }

  Future<String> getFCM_Manager(String userId) async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(userId).get();
    if (doc.exists) {
      final data = UserModel.fromSnapshot(doc);
      setState(() {
        fcmManager = data.fcmToken!;
      });
      return data.fcmToken!;
    }
    return '';
  }

  int _getStepFromStatus(String status) {
    switch (status.toLowerCase()) {
      case 'neworder': return 0;
      case 'assigned': return 1;
      case 'accepted': return 2;
      case 'pending': return 3;
      case 'delivered': return 4;
      case 'paymentstep': return 5;
      case 'finish': return 6;
      case 'cancelled': return 7;
      case 'refused': return 8;
      default: return 0;
    }
  }

  // Fonction pour obtenir les informations du statut (icône et couleur)
  Map<String, dynamic> _getStepInfo(int step) {
    switch (step) {
      case 0:
        return {
          'icon': Icons.assignment_outlined,
          'color': _primaryColor,
          'title': 'Nouvelle commande',
          'subtitle': 'Commande en cours d\'analyse'
        };
      case 1:
        return {
          'icon': Icons.thumb_up_outlined,
          'color': _warningColor,
          'title': 'Acceptation',
          'subtitle': 'Acceptez la commande'
        };
      case 2:
        return {
          'icon': Icons.luggage,
          'color': Colors.blue,
          'title': 'Prise du colis',
          'subtitle': 'Récupérez le colis'
        };
      case 3:
        return {
          'icon': Icons.delivery_dining_outlined,
          'color': Colors.purple,
          'title': 'En livraison',
          'subtitle': 'Livrez le colis au client'
        };
      case 4:
        return {
          'icon': Icons.check_circle_outlined,
          'color': Colors.teal,
          'title': 'Livré',
          'subtitle': 'Colis remis au client'
        };
      case 5:
        return {
          'icon': Icons.payment_outlined,
          'color': Colors.indigo,
          'title': 'Paiement',
          'subtitle': 'Recevez le paiement'
        };
      case 6:
        return {
          'icon': Icons.celebration_outlined,
          'color': _successColor,
          'title': 'Terminé',
          'subtitle': 'Course finalisée'
        };
      default:
        return {
          'icon': Icons.circle_outlined,
          'color': Colors.grey,
          'title': 'Étape $step',
          'subtitle': ''
        };
    }
  }

  Widget _buildStepIndicator(int step, bool isActive, bool isCompleted) {
    final stepInfo = _getStepInfo(step);
    
    return Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        color: isCompleted ? stepInfo['color'] : (isActive ? stepInfo['color'] : Colors.grey.shade300),
        shape: BoxShape.circle,
        boxShadow: isActive ? [
          BoxShadow(
            color: (stepInfo['color'] as Color).withOpacity(0.3),
            blurRadius: 8,
            spreadRadius: 2,
          )
        ] : null,
      ),
      child: Icon(
        stepInfo['icon'],
        color: isCompleted || isActive ? Colors.white : Colors.grey,
        size: 20,
      ),
    );
  }

  Widget _buildStepContent(int step, bool isActive, int currentStep) {
    final stepInfo = _getStepInfo(step);
    final isStepCompleted = step < currentStep;
    final isStepFuture = step > currentStep;
    
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      margin: EdgeInsets.symmetric(vertical: 8),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isActive ? (stepInfo['color'] as Color).withOpacity(0.1) : Colors.transparent,
        borderRadius: BorderRadius.circular(15),
        border: isActive ? Border.all(color: stepInfo['color'] as Color, width: 2) : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(stepInfo['icon'], color: stepInfo['color'] as Color, size: 24),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      stepInfo['title'],
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: stepInfo['color'] as Color,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      stepInfo['subtitle'],
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              // Badge d'état
              if (isStepCompleted)
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _successColor,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Terminé',
                    style: TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                )
              else if (isActive)
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: stepInfo['color'] as Color,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'En cours',
                    style: TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                )
              else if (isStepFuture)
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _disabledColor,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'À venir',
                    style: TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
            ],
          ),
          SizedBox(height: 16),
          _buildStepSpecificContent(step, isActive, currentStep),
        ],
      ),
    );
  }

  Widget _buildStepSpecificContent(int step, bool isActive, int currentStep) {
    final isStepCompleted = step < currentStep;
    final isStepFuture = step > currentStep;
    
    switch (step) {
      case 0:
        return Column(
          children: [
            Lottie.asset(
              'assets/images/order_placed.json',
              height: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),
            Text(
              "La commande est en cours d'analyse par l'administrateur.",
              style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
              textAlign: TextAlign.center,
            ),
          ],
        );
      
      case 1:
        return Column(
          children: [
            Lottie.asset(
              'assets/images/accept_order.json',
              height: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),
            Text(
              "Consultez les détails de la commande et acceptez-la pour continuer.",
              style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            _buildActionButton(
              text: 'Voir les détails',
              icon: Icons.info_outline,
              color: isActive ? _primaryColor : _disabledColor,
              onPressed: isActive ? () {
                Get.to(
                  () => OrderDetailScreen(
                    startLocation: orderData.withdrawalPoint,
                    endLocation: orderData.destinationLocation,
                    userCreatedId: orderData.userRef!.id,
                    orderId: orderData.uid!,
                  ),
                );
              } : null,
              isDisabled: !isActive,
            ),
            SizedBox(height: 12),
            _buildActionButton(
              text: 'Discuter avec le client',
              icon: Icons.chat_outlined,
              color: isActive ? _secondaryColor : _disabledColor,
              onPressed: isActive ? () {
                Get.to(
                  () => ChatScreen(
                    receiverID: orderData.userRef!.id,
                    receiverEmail: clientInfo.email,
                  ),
                );
              } : null,
              isDisabled: !isActive,
            ),
            SizedBox(height: 12),
            _buildActionButton(
              text: 'Accepter la commande',
              icon: Icons.check_circle_outline,
              color: isActive ? _successColor : _disabledColor,
              onPressed: isActive ? _acceptOrder : null,
              isDisabled: !isActive,
            ),
            if (isStepFuture) ...[
              SizedBox(height: 12),
              Text(
                'Ces actions seront disponibles après l\'analyse de la commande',
                style: TextStyle(fontSize: 12, color: _warningColor, fontStyle: FontStyle.italic),
                textAlign: TextAlign.center,
              ),
            ],
          ],
        );
      
      case 2:
        return Column(
          children: [
            Lottie.asset(
              'assets/images/pickup.json',
              height: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),
            Text(
              "Rendez-vous au point de retrait et confirmez la récupération du colis.",
              style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            _buildActionButton(
              text: 'Voir le point de retrait',
              icon: Icons.location_on_outlined,
              color: isActive ? _primaryColor : _disabledColor,
              onPressed: isActive ? () {
                Get.to(
                  () => GoToWithdrawalPage(
                    order: orderData,
                    googleApiKey: "AIzaSyCv7nzABmowHcgisZuOVJL8HvENMMQ-uxU",
                  ),
                );
              } : null,
              isDisabled: !isActive,
            ),
            SizedBox(height: 12),
            _buildActionButton(
              text: 'Discuter avec le client',
              icon: Icons.chat_outlined,
              color: isActive ? _secondaryColor : _disabledColor,
              onPressed: isActive ? () {
                Get.to(
                  () => ChatScreen(
                    receiverID: orderData.userRef!.id,
                    receiverEmail: clientInfo.email,
                  ),
                );
              } : null,
              isDisabled: !isActive,
            ),
            SizedBox(height: 12),
            _buildActionButton(
              text: 'Confirmer récupération',
              icon: Icons.inventory_2_outlined,
              color: isActive ? _successColor : _disabledColor,
              onPressed: isActive ? _showPurchaseModal : null,
              isDisabled: !isActive,
            ),
            if (isStepFuture) ...[
              SizedBox(height: 12),
              Text(
                'Ces actions seront disponibles après l\'acceptation de la commande',
                style: TextStyle(fontSize: 12, color: _warningColor, fontStyle: FontStyle.italic),
                textAlign: TextAlign.center,
              ),
            ],
          ],
        );
      
      case 3:
        return Column(
          children: [
            Lottie.asset(
              'assets/images/delivery.json',
              height: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),
            Text(
              "Livrez le colis au client et suivez votre trajet en temps réel.",
              style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            _buildActionButton(
              text: 'Voir destination',
              icon: Icons.map_outlined,
              color: isActive ? _primaryColor : _disabledColor,
              onPressed: isActive ? () {
                Get.to(
                  () => GoToDestinationPage(
                    order: orderData,
                    googleApiKey: "AIzaSyCv7nzABmowHcgisZuOVJL8HvENMMQ-uxU",
                  ),
                );
              } : null,
              isDisabled: !isActive,
            ),
            SizedBox(height: 12),
            _buildActionButton(
              text: 'Discuter avec le client',
              icon: Icons.chat_outlined,
              color: isActive ? _secondaryColor : _disabledColor,
              onPressed: isActive ? () {
                Get.to(
                  () => ChatScreen(
                    receiverID: orderData.userRef!.id,
                    receiverEmail: clientInfo.email,
                  ),
                );
              } : null,
              isDisabled: !isActive,
            ),
            if (isStepFuture) ...[
              SizedBox(height: 12),
              Text(
                'Ces actions seront disponibles après la récupération du colis',
                style: TextStyle(fontSize: 12, color: _warningColor, fontStyle: FontStyle.italic),
                textAlign: TextAlign.center,
              ),
            ],
          ],
        );
      
      case 5:
        return Column(
          children: [
            Lottie.asset(
              'assets/images/payment.json',
              height: 100,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),
            Text(
              "Le client effectuera le paiement en espèces ou par mobile money.",
              style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: Column(
                children: [
                  Text(
                    'Montant à recevoir',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.blue.shade800),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '${orderData.totalPrice.toInt()} FCFA',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: _successColor),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            _buildActionButton(
              text: 'Confirmer réception espèces',
              icon: Icons.money_outlined,
              color: isActive ? _successColor : _disabledColor,
              onPressed: isActive ? _confirmCashPayment : null,
              isDisabled: !isActive,
            ),
            SizedBox(height: 12),
            _buildActionButton(
              text: 'Discuter avec le client',
              icon: Icons.chat_outlined,
              color: isActive ? _secondaryColor : _disabledColor,
              onPressed: isActive ? () {
                Get.to(
                  () => ChatScreen(
                    receiverID: orderData.userRef!.id,
                    receiverEmail: clientInfo.email,
                  ),
                );
              } : null,
              isDisabled: !isActive,
            ),
            if (isStepFuture) ...[
              SizedBox(height: 12),
              Text(
                'Le paiement sera disponible après la livraison du colis',
                style: TextStyle(fontSize: 12, color: _warningColor, fontStyle: FontStyle.italic),
                textAlign: TextAlign.center,
              ),
            ],
          ],
        );
      
      case 6:
        return Column(
          children: [
            Lottie.asset(
              'assets/images/success.json',
              height: 150,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),
            Text(
              'Félicitations ! La course a été terminée avec succès.',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: _successColor,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 8),
            Text(
              'Merci pour votre excellent travail.',
              style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            _buildActionButton(
              text: 'Retour à l\'accueil',
              icon: Icons.home,
              color: _primaryColor,
              onPressed: () => Get.offAll(() => TabsScreen(initialIndex: 1)),
              isDisabled: false,
            ),
          ],
        );
      
      default:
        return Container(
          padding: EdgeInsets.all(16),
          margin: EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              Text(
                _getStepInfo(step)['subtitle'],
                style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
                textAlign: TextAlign.center,
              ),
              if (isStepFuture) ...[
                SizedBox(height: 8),
                Text(
                  'Cette étape sera bientôt disponible',
                  style: TextStyle(fontSize: 12, color: _disabledColor, fontStyle: FontStyle.italic),
                  textAlign: TextAlign.center,
                ),
              ],
            ],
          ),
        );
    }
  }

  Widget _buildActionButton({
    required String text,
    required IconData icon,
    required Color color,
    required VoidCallback? onPressed,
    required bool isDisabled,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: isDisabled ? _disabledColor : color,
        foregroundColor: Colors.white,
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: isDisabled ? 0 : 2,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 18),
          SizedBox(width: 8),
          Flexible(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 12, 
                fontWeight: FontWeight.bold,
                color: isDisabled ? Colors.grey.shade400 : Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          if (isDisabled) ...[
            SizedBox(width: 4),
            Icon(Icons.lock_outline, size: 14, color: Colors.grey.shade400),
          ],
        ],
      ),
    );
  }

  void _acceptOrder() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => _buildConfirmationDialog(
        title: "Accepter la commande",
        content: "Voulez-vous accepter cette commande ?",
        confirmText: "Oui, accepter",
        confirmColor: _successColor,
      ),
    );

    if (confirm == true) {
      try {
        await _updateOrderStatus('accepted');
        _showCustomSnackBar('Commande acceptée avec succès!', _successColor, Icons.check_circle);
      } catch (e) {
        _showCustomSnackBar('Erreur: $e', _errorColor, Icons.error);
      }
    }
  }

  void _confirmCashPayment() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => _buildConfirmationDialog(
        title: "Confirmer le paiement",
        content: "Voulez-vous confirmer la réception du paiement en espèces ?",
        confirmText: "Oui, confirmer",
        confirmColor: _successColor,
      ),
    );

    if (confirm == true) {
      try {
        await _processCashPayment();
        _confettiController.play();
      } catch (e) {
        _showCustomSnackBar('Erreur: $e', _errorColor, Icons.error);
      }
    }
  }

  Widget _buildConfirmationDialog({
    required String title,
    required String content,
    required String confirmText,
    required Color confirmColor,
  }) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.help_outline, size: 48, color: _primaryColor),
            SizedBox(height: 16),
            Text(
              title,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 12),
            Text(
              content,
              style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context, false),
                    style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      padding: EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text('Annuler'),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: confirmColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      padding: EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text(confirmText),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showCustomSnackBar(String message, Color color, IconData icon) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: color,
        content: Row(
          children: [
            Icon(icon, color: Colors.white),
            SizedBox(width: 10),
            Expanded(child: Text(message, style: TextStyle(color: Colors.white))),
          ],
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Future<void> _updateOrderStatus(String newStatus) async {
    final firebase = FirebaseFirestore.instance;
    try {
      await firebase.collection('orders').doc(widget.orderId).update({
        'status': newStatus,
      });
    } catch (e) {
      throw e;
    }
  }

  void _showPurchaseModal() async {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Prix des achats effectués",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              Text(
                "NB: Si vous n'avez pas fait d'achats, entrez 0 dans le champ.",
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.normal,
                  color: Colors.red,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              TextFormFieldSimpleCustom(
                keyboardType: TextInputType.number,
                obscureText: false,
                borderRadiusBorder: 10,
                cursorColor: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tWhiteColor
                    : ColorApp.tBlackColor,
                borderSideRadiusBorder: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tsecondaryColor
                    : ColorApp.tSombreColor,
                borderRadiusFocusedBorder: 10,
                borderSideRadiusFocusedBorder: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tsecondaryColor
                    : ColorApp.tSombreColor,
                controller: purchaseAmount,
                labelText: 'Entrez le montant',
                labelStyleColor: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tWhiteColor
                    : ColorApp.tBlackColor,
                hintText: 'Entrez le montant',
                hintStyleColor: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tWhiteColor
                    : ColorApp.tBlackColor,
                validator: (value) => TValidator.validationEmptyText("Montant", value),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    if (purchaseAmount.text.isEmpty) {
                      _showCustomSnackBar('Veuillez entrer le montant', _errorColor, Icons.error);
                      return;
                    }
                    await _processPurchaseConfirmation();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _secondaryColor,
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: Text("Confirmer la récupération"),
                ),
              ),
              SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }

  Future<void> _processPurchaseConfirmation() async {
    try {
      final firebase = FirebaseFirestore.instance;

      await firebase.collection('orders').doc(widget.orderId).update({
        'status': "pending",
        'purchasePrice': double.parse(purchaseAmount.text.trim()),
        'totalPrice': double.parse(purchaseAmount.text.trim()) + orderData.amount,
      });

      final notification = NotificationModel(
        senderRef: FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid),
        receiverRef: clientInfo.ref,
        title: 'Prise de Colis 🎉',
        message: "Le livreur vient de prendre votre colis.",
        type: "Location",
        isRead: false,
        createdAt: Timestamp.now(),
      );

      await FirebaseFirestore.instance.collection('notifications').add(notification.toJson());

      NotificationServices().sendPushNotification(
        deviceToken: clientInfo.fcmToken!,
        title: "Prise de Colis 🎉",
        body: "Le livreur vient de prendre votre colis. Patientez, il est en route.",
      );

      _showCustomSnackBar('Récupération confirmée avec succès!', _successColor, Icons.check_circle);
      Navigator.pop(context);
      Get.offAll(() => TabsScreen(initialIndex: 1));
    } catch (e) {
      _showCustomSnackBar('Erreur: $e', _errorColor, Icons.error);
    }
  }

  Future<void> _processCashPayment() async {
    try {
      final firebase = FirebaseFirestore.instance;

      await firebase.collection('orders').doc(widget.orderId).update({
        'status': 'finish',
        'paymentStatus': 'Completed',
      });

      await firebase.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).update({
        'isAvailable': true,
      });

      // Gestion du portefeuille
      final walletData = await firebase
          .collection('wallets')
          .where('userId', isEqualTo: widget.deliverRef)
          .limit(1)
          .get();

      final transaction = TransactionModel(
        userId: widget.deliverRef!.id,
        userCreatedId: FirebaseAuth.instance.currentUser!.uid,
        amount: widget.amount.toDouble(),
        type: "cash",
        status: "completed",
        createdAt: Timestamp.now(),
        reference: 'REF_${DateTime.now().millisecondsSinceEpoch}',
      );

      if (walletData.docs.isNotEmpty) {
        final existingWalletDoc = walletData.docs.first;
        final data = WalletModel.fromSnapshot(existingWalletDoc);

        final wallet = WalletModel(
          uuid: data.uuid,
          userId: data.userId,
          amount: data.amount + widget.amount.toDouble(),
          createdAt: Timestamp.now(),
        );

        await firebase.collection('wallets').doc(data.uuid!.id).update(wallet.toMap());
      } else {
        final wallet = WalletModel(
          userId: widget.deliverRef!.id,
          amount: widget.amount.toDouble(),
          createdAt: Timestamp.now(),
        );
        await firebase.collection('wallets').add(wallet.toMap());
      }

      await firebase.collection('transactions').add(transaction.toJson());

      // Notifications
      final notificationManager = NotificationModel(
        senderRef: FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid),
        receiverRef: widget.managerRef,
        title: 'Paiement reçu 💰',
        message: "Le client vient de payer la course.",
        type: "Location",
        isRead: false,
        createdAt: Timestamp.now(),
      );

      final notificationDeliver = NotificationModel(
        senderRef: FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid),
        receiverRef: widget.managerRef,
        title: 'Paiement reçu 💰',
        message: "Le client vient de vous payer la course.",
        type: "Location",
        isRead: false,
        createdAt: Timestamp.now(),
      );

      await getFCM_Deliver(widget.deliverRef!.id);
      await getFCM_Manager(widget.managerRef!.id);

      await FirebaseFirestore.instance.collection('notifications').add(notificationManager.toJson());
      await FirebaseFirestore.instance.collection('notifications').add(notificationDeliver.toJson());

      NotificationServices().sendPushNotification(
        deviceToken: fcmDeliver,
        title: "Paiement reçu 💰",
        body: "Le client vient de vous payer la course. Montant: ${widget.amount} FCFA",
      );

      NotificationServices().sendPushNotification(
        deviceToken: fcmManager,
        title: "Paiement confirmé 💰",
        body: "Le client a payé la course #${widget.orderId}",
      );

      _showCustomSnackBar('Paiement confirmé avec succès!', _successColor, Icons.check_circle);
      
      Future.delayed(Duration(seconds: 2), () {
        Get.offAll(() => TabsScreen(initialIndex: 1));
      });

    } catch (e) {
      throw e;
    }
  }

  Future<void> _getCurrentLocation() async {
    Location location = Location();
    bool serviceEnabled;
    PermissionStatus permissionGranted;
    LocationData locationData;

    serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
      if (!serviceEnabled) return;
    }

    permissionGranted = await location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();
      if (permissionGranted != PermissionStatus.granted) return;
    }

    locationData = await location.getLocation();
    setState(() {
      userLatitude = locationData.latitude!;
      userLontitude = locationData.longitude!;
    });
  }

  void _getClientInfo() async {
    final data = await firebase.collection("users").doc(widget.userCreatedId).get();
    if (data.exists) {
      final client = UserModel.fromSnapshot(data);
      setState(() {
        clientInfo = client;
      });
    }
  }

  void _fetchOrderDetails() async {
    final data = await firebase.collection('orders').doc(widget.orderId).get();
    if (data.exists) {
      final order = OrderModel.fromSnapshot(data);
      setState(() {
        orderData = order;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Get.offAll(() => TabsScreen(initialIndex: 1)),
          icon: Icon(
            LineAwesomeIcons.angle_left_solid,
            color: THelperFunctions.isDarkMode(context) ? ColorApp.tWhiteColor : ColorApp.tBlackColor,
          ),
        ),
        centerTitle: true,
        title: TextCustom(
          TheText: "Suivi de commande",
          TheTextSize: 16,
          TheTextFontWeight: FontWeight.bold,
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      body: Stack(
        children: [
          StreamBuilder<DocumentSnapshot>(
            stream: FirebaseFirestore.instance.collection('orders').doc(widget.orderId).snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: _primaryColor),
                      SizedBox(height: 16),
                      Text(
                        'Chargement du suivi...',
                        style: TextStyle(color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                );
              }

              if (!snapshot.hasData || !snapshot.data!.exists) {
                return _buildErrorState("Commande introuvable");
              }

              final status = snapshot.data!['status'];
              final currentStep = _getStepFromStatus(status);

              if (status == "refused") {
                return _buildErrorState(
                  "Commande refusée",
                  "Cette commande a été refusée par l'administrateur.",
                  Icons.block,
                  _errorColor,
                );
              }

              if (status == "cancelled") {
                return _buildErrorState(
                  "Commande annulée",
                  "Cette commande a été annulée.",
                  Icons.cancel,
                  _warningColor,
                );
              }

              return SingleChildScrollView(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    // En-tête
                    Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Icon(Icons.local_shipping, color: _primaryColor, size: 24),
                                SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Commande #${widget.orderId}',
                                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        '${orderData.totalPrice.toInt()} FCFA',
                                        style: TextStyle(fontSize: 14, color: _secondaryColor, fontWeight: FontWeight.bold),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 12),
                            Divider(),
                            SizedBox(height: 8),
                            Text(
                              'Suivez l\'avancement de votre livraison en temps réel',
                              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 24),

                    // Étapes
                    ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: 7,
                      itemBuilder: (context, index) {
                        final isActive = index == currentStep;
                        final isCompleted = index < currentStep;
                        
                        return Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  children: [
                                    _buildStepIndicator(index, isActive, isCompleted),
                                    if (index < 6)
                                      Container(
                                        width: 2,
                                        height: 40,
                                        color: isCompleted ? _getStepInfo(index)['color'] : Colors.grey.shade300,
                                      ),
                                  ],
                                ),
                                SizedBox(width: 16),
                                Expanded(child: _buildStepContent(index, isActive, currentStep)),
                              ],
                            ),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              );
            },
          ),

          // Confetti pour la célébration
          ConfettiWidget(
            confettiController: _confettiController,
            blastDirectionality: BlastDirectionality.explosive,
            shouldLoop: false,
            colors: const [Colors.green, Colors.blue, Colors.orange, Colors.pink],
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState(String title, [String? message, IconData? icon, Color? color]) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon ?? Icons.error_outline,
              size: 64,
              color: color ?? _errorColor,
            ),
            SizedBox(height: 20),
            Text(
              title,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color ?? _errorColor),
              textAlign: TextAlign.center,
            ),
            if (message != null) ...[
              SizedBox(height: 12),
              Text(
                message,
                style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
                textAlign: TextAlign.center,
              ),
            ],
            SizedBox(height: 30),
            _buildActionButton(
              text: 'Retour à l\'accueil',
              icon: Icons.home,
              color: _primaryColor,
              onPressed: () => Get.offAll(() => TabsScreen(initialIndex: 1)),
              isDisabled: false,
            ),
          ],
        ),
      ),
    );
  }
}