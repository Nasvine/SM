import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/models/auth/user_model.dart';
import 'package:smart_deliver/src/models/order_model.dart';
import 'package:smart_deliver/src/screens/orders/order_step.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:smart_deliver/src/models/transactions/transaction_model.dart';
import 'package:lottie/lottie.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:confetti/confetti.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.userFullName,
    required this.userEmail,
  });

  final String userFullName;
  final String userEmail;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final User? _currentUser = FirebaseAuth.instance.currentUser;
  UserModel clientInfo = UserModel.empty();
  bool _hasFetchedClientInfo = false;
  late ConfettiController _confettiController;

  // Couleurs personnalisées
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _infoColor = Colors.blue;
  final Color _darkColor = Color(0xFF1A1A1A);

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: Duration(seconds: 3));
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  // Fonction de traduction des statuts
  String _translateStatus(String status) {
    switch (status.toLowerCase()) {
      case 'neworder':
        return 'Nouvelle';
      case 'assigned':
        return 'Assignée';
      case 'accepted':
        return 'Acceptée';
      case 'pending':
        return 'En cours';
      case 'delivered':
        return 'Livrée';
      case 'paymentstep':
        return 'Paiement';
      case 'finish':
        return 'Terminée';
      case 'cancelled':
        return 'Annulée';
      case 'refused':
        return 'Refusée';
      case 'completed':
        return 'Terminée';
      default:
        return status;
    }
  }

  // Fonction pour obtenir les informations du statut
  Map<String, dynamic> _getStatusInfo(String status) {
    final statusLower = status.toLowerCase();

    switch (statusLower) {
      case 'neworder':
        return {
          'text': 'Nouvelle',
          'color': _infoColor,
          'icon': Icons.assignment_outlined,
          'description': 'En attente d\'acceptation',
        };
      case 'assigned':
        return {
          'text': 'Assignée',
          'color': _warningColor,
          'icon': Icons.person_outline,
          'description': 'Assignée à vous',
        };
      case 'accepted':
        return {
          'text': 'Acceptée',
          'color': Colors.blue,
          'icon': Icons.thumb_up_outlined,
          'description': 'Vous avez accepté',
        };
      case 'pending':
        return {
          'text': 'En cours',
          'color': Colors.purple,
          'icon': Icons.delivery_dining_outlined,
          'description': 'En livraison',
        };
      case 'delivered':
        return {
          'text': 'Livrée',
          'color': Colors.teal,
          'icon': Icons.check_circle_outlined,
          'description': 'Colis livré',
        };
      case 'paymentstep':
        return {
          'text': 'Paiement',
          'color': Colors.indigo,
          'icon': Icons.payment_outlined,
          'description': 'En attente de paiement',
        };
      case 'finish':
      case 'completed':
        return {
          'text': 'Terminée',
          'color': _successColor,
          'icon': Icons.celebration_outlined,
          'description': 'Course terminée',
        };
      case 'cancelled':
        return {
          'text': 'Annulée',
          'color': _errorColor,
          'icon': Icons.cancel_outlined,
          'description': 'Course annulée',
        };
      case 'refused':
        return {
          'text': 'Refusée',
          'color': _errorColor,
          'icon': Icons.block_outlined,
          'description': 'Course refusée',
        };
      default:
        return {
          'text': status,
          'color': Colors.grey,
          'icon': Icons.help_outline,
          'description': 'Statut inconnu',
        };
    }
  }

  Stream<double> getUserBalance(String userId) {
    return FirebaseFirestore.instance
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .where('status', isEqualTo: 'completed')
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return 0.0;

          double totalPayments = 0;
          double totalWithdrawals = 0;

          for (var doc in snapshot.docs) {
            final data = doc.data();
            final amount = (data['amount'] as num).toDouble();
            final type = data['type'];

            if (type == 'payment') {
              totalPayments += amount;
            } else if (type == 'withdrawal') {
              totalWithdrawals += amount;
            }
          }

          return totalPayments - totalWithdrawals;
        });
  }

  Stream<double> getUserBalanceToday(String userId) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return FirebaseFirestore.instance
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .where('status', isEqualTo: 'completed')
        .where(
          'createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay),
          isLessThan: Timestamp.fromDate(endOfDay),
        )
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return 0.0;

          double totalPayments = 0;
          double totalWithdrawals = 0;

          for (var doc in snapshot.docs) {
            final data = doc.data();
            final amount = (data['amount'] as num).toDouble();
            final type = data['type'];

            if (type == 'payment') {
              totalPayments += amount;
            } else if (type == 'withdrawal') {
              totalWithdrawals += amount;
            }
          }

          return totalPayments - totalWithdrawals;
        });
  }

  Stream<int> getOrderPendingTotal(String userId) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('paymentStatus', isEqualTo: "Pending")
        .where(
          'createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay),
          isLessThan: Timestamp.fromDate(endOfDay),
        )
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Stream<OrderModel?> getOrderPendingFirstTotal(String userId) {
    return FirebaseFirestore.instance
        .collection('orders')
        .orderBy("createdAt", descending: true)
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('paymentStatus', isEqualTo: "Pending")
        .limit(1)
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return null;
          return OrderModel.fromSnapshot(snapshot.docs.first);
        });
  }

  Stream<List<OrderModel>> getOrdersFinishLists(String userId) {
    return FirebaseFirestore.instance
        .collection('orders')
        .orderBy("createdAt", descending: true)
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('paymentStatus', isEqualTo: "Completed")
        .limit(5)
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) => OrderModel.fromSnapshot(doc)).toList(),
        );
  }

  Stream<int> getOrderFinishTodayTotal(String userId) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('status', isEqualTo: "completed")
        .where(
          'createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay),
          isLessThan: Timestamp.fromDate(endOfDay),
        )
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Stream<int> getOrderFinishTotal(String userId) {
    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('status', isEqualTo: "completed")
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Stream<List<TransactionModel>> getTransactions(String userId) {
    return FirebaseFirestore.instance
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .limit(10)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => TransactionModel.fromSnapshot(doc))
              .toList(),
        );
  }

  void _getClientInfo(String userId) async {
    if (_hasFetchedClientInfo) return;

    final firebase = FirebaseFirestore.instance;
    final data = await firebase.collection("users").doc(userId).get();
    if (data.exists) {
      final client = UserModel.fromSnapshot(data);
      if (mounted) {
        setState(() {
          clientInfo = client;
          _hasFetchedClientInfo = true;
        });
      }
    }
  }

  Widget _buildStatCard({
    required String title,
    required Stream<dynamic> stream,
    required Color color,
    required IconData icon,
    String? defaultValue,
    bool isCurrency = false,
  }) {
    return Container(
      width:
          (MediaQuery.of(context).size.width - 48) /
          2, // Calcul dynamique de la largeur
      height: 100,
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [color.withOpacity(0.8), color],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 8,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(icon, color: Colors.white, size: 20),
                  StreamBuilder(
                    stream: stream,
                    builder: (context, asyncSnapshot) {
                      if (!asyncSnapshot.hasData && defaultValue == null) {
                        return SizedBox(
                          height: 16,
                          width: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        );
                      }

                      final data = asyncSnapshot.data ?? defaultValue ?? "0";
                      String displayText = data.toString();

                      if (isCurrency && data is num) {
                        displayText = '${data.toInt()} FCFA';
                      }

                      return Flexible(
                        child: Text(
                          displayText,
                          style: TextStyle(
                            fontSize: 16, // Taille réduite
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    },
                  ),
                ],
              ),
              Flexible(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.white.withOpacity(0.9),
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/success_register.json',
            height: 80,
            width: 80,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 8),
          Text(
            'Chargement...',
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }

  Widget _buildNoDataWidget(String message, {String? subtitle}) {
    return Container(
      height: 300,
      width: double.infinity,
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.grey.shade50,
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/no_data.json',
            height: 100,
            width: 100,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 16),
          Text(
            message,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade600,
            ),
            textAlign: TextAlign.center,
          ),
          if (subtitle != null) ...[
            SizedBox(height: 8),
            Text(
              subtitle,
              style: TextStyle(fontSize: 14, color: Colors.grey.shade500),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCurrentDeliverySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.local_shipping_rounded, color: _primaryColor, size: 20),
            SizedBox(width: 8),
            Text(
              'Livraison en cours',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tWhiteColor
                    : ColorApp.tBlackColor,
              ),
            ),
          ],
        ),
        SizedBox(height: 16),
        Card(
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.blue.shade50, Colors.blue.shade100],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: StreamBuilder<OrderModel?>(
              stream: getOrderPendingFirstTotal(_currentUser!.uid),
              builder: (context, asyncSnapshot) {
                if (asyncSnapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: _buildLoadingIndicator());
                }

                if (!asyncSnapshot.hasData || asyncSnapshot.data == null) {
                  return _buildNoDataWidget(
                    "Aucune livraison en cours",
                    subtitle: "Les nouvelles missions apparaîtront ici",
                  );
                }

                final order = asyncSnapshot.data!;
                if (!_hasFetchedClientInfo) {
                  _getClientInfo(order.userRef!.id);
                }

                return InkWell(
                  onTap: () {
                    Get.to(
                      () => OrderStep(
                        status: order.status,
                        orderId: order.uid!,
                        amount: order.amount,
                        carId: '',
                        userCreatedId: order.userRef!.id,
                        managerRef: order.managerRef,
                        deliverRef: order.deliverRef,
                      ),
                    );
                  },
                  child: _buildOrderDetails(order),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildOrderDetails(OrderModel order) {
    final statusInfo = _getStatusInfo(order.status);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // En-tête
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Mission #${order.orderId}',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  DateFormat(
                    'dd/MM/yyyy à HH:mm',
                  ).format(order.createdAt.toDate()),
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
              ],
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: statusInfo['color'].withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: statusInfo['color'] as Color,
                  width: 1.5,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    statusInfo['icon'],
                    size: 14,
                    color: statusInfo['color'] as Color,
                  ),
                  SizedBox(width: 6),
                  Text(
                    statusInfo['text'],
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: statusInfo['color'] as Color,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        SizedBox(height: 16),

        // Informations client
        _buildInfoItem(
          icon: Icons.person_outline,
          title: 'Client',
          value: clientInfo.fullName.isNotEmpty
              ? clientInfo.fullName
              : 'Chargement...',
        ),
        SizedBox(height: 12),

        // Informations course
        Row(
          children: [
            Expanded(
              child: _buildInfoItem(
                icon: Icons.attach_money_outlined,
                title: 'Gains',
                value: '${order.amount.toInt()} FCFA',
                valueStyle: TextStyle(
                  color: _successColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: _buildInfoItem(
                icon: Icons.space_dashboard_outlined,
                title: 'Distance',
                value: '${order.distance.toStringAsFixed(1)} Km',
              ),
            ),
          ],
        ),
        SizedBox(height: 20),

        // Points de livraison
        _buildLocationSection(
          icon: Icons.location_on_outlined,
          title: "Point de retrait",
          address: order.withdrawalPoint.address,
          phoneNumber: "${order.numeroWithdrawal}",
        ),
        SizedBox(height: 16),
        _buildLocationSection(
          icon: Icons.flag_outlined,
          title: "Destination",
          address: order.destinationLocation.address,
          phoneNumber: clientInfo.phoneNumber,
        ),
      ],
    );
  }

  Widget _buildInfoItem({
    required IconData icon,
    required String title,
    required String value,
    TextStyle? valueStyle,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, size: 16, color: Colors.grey.shade600),
            SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade600,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        SizedBox(height: 4),
        Text(
          value,
          style:
              valueStyle ??
              TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
        ),
      ],
    );
  }

  Widget _buildLocationSection({
    required IconData icon,
    required String title,
    required String address,
    required String phoneNumber,
  }) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: _primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: _primaryColor, size: 20),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  address,
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          SizedBox(width: 12),
          _buildPhoneButton(phoneNumber),
        ],
      ),
    );
  }

  Widget _buildPhoneButton(String phoneNumber) {
    return InkWell(
      onTap: () async {
        final formattedNumber = "tel:+229$phoneNumber";
        final Uri phoneUri = Uri.parse(formattedNumber);

        if (await canLaunchUrl(phoneUri)) {
          await launchUrl(phoneUri);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Impossible de passer l\'appel'),
              backgroundColor: _errorColor,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      },
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: _successColor,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: _successColor.withOpacity(0.3),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Icon(Icons.phone_rounded, color: Colors.white, size: 20),
      ),
    );
  }

  Widget _buildRecentDeliveriesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.history_rounded, color: _primaryColor, size: 20),
            SizedBox(width: 8),
            Text(
              'Livraisons récentes',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tWhiteColor
                    : ColorApp.tBlackColor,
              ),
            ),
          ],
        ),
        SizedBox(height: 16),
        StreamBuilder<List<OrderModel>>(
          stream: getOrdersFinishLists(_currentUser!.uid),
          builder: (context, asyncSnapshot) {
            if (asyncSnapshot.connectionState == ConnectionState.waiting) {
              return Center(child: _buildLoadingIndicator());
            }

            if (!asyncSnapshot.hasData || asyncSnapshot.data!.isEmpty) {
              return _buildNoDataWidget(
                "Aucune livraison récente",
                subtitle: "Vos missions terminées apparaîtront ici",
              );
            }

            final orders = asyncSnapshot.data!;

            return ListView.builder(
              itemCount: orders.length,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                final orderItem = orders[index];
                final statusInfo = _getStatusInfo(orderItem.status);

                return InkWell(
                  onTap: () {
                    Get.to(
                      () => OrderStep(
                        status: orderItem.status,
                        orderId: orderItem.uid!,
                        amount: orderItem.amount,
                        carId: '',
                        userCreatedId: orderItem.userRef!.id,
                        managerRef: orderItem.managerRef,
                        deliverRef: orderItem.deliverRef,
                      ),
                    );
                  },
                  child: Card(
                    elevation: 2,
                    margin: EdgeInsets.only(bottom: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.green.shade50, Colors.green.shade100],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Mission #${orderItem.orderId}',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: statusInfo['color'].withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: statusInfo['color'] as Color,
                                  ),
                                ),
                                child: Text(
                                  statusInfo['text'],
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: statusInfo['color'] as Color,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                DateFormat(
                                  'dd/MM/yyyy',
                                ).format(orderItem.createdAt.toDate()),
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                              Text(
                                '${orderItem.amount.toInt()} FCFA',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: _successColor,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Distance: ${orderItem.distance.toStringAsFixed(1)} Km',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }

  Widget _buildTransactionHistorySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.receipt_long_rounded, color: _primaryColor, size: 20),
            SizedBox(width: 8),
            Text(
              'Historique des transactions',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: THelperFunctions.isDarkMode(context)
                    ? ColorApp.tWhiteColor
                    : ColorApp.tBlackColor,
              ),
            ),
          ],
        ),
        SizedBox(height: 16),
        StreamBuilder<List<TransactionModel>>(
          stream: getTransactions(_currentUser!.uid),
          builder: (context, asyncSnapshot) {
            if (asyncSnapshot.connectionState == ConnectionState.waiting) {
              return Center(child: _buildLoadingIndicator());
            }

            if (!asyncSnapshot.hasData || asyncSnapshot.data!.isEmpty) {
              return _buildNoDataWidget(
                "Aucune transaction",
                subtitle: "Vos transactions apparaîtront ici",
              );
            }

            final transactions = asyncSnapshot.data!;

            return ListView.builder(
              itemCount: transactions.length,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                final transactionItem = transactions[index];
                return _buildTransactionItem(transactionItem);
              },
            );
          },
        ),
      ],
    );
  }

  Widget _buildTransactionItem(TransactionModel transaction) {
    Color statusColor = Colors.grey;
    String statusText = "En attente";

    switch (transaction.status) {
      case "completed":
        statusColor = _successColor;
        statusText = "Terminée";
        break;
      case "failed":
        statusColor = _errorColor;
        statusText = "Échouée";
        break;
      case "pending":
        statusColor = _warningColor;
        statusText = "En attente";
        break;
    }

    return Card(
      elevation: 2,
      margin: EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                transaction.type == "payment"
                    ? Icons.arrow_downward_rounded
                    : Icons.arrow_upward_rounded,
                color: statusColor,
                size: 20,
              ),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    transaction.type == "payment" ? "Revenu" : "Retrait",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    DateFormat(
                      'dd/MM/yyyy à HH:mm',
                    ).format(transaction.createdAt.toDate()),
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  ),
                  SizedBox(height: 4),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      statusText,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: statusColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Text(
              "${transaction.type == "payment" ? '+' : '-'} ${transaction.amount.toStringAsFixed(2)} FCFA",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: transaction.type == "payment"
                    ? _successColor
                    : _errorColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_currentUser == null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.error_outline, size: 64, color: _errorColor),
              SizedBox(height: 16),
              Text(
                'Utilisateur non connecté',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      body: Stack(
        children: [
          SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  // Header Card
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [_primaryColor, _secondaryColor],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: _primaryColor.withOpacity(0.3),
                            blurRadius: 15,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Bonjour,',
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.white.withOpacity(0.9),
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    widget.userFullName,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(25),
                                ),
                                child: Icon(
                                  Icons.delivery_dining_rounded,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 20),
                          Text(
                            'Solde disponible',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.white.withOpacity(0.8),
                            ),
                          ),
                          SizedBox(height: 8),
                          StreamBuilder(
                            stream: getUserBalance(_currentUser!.uid),
                            builder: (context, asyncSnapshot) {
                              final balance = asyncSnapshot.data ?? 0.0;
                              return Text(
                                '${balance.toInt()} FCFA',
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 20),

                  // Statistics Grid
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildStatCard(
                        title: "Gains du jour",
                        stream: getUserBalanceToday(_currentUser!.uid),
                        color: Colors.green,
                        icon: Icons.today_rounded,
                        defaultValue: "0",
                        isCurrency: true,
                      ),
                      _buildStatCard(
                        title: "Courses du jour",
                        stream: getOrderFinishTodayTotal(_currentUser!.uid),
                        color: Colors.blue,
                        icon: Icons.local_shipping_rounded,
                        defaultValue: "0",
                      ),
                    ],
                  ),
                  SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildStatCard(
                        title: "En cours",
                        stream: getOrderPendingTotal(_currentUser!.uid),
                        color: Colors.orange,
                        icon: Icons.pending_actions_rounded,
                        defaultValue: "0",
                      ),
                      _buildStatCard(
                        title: "Total terminées",
                        stream: getOrderFinishTotal(_currentUser!.uid),
                        color: Colors.purple,
                        icon: Icons.check_circle_outline_rounded,
                        defaultValue: "0",
                      ),
                    ],
                  ),

                  SizedBox(height: 24),
                  _buildCurrentDeliverySection(),
                  SizedBox(height: 24),
                  _buildRecentDeliveriesSection(),
                  SizedBox(height: 24),
                  _buildTransactionHistorySection(),
                  SizedBox(height: 20),
                ],
              ),
            ),
          ),
          ConfettiWidget(
            confettiController: _confettiController,
            blastDirectionality: BlastDirectionality.explosive,
            shouldLoop: false,
            colors: const [
              Colors.green,
              Colors.blue,
              Colors.orange,
              Colors.pink,
            ],
          ),
        ],
      ),
    );
  }
}
