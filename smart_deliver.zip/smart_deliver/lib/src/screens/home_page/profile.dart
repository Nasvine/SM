import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/constants/images.dart';
import 'package:smart_deliver/src/constants/sizes.dart';
import 'package:smart_deliver/src/controllers/auth/avis_contoller.dart';
import 'package:smart_deliver/src/models/auth/user_model.dart';
import 'package:smart_deliver/src/repository/authentification_repository.dart';
import 'package:smart_deliver/src/repository/user_repository.dart';
import 'package:smart_deliver/src/screens/auth/login_screen.dart';
import 'package:smart_deliver/src/screens/auth/update_profile_screen.dart';
import 'package:smart_deliver/src/screens/gain.dart';
import 'package:smart_deliver/src/screens/home_page/settings_screen.dart';
import 'package:smart_deliver/src/screens/settings/about_page.dart';
import 'package:smart_deliver/src/screens/settings/policy_page.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:lottie/lottie.dart';
import 'package:confetti/confetti.dart';

final _auth = FirebaseAuth.instance.currentUser!;

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.userFullName,
    required this.userEmail,
  });

  final String userFullName;
  final String userEmail;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final repository = Get.put(AuthentificationRepository());
  final user_repository = Get.put(UserRepository());
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  late ConfettiController _confettiController;

  // Couleurs personnalisées
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: Duration(seconds: 3));
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  Future<void> deleteUserAccount() async {
    final user = FirebaseAuth.instance.currentUser;

    if (user != null) {
      final uid = user.uid;

      try {
        // Supprimer les données de Firestore (ex: collection users)
        await FirebaseFirestore.instance.collection('users').doc(uid).delete();

        // Supprimer le compte de Firebase Auth
        await user.delete();
      } on FirebaseAuthException catch (e) {
        if (e.code == 'requires-recent-login') {
          // Il faut réauthentifier l'utilisateur
          throw FirebaseAuthException(
            code: 'requires-recent-login',
            message: 'Vous devez vous reconnecter pour supprimer votre compte.',
          );
        } else {
          rethrow;
        }
      }
    }
  }

  void showAvisModal(BuildContext context) async {
    final AvisController avisController = Get.put(AvisController());
    await avisController.loadUserAvis();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: THelperFunctions.isDarkMode(context) ? Colors.grey.shade900 : Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(25),
              topRight: Radius.circular(25),
            ),
          ),
          child: Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
              left: 24,
              right: 24,
              top: 32,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  avisController.existingAvisDoc != null
                      ? "Modifier votre avis"
                      : "Donnez votre avis",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: THelperFunctions.isDarkMode(context) ? Colors.white : Colors.black87,
                  ),
                ),
                SizedBox(height: 24),

                // ⭐ Étoiles avec animation
                Obx(
                  () => Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(5, (index) {
                          return IconButton(
                            onPressed: () =>
                                avisController.selectedStars.value = index + 1,
                            icon: Icon(
                              index < avisController.selectedStars.value
                                  ? Icons.star_rounded
                                  : Icons.star_border_rounded,
                              color: Colors.amber,
                              size: 36,
                            ),
                          );
                        }),
                      ),
                      SizedBox(height: 8),
                      Text(
                        '${avisController.selectedStars.value}/5 étoiles',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 24),

                // 💬 Commentaire
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: THelperFunctions.isDarkMode(context) ? Colors.grey.shade800 : Colors.grey.shade100,
                  ),
                  child: TextField(
                    controller: avisController.commentController,
                    maxLines: 4,
                    decoration: InputDecoration(
                      hintText: "Partagez votre expérience... (optionnel)",
                      hintStyle: TextStyle(
                        color: Colors.grey.shade500,
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.all(16),
                    ),
                  ),
                ),

                SizedBox(height: 24),

                // 📤 Bouton d'envoi
                Container(
                  width: double.infinity,
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_primaryColor, _secondaryColor],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: _primaryColor.withOpacity(0.3),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: ElevatedButton(
                    onPressed: () {
                      avisController.submitAvis();
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      avisController.existingAvisDoc != null
                          ? "Modifier mon avis"
                          : "Envoyer mon avis",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 16),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildProfileHeader(UserModel user, bool isDark) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF667eea), Color(0xFF764ba2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 15,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        children: [
          // Avatar avec effet de bordure
          Stack(
            children: [
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.3),
                    width: 3,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(60),
                  child: user.profilePicture == null || user.profilePicture!.isEmpty
                      ? Image(
                          image: AssetImage(ImageApp.tCover),
                          fit: BoxFit.cover,
                        )
                      : Image.network(
                          user.profilePicture!,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Image(
                              image: AssetImage(ImageApp.tCover),
                              fit: BoxFit.cover,
                            );
                          },
                        ),
                ),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: _secondaryColor,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                  child: Icon(
                    Icons.verified_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          Text(
            user.fullName,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8),
          Text(
            user.email,
            style: TextStyle(
              fontSize: 16,
              color: Colors.white.withOpacity(0.8),
            ),
            textAlign: TextAlign.center,
          ),
         /*  Container(
            width: 200,
            height: 45,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(25),
              border: Border.all(color: Colors.white.withOpacity(0.3)),
            ),
            child: ElevatedButton(
              onPressed: () => Get.to(() => UpdateUserProfileScreen(user: user)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.edit_rounded, size: 18),
                  SizedBox(width: 8),
                  Text(
                    "Modifier le profil",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ), */
        ],
      ),
    );
  }

  Widget _buildMenuCard({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? iconColor,
    bool isDanger = false,
  }) {
    final isDark = THelperFunctions.isDarkMode(Get.context!);
    
    return Card(
      elevation: 2,
      margin: EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: isDark ? Colors.grey.shade800 : Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: isDanger 
                          ? _errorColor.withOpacity(0.1)
                          : (iconColor ?? _primaryColor).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      icon,
                      color: isDanger ? _errorColor : (iconColor ?? _primaryColor),
                      size: 22,
                    ),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: isDark ? Colors.white : Colors.black87,
                      ),
                    ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: Colors.grey.shade500,
                    size: 16,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/no_data.json',
            height: 120,
            width: 120,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 20),
          Text(
            'Chargement du profil...',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/error.json',
            height: 150,
            width: 150,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 20),
          Text(
            'Erreur de chargement',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: _errorColor,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Impossible de charger les informations du profil',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade600,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  void _showLogoutConfirmation() async {
    final confirm = await showDialog<bool>(
      context: Get.context!,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.logout_rounded, color: _warningColor),
            SizedBox(width: 12),
            Text(
              "Déconnexion",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Text(
          "Voulez-vous vraiment vous déconnecter ?",
          style: TextStyle(fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            style: TextButton.styleFrom(
              foregroundColor: Colors.grey.shade600,
            ),
            child: Text("Annuler"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: _warningColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: Text("Déconnecter"),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await repository.logout();
      } catch (e) {
        Get.snackbar(
          'Erreur',
          'Erreur lors de la déconnexion: $e',
          backgroundColor: _errorColor,
          colorText: Colors.white,
        );
      }
    }
  }

  void _showDeleteAccountConfirmation() async {
    final confirm = await showDialog<bool>(
      context: Get.context!,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.delete_forever_rounded, color: _errorColor),
            SizedBox(width: 12),
            Text(
              "Supprimer le compte",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Cette action est irréversible. Toutes vos données seront définitivement supprimées.",
              style: TextStyle(fontSize: 14),
            ),
            SizedBox(height: 8),
            Text(
              "Êtes-vous absolument sûr ?",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: _errorColor,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            style: TextButton.styleFrom(
              foregroundColor: Colors.grey.shade600,
            ),
            child: Text("Annuler"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: _errorColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: Text("Supprimer"),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await deleteUserAccount();
        Get.offAll(() => LoginScreen());
      } catch (e) {
        if (e is FirebaseAuthException && e.code == 'requires-recent-login') {
          Get.snackbar(
            'Reconnexion requise',
            'Veuillez vous reconnecter pour supprimer votre compte',
            backgroundColor: _warningColor,
            colorText: Colors.white,
          );
        } else {
          Get.snackbar(
            'Erreur',
            'Erreur lors de la suppression: $e',
            backgroundColor: _errorColor,
            colorText: Colors.white,
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = THelperFunctions.isDarkMode(context);

    return Scaffold(
      body: Stack(
        children: [
          StreamBuilder<UserModel>(
            stream: user_repository.fetchUserDetailsRealTime(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return _buildLoadingState();
              } else if (snapshot.hasError) {
                return _buildErrorState();
              } else if (!snapshot.hasData || snapshot.data == UserModel.empty()) {
                return Center(child: Text('Aucun utilisateur trouvé.'));
              } else {
                final user = snapshot.data!;
                return SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildProfileHeader(user, isDark),
                      Padding(
                        padding: EdgeInsets.all(24),
                        child: Column(
                          children: [
                            // Section Compte
                            _buildMenuCard(
                              icon: Icons.person_outline_rounded,
                              title: 'Modifier le profil',
                              onTap: () => Get.to(() => UpdateUserProfileScreen(user: user)),
                              iconColor: Colors.blue,
                            ),
                            
                            _buildMenuCard(
                              icon: Icons.payments_rounded,
                              title: 'Mes gains',
                              onTap: () => Get.to(() => GainScreen()),
                              iconColor: Colors.green,
                            ),

                            _buildMenuCard(
                              icon: Icons.settings_rounded,
                              title: 'Paramètres',
                              onTap: () => Get.to(() => SettingsScreen()),
                              iconColor: Colors.purple,
                            ),

                            // Section Informations
                            _buildMenuCard(
                              icon: Icons.info_outline_rounded,
                              title: 'À propos',
                              onTap: () => Get.to(() => AboutOwnerPage()),
                              iconColor: Colors.blue,
                            ),

                            _buildMenuCard(
                              icon: Icons.privacy_tip_rounded,
                              title: 'Politique de confidentialité',
                              onTap: () => Get.to(() => PrivacyPolicyOwnerPage()),
                              iconColor: Colors.indigo,
                            ),

                            _buildMenuCard(
                              icon: Icons.star_rate_rounded,
                              title: 'Donner mon avis',
                              onTap: () => showAvisModal(context),
                              iconColor: Colors.amber,
                            ),

                            // Section Compte
                            _buildMenuCard(
                              icon: Icons.logout_rounded,
                              title: 'Déconnexion',
                              onTap: _showLogoutConfirmation,
                              isDanger: true,
                            ),

                            _buildMenuCard(
                              icon: Icons.delete_forever_rounded,
                              title: 'Supprimer mon compte',
                              onTap: _showDeleteAccountConfirmation,
                              isDanger: true,
                            ),

                            SizedBox(height: 20),
                            Text(
                              'Version 1.0.0',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }
            },
          ),
          ConfettiWidget(
            confettiController: _confettiController,
            blastDirectionality: BlastDirectionality.explosive,
            shouldLoop: false,
            colors: const [Colors.green, Colors.blue, Colors.orange, Colors.pink],
          ),
        ],
      ),
    );
  }
}