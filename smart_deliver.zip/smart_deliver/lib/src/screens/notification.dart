import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/constants/sizes.dart';
import 'package:smart_deliver/src/models/auth/notification_model.dart';
import 'package:smart_deliver/src/screens/tabs.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:lottie/lottie.dart';
import 'package:intl/intl.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  // Couleurs personnalisées
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _infoColor = Colors.blue;

  Stream<List<NotificationModel>> getNotifications(String userId) {
    return FirebaseFirestore.instance
        .collection('notifications')
        .where(
          'receiverRef',
          isEqualTo: FirebaseFirestore.instance.collection("users").doc(userId),
        )
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => NotificationModel.fromSnapshot(doc))
              .toList(),
        );
  }

  // Méthode pour obtenir l'icône et la couleur selon le type de notification
  Map<String, dynamic> _getNotificationTypeInfo(String type) {
    switch (type.toLowerCase()) {
      case 'location':
        return {
          'icon': Icons.local_shipping_rounded,
          'color': _primaryColor,
          'background': _primaryColor.withOpacity(0.1),
        };
      case 'chat':
        return {
          'icon': Icons.chat_bubble_rounded,
          'color': _infoColor,
          'background': _infoColor.withOpacity(0.1),
        };
      case 'platform':
        return {
          'icon': Icons.admin_panel_settings_rounded,
          'color': Colors.purple,
          'background': Colors.purple.withOpacity(0.1),
        };
      case 'payment':
        return {
          'icon': Icons.payments_rounded,
          'color': _successColor,
          'background': _successColor.withOpacity(0.1),
        };
      default:
        return {
          'icon': Icons.notifications_rounded,
          'color': _warningColor,
          'background': _warningColor.withOpacity(0.1),
        };
    }
  }

  Widget _buildNotificationItem(NotificationModel notification, bool isDark) {
    final typeInfo = _getNotificationTypeInfo(notification.type);
    final timeAgo = _getTimeAgo(notification.createdAt);

    return Container(
      margin: EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: isDark ? Colors.grey.shade800 : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: isDark ? Colors.grey.shade700 : Colors.grey.shade200,
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            // Marquer comme lu si ce n'est pas déjà fait
            if (!notification.isRead) {
              _markAsRead(notification);
            }
          },
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Icône de notification
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: typeInfo['background'],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    typeInfo['icon'],
                    color: typeInfo['color'],
                    size: 24,
                  ),
                ),
                SizedBox(width: 16),
                
                // Contenu de la notification
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              notification.title,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: isDark ? Colors.white : Colors.black87,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (!notification.isRead)
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: _primaryColor,
                                shape: BoxShape.circle,
                              ),
                            ),
                        ],
                      ),
                      SizedBox(height: 6),
                      Text(
                        notification.message,
                        style: TextStyle(
                          fontSize: 14,
                          color: isDark ? Colors.grey.shade400 : Colors.grey.shade700,
                          height: 1.4,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            Icons.access_time_rounded,
                            size: 12,
                            color: Colors.grey.shade500,
                          ),
                          SizedBox(width: 4),
                          Text(
                            timeAgo,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade500,
                            ),
                          ),
                          Spacer(),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: typeInfo['color'].withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              _getTypeLabel(notification.type),
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: typeInfo['color'],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _getTypeLabel(String type) {
    switch (type.toLowerCase()) {
      case 'location': return 'Livraison';
      case 'chat': return 'Message';
      case 'platform': return 'Système';
      case 'payment': return 'Paiement';
      default: return type;
    }
  }

  String _getTimeAgo(Timestamp timestamp) {
    final now = DateTime.now();
    final time = timestamp.toDate();
    final difference = now.difference(time);

    if (difference.inMinutes < 1) {
      return 'À l\'instant';
    } else if (difference.inHours < 1) {
      return '${difference.inMinutes} min';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} h';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} j';
    } else {
      return DateFormat('dd/MM/yyyy').format(time);
    }
  }

  Future<void> _markAsRead(NotificationModel notification) async {
    try {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(notification.uid)
          .update({'isRead': true});
    } catch (e) {
      print('Erreur lors du marquage comme lu: $e');
    }
  }

  Future<void> _markAllAsRead() async {
    try {
      final unreadNotifications = await FirebaseFirestore.instance
          .collection('notifications')
          .where(
            'receiverRef',
            isEqualTo: FirebaseFirestore.instance
                .collection("users")
                .doc(FirebaseAuth.instance.currentUser!.uid),
          )
          .where('isRead', isEqualTo: false)
          .get();

      final batch = FirebaseFirestore.instance.batch();
      for (final doc in unreadNotifications.docs) {
        batch.update(doc.reference, {'isRead': true});
      }
      await batch.commit();

      Get.snackbar(
        'Succès',
        'Toutes les notifications ont été marquées comme lues',
        backgroundColor: _successColor,
        colorText: Colors.white,
      );
    } catch (e) {
      Get.snackbar(
        'Erreur',
        'Impossible de marquer toutes les notifications comme lues',
        backgroundColor: _warningColor,
        colorText: Colors.white,
      );
    }
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/no_data.json',
            height: 120,
            width: 120,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 20),
          Text(
            'Chargement des notifications...',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(bool isDark) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/no_notifications.json',
            height: 200,
            width: 200,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 20),
          Text(
            'Aucune notification',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: isDark ? Colors.white : Colors.grey.shade700,
            ),
          ),
          SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'Vous serez notifié ici des nouvelles missions et messages importants',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderSection(int unreadCount, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
         /*  Text(
            'Notifications',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: isDark ? Colors.white : Colors.black87,
            ),
          ), */
          if (unreadCount > 0)
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _primaryColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '$unreadCount non lue${unreadCount > 1 ? 's' : ''}',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = THelperFunctions.isDarkMode(context);

    return Scaffold(
      backgroundColor: isDark ? Colors.grey.shade900 : Colors.grey.shade50,
      appBar: AppBar(
        backgroundColor: isDark ? Colors.grey.shade900 : Colors.white,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Get.back(),
          icon: Icon(
            LineAwesomeIcons.angle_left_solid,
            color: isDark ? Colors.white : Colors.black87,
          ),
        ),
        title: Text(
          'Notifications',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: isDark ? Colors.white : Colors.black87,
          ),
        ),
        centerTitle: true,
        actions: [
          StreamBuilder<List<NotificationModel>>(
            stream: getNotifications(FirebaseAuth.instance.currentUser!.uid),
            builder: (context, snapshot) {
              final unreadCount = snapshot.hasData 
                  ? snapshot.data!.where((n) => !n.isRead).length 
                  : 0;
              
              if (unreadCount > 0) {
                return IconButton(
                  onPressed: _markAllAsRead,
                  icon: Icon(Icons.mark_email_read_rounded),
                  tooltip: 'Marquer tout comme lu',
                );
              }
              return SizedBox();
            },
          ),
        ],
      ),
      body: StreamBuilder<List<NotificationModel>>(
        stream: getNotifications(FirebaseAuth.instance.currentUser!.uid),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return _buildLoadingState();
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return _buildEmptyState(isDark);
          }

          final notifications = snapshot.data!;
          final unreadCount = notifications.where((n) => !n.isRead).length;

          return Column(
            children: [
              _buildHeaderSection(unreadCount, isDark),
              SizedBox(height: 16),
              Expanded(
                child: ListView.builder(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  itemCount: notifications.length,
                  itemBuilder: (context, index) {
                    return _buildNotificationItem(notifications[index], isDark);
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}