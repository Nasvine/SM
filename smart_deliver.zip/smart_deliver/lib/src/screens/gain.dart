import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/constants/sizes.dart';
import 'package:smart_deliver/src/models/transactions/transaction_model.dart';
import 'package:smart_deliver/src/screens/tabs.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:text_custom/text_custom.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';


class GainScreen extends StatefulWidget {
  const GainScreen({super.key});

  @override
  State<GainScreen> createState() => _GainScreenState();
}

class _GainScreenState extends State<GainScreen> {
  Stream<List<TransactionModel>> getTransactions(String userId) {
    return FirebaseFirestore.instance
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => TransactionModel.fromSnapshot(doc))
              .toList(),
        );
  }

  Stream<double> getUserBalance(String userId) {
    return FirebaseFirestore.instance
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .where('status', isEqualTo: 'completed')
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return 0.0;

          double totalPayments = 0;
          double totalWithdrawals = 0;

          for (var doc in snapshot.docs) {
            final data = doc.data();
            final amount = (data['amount'] as num).toDouble();
            final type = data['type'];

            if (type == 'payment') {
              totalPayments += amount;
            } else if (type == 'withdrawal') {
              totalWithdrawals += amount;
            }
          }

          return totalPayments - totalWithdrawals;
        });
  }

  Stream<double> getWithdrawalsBalance(String userId) {
    return FirebaseFirestore.instance
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .where('status', isEqualTo: 'completed')
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return 0.0;

          double totalWithdrawals = 0;

          for (var doc in snapshot.docs) {
            final data = doc.data();
            final amount = (data['amount'] as num).toDouble();
            final type = data['type'];

            if (type == 'withdrawal') {
              totalWithdrawals += amount;
            }
          }

          return totalWithdrawals;
        });
  }

  String _formatAmount(double amount) {
    return '${amount.toStringAsFixed(0)} F';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = THelperFunctions.isDarkMode(context);
    
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        leading: IconButton(
          onPressed: () => Get.offAll(() => TabsScreen(initialIndex: 3)),
          icon: Icon(
            LineAwesomeIcons.angle_left_solid,
            color: isDark ? ColorApp.tWhiteColor : ColorApp.tBlackColor,
            size: 24,
          ),
        ),
        title: Text(
          'Mes Gains',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: isDark ? ColorApp.tWhiteColor : ColorApp.tBlackColor,
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Carte principale des gains
              _buildBalanceCard(context),
              
              const SizedBox(height: 24),
              
              // Résumé des gains
              _buildSummarySection(context),
              
              const SizedBox(height: 24),
              
              // Historique des transactions
              _buildTransactionHistory(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBalanceCard(BuildContext context) {
    final isDark = THelperFunctions.isDarkMode(context);
    
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            ColorApp.tPrimaryColor.withOpacity(0.9),
            Color(0xFFFE9003).withOpacity(0.8),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Solde Disponible',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  StreamBuilder(
                    stream: getUserBalance(FirebaseAuth.instance.currentUser!.uid),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return _buildShimmerLoader();
                      }
                      
                      final balance = snapshot.data ?? 0.0;
                      return Text(
                        _formatAmount(balance),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                        ),
                      );
                    },
                  ),
                ],
              ),
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Icon(
                  Icons.account_balance_wallet,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            height: 1,
            color: Colors.white.withOpacity(0.3),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildInfoItem('Gains totaux', Icons.trending_up, Colors.white),
              _buildInfoItem('Retraits', Icons.trending_down, Colors.white),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(String text, IconData icon, Color color) {
    return Row(
      children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 6),
        Text(
          text,
          style: TextStyle(
            color: color.withOpacity(0.8),
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildSummarySection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Résumé des gains',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: THelperFunctions.isDarkMode(context) 
                ? ColorApp.tWhiteColor 
                : ColorApp.tBlackColor,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildSummaryCard(
                title: 'Disponibles',
                amountStream: getUserBalance(FirebaseAuth.instance.currentUser!.uid),
                icon: Icons.check_circle,
                color: Colors.green,
                backgroundColor: Colors.green.withOpacity(0.1),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildSummaryCard(
                title: 'Retraits',
                amountStream: getWithdrawalsBalance(FirebaseAuth.instance.currentUser!.uid),
                icon: Icons.account_balance_wallet,
                color: Colors.orange,
                backgroundColor: Colors.orange.withOpacity(0.1),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSummaryCard({
    required String title,
    required Stream<double> amountStream,
    required IconData icon,
    required Color color,
    required Color backgroundColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(height: 12),
          StreamBuilder(
            stream: amountStream,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return _buildShimmerLoader();
              }
              
              final amount = snapshot.data ?? 0.0;
              return Text(
                _formatAmount(amount),
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              );
            },
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              color: color.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionHistory(BuildContext context) {
    final isDark = THelperFunctions.isDarkMode(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Historique des transactions',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDark ? ColorApp.tWhiteColor : ColorApp.tBlackColor,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: ColorApp.tPrimaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: StreamBuilder(
                stream: getTransactions(FirebaseAuth.instance.currentUser!.uid),
                builder: (context, snapshot) {
                  final count = snapshot.hasData ? snapshot.data!.length : 0;
                  return Text(
                    '$count',
                    style: TextStyle(
                      fontSize: 12,
                      color: ColorApp.tPrimaryColor,
                      fontWeight: FontWeight.w500,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        StreamBuilder(
          stream: getTransactions(FirebaseAuth.instance.currentUser!.uid),
          builder: (context, asyncSnapshot) {
            if (asyncSnapshot.connectionState == ConnectionState.waiting) {
              return _buildLoadingTransactions();
            }

            if (!asyncSnapshot.hasData || asyncSnapshot.data!.isEmpty) {
              return _buildEmptyState();
            }

            final transactions = asyncSnapshot.data!;

            return ListView.separated(
              itemCount: transactions.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              separatorBuilder: (context, index) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final transaction = transactions[index];
                return _buildTransactionItem(transaction, isDark);
              },
            );
          },
        ),
      ],
    );
  }

  Widget _buildTransactionItem(TransactionModel transaction, bool isDark) {
    final isPayment = transaction.type == 'payment';
    final isCompleted = transaction.status == 'completed';
    final isPending = transaction.status == 'pending';
    final isFailed = transaction.status == 'failed';

    Color statusColor = Colors.grey;
    if (isCompleted) statusColor = Colors.green;
    if (isFailed) statusColor = Colors.red;
    if (isPending) statusColor = Colors.orange;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey[800] : Colors.grey[50],
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? Colors.grey[700]! : Colors.grey[200]!,
        ),
      ),
      child: Row(
        children: [
          // Icon avec fond coloré
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isPayment 
                  ? Colors.green.withOpacity(0.2)
                  : Colors.orange.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              isPayment ? Icons.arrow_downward : Icons.arrow_upward,
              color: isPayment ? Colors.green : Colors.orange,
              size: 20,
            ),
          ),
          
          const SizedBox(width: 12),
          
          // Détails de la transaction
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isPayment ? 'Revenu' : 'Retrait',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: isDark ? Colors.white : Colors.black,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  DateFormat('dd MMM yyyy - HH:mm').format(transaction.createdAt.toDate()),
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    transaction.status,
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // Montant
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${isPayment ? '+' : '-'} ${transaction.amount.toStringAsFixed(2)} F',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: isPayment ? Colors.green : Colors.red,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Ref: ${transaction.reference.substring(0, 8)}...',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 10,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        children: [
          Lottie.asset(
            height: 200,
            width: 200,
            'assets/images/no_data.json',
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 16),
          Text(
            'Aucune transaction récente',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Vos transactions apparaîtront ici',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingTransactions() {
    return Column(
      children: List.generate(3, (index) => _buildShimmerTransactionItem()),
    );
  }

  Widget _buildShimmerTransactionItem() {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Colors.grey[400],
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 80,
                  height: 16,
                  color: Colors.grey[400],
                ),
                const SizedBox(height: 8),
                Container(
                  width: 120,
                  height: 12,
                  color: Colors.grey[400],
                ),
              ],
            ),
          ),
          Container(
            width: 60,
            height: 20,
            color: Colors.grey[400],
          ),
        ],
      ),
    );
  }

  Widget _buildShimmerLoader() {
    return Container(
      width: 100,
      height: 32,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }
}