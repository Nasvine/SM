import 'package:smart_deliver/src/constants/colors.dart';
import 'package:smart_deliver/src/models/auth/notification_model.dart';
import 'package:smart_deliver/src/repository/authentification_repository.dart';
import 'package:smart_deliver/src/screens/chat/chat_list_screen.dart';
import 'package:smart_deliver/src/screens/drawer/drawer_listTile.dart';
import 'package:smart_deliver/src/screens/home_page/home.dart';
import 'package:smart_deliver/src/screens/home_page/profile.dart';
import 'package:smart_deliver/src/screens/notification.dart';
import 'package:smart_deliver/src/screens/orders/orders.dart';
import 'package:smart_deliver/src/utils/helpers/helper_function.dart';
import 'package:smart_deliver/src/utils/widget_theme/circle_icon_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:line_icons/line_icons.dart';
import 'package:badges/badges.dart' as badges;
import 'package:lottie/lottie.dart';

class TabsScreen extends StatefulWidget {
  const TabsScreen({super.key, this.initialIndex = 0});
  final int initialIndex;

  @override
  State<TabsScreen> createState() => _TabsScreenState();
}

class _TabsScreenState extends State<TabsScreen> {
  final controller = Get.put(TabsScreenController());

  // Couleurs personnalisées
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;

  Stream<int> getNotificationTotal(String userId) {
    return FirebaseFirestore.instance
        .collection('notifications')
        .where(
          'receiverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('isRead', isEqualTo: false)
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Widget _buildAppBarTitle(int index) {
    final titles = {
      0: 'Tableau de Bord',
      1: 'Mes Missions',
      2: 'Messages',
      3: 'Mon Profil',
    };

    return Text(
      titles[index] ?? 'SmartDeliver',
      style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: THelperFunctions.isDarkMode(Get.context!) ? Colors.white : Colors.black87,
      ),
    );
  }

  Widget _buildNotificationBadge() {
    return StreamBuilder<int>(
      stream: getNotificationTotal(FirebaseAuth.instance.currentUser!.uid),
      builder: (context, snapshot) {
        final count = snapshot.data ?? 0;
        
        return badges.Badge(
          showBadge: count > 0,
          badgeContent: Text(
            count > 99 ? '99+' : count.toString(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          badgeStyle: badges.BadgeStyle(
            badgeColor: _primaryColor,
            padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: THelperFunctions.isDarkMode(Get.context!) 
                  ? Colors.grey.shade800 
                  : Colors.grey.shade100,
              shape: BoxShape.circle,
            ),
            child: IconButton(
              onPressed: () async {
                // Marquer toutes les notifications comme lues
                final notifications = await FirebaseFirestore.instance
                    .collection('notifications')
                    .where(
                      'receiverRef',
                      isEqualTo: FirebaseFirestore.instance
                          .collection('users')
                          .doc(FirebaseAuth.instance.currentUser!.uid),
                    )
                    .where('isRead', isEqualTo: false)
                    .get();

                for (final doc in notifications.docs) {
                  await FirebaseFirestore.instance
                      .collection('notifications')
                      .doc(doc.id)
                      .update({'isRead': true});
                }
                
                Get.to(() => NotificationScreen());
              },
              icon: Icon(
                Icons.notifications_outlined,
                color: THelperFunctions.isDarkMode(Get.context!) 
                    ? Colors.white 
                    : Colors.grey.shade700,
                size: 22,
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildBottomNavigationBar(bool isDark) {
    return Container(
      decoration: BoxDecoration(
        color: isDark ? Colors.grey.shade900 : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 1,
          ),
        ],
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12),
          child: GNav(
            rippleColor: _primaryColor.withOpacity(0.1),
            hoverColor: _primaryColor.withOpacity(0.1),
            gap: 8,
            activeColor: Colors.white,
            iconSize: 24,
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            duration: Duration(milliseconds: 400),
            tabBackgroundColor: _primaryColor,
            color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
            tabs: [
              GButton(
                icon: LineIcons.home,
                text: 'Accueil',
                textStyle: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              GButton(
                icon: Icons.local_shipping_outlined,
                text: 'Missions',
                textStyle: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              GButton(
                icon: LineIcons.comments,
                text: 'Chats',
                textStyle: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              GButton(
                icon: LineIcons.user,
                text: 'Profil',
                textStyle: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
            selectedIndex: controller._selectedIndex.value,
            onTabChange: (index) {
              controller._selectedIndex.value = index;
            },
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/loading.json',
            height: 120,
            width: 120,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 20),
          Text(
            'Chargement...',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> _onWillPop() async {
    final shouldExit = await showDialog<bool>(
      context: Get.context!,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.exit_to_app_rounded,
                size: 48,
                color: _warningColor,
              ),
              SizedBox(height: 16),
              Text(
                "Quitter l'application",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 12),
              Text(
                "Voulez-vous vraiment quitter SmartDeliver ?",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade600,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(false),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.grey.shade600,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text("Annuler"),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(context).pop(true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _primaryColor,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text("Quitter"),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    return shouldExit ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = THelperFunctions.isDarkMode(context);
    controller._selectedIndex.value = widget.initialIndex;

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: isDark ? Colors.grey.shade900 : Colors.grey.shade50,
        appBar: AppBar(
          backgroundColor: isDark ? Colors.grey.shade900 : Colors.white,
          elevation: 0,
          title: Obx(() => _buildAppBarTitle(controller._selectedIndex.value)),
          // centerTitle: true,
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: _buildNotificationBadge(),
            ),
          ],
        ),
        body: Obx(() {
          if (controller.user.isEmpty) {
            return _buildLoadingState();
          }

          return AnimatedSwitcher(
            duration: Duration(milliseconds: 300),
            child: Container(
              key: ValueKey(controller._selectedIndex.value),
              child: controller.screens[controller._selectedIndex.value],
            ),
          );
        }),
        bottomNavigationBar: Obx(() => _buildBottomNavigationBar(isDark)),
      ),
    );
  }
}

class TabsScreenController extends GetxController {
  static TabsScreenController get to => Get.find();

  final _selectedIndex = 0.obs;
  final userConnectName = ''.obs;
  final user = <String, dynamic>{}.obs;
  final auth = FirebaseAuth.instance.currentUser!;
  RxBool accountVerified = false.obs;

  @override
  void onInit() {
    super.onInit();
    _getUserInfo();
  }

  void _getUserInfo() async {
    try {
      final data = await AuthentificationRepository.instance.getUserInfo(auth.uid);
      if (data.isNotEmpty) {
        user.value = data;
        userConnectName.value = data['fullName'];
        List<String> parts = userConnectName.value.trim().split(" ");
        userConnectName.value = parts.length >= 2 ? parts[1] : parts.first;
      }
    } catch (e) {
      print('Erreur lors du chargement des données utilisateur: $e');
    }
  }

  List<Widget> get screens => [
        HomeScreen(
          userFullName: user['fullName'] ?? 'Livreur',
          userEmail: user['email'] ?? '',
        ),
        OrdersScreen(),
        ChatListScreen(),
        ProfileScreen(
          userFullName: user['fullName'] ?? 'Livreur',
          userEmail: user['email'] ?? '',
        ),
      ];
}