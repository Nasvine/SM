


 import 'package:flutter/material.dart';

class ActionTypeEnum{
  static const String Location = "Location";
  static const String Vente = "Vente";
}