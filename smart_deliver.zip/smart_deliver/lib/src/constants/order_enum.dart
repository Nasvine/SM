


 import 'package:flutter/material.dart';

class OrderSatus{
  static const String NewOrder = "NewOrder";
  static const String Pending = "Pending";
  static const String Finish = "Finish";
}