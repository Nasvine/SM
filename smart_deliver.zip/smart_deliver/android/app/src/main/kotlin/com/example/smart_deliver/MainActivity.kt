package com.example.smart_deliver

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
