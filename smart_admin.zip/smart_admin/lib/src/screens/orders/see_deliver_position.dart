import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:smart_admin/notification_services.dart';
import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/models/auth/notification_model.dart';
import 'package:smart_admin/src/models/auth/user_model.dart';
import 'package:smart_admin/src/models/order_model.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:smart_admin/src/utils/texts/text_custom.dart';

/* import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:smart_admin/notification_services.dart';
import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/models/auth/notification_model.dart';
import 'package:smart_admin/src/models/auth/user_model.dart';
import 'package:smart_admin/src/models/order_model.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:smart_admin/src/utils/texts/text_custom.dart';
import 'package:lottie/lottie.dart'; 
*/

class SeeDeliverPositionScreen extends StatefulWidget {
  const SeeDeliverPositionScreen({
    super.key,
    required this.startLocation,
    required this.orderId,
    required this.clientId,
  });

  final PlaceLocation startLocation;
  final String orderId;
  final String clientId;

  @override
  State<SeeDeliverPositionScreen> createState() =>
      _SeeDeliverPositionScreenState();
}

class _SeeDeliverPositionScreenState extends State<SeeDeliverPositionScreen> {
  final firebase = FirebaseFirestore.instance;
  UserModel clientInfo = UserModel.empty();
  OrderModel orderData = OrderModel.empty();
  GoogleMapController? _mapController;
  List<Map<String, dynamic>> _deliverers = [];
  bool _loading = true;
  bool _isAssigning = false;

  // Couleurs personnalisées pour le design
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _infoColor = Colors.blue;

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  void _initializeData() async {
    await Future.wait<void>([
      _fetchDeliverers(),
      _getClientInfo(),
    ]);
  }

  Stream<OrderModel> fetchOrderDetails() {
    return FirebaseFirestore.instance
        .collection('orders')
        .doc(widget.orderId)
        .snapshots()
        .map((snapshot) => OrderModel.fromSnapshot(snapshot));
  }

  Future<void> _getClientInfo() async {
    try {
      final data = await firebase.collection("users").doc(widget.clientId).get();
      if (data.exists) {
        final client = UserModel.fromSnapshot(data);
        setState(() {
          clientInfo = client;
        });
      }
    } catch (e) {
      print('Error fetching client info: $e');
    }
  }

  double _calculateDistanceBetween(
    double lat1,
    double lon1,
    double lat2,
    double lon2,
  ) {
    const p = 0.017453292519943295;
    final a =
        0.5 -
        cos((lat2 - lat1) * p) / 2 +
        cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a));
  }

  Future<void> _fetchDeliverers() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection("users")
          .where("userRole", isEqualTo: "Deliver")
          .get();

      final List<Map<String, dynamic>> deliverers = [];

      for (var doc in snapshot.docs) {
        final data = doc.data();
        if (data.containsKey("geopoint") && data["geopoint"] is GeoPoint) {
          final GeoPoint gp = data["geopoint"];
          final distance = _calculateDistanceBetween(
            widget.startLocation.latitude,
            widget.startLocation.longitude,
            gp.latitude,
            gp.longitude,
          );

          deliverers.add({
            "id": doc.id,
            "ref": doc.reference,
            "name": data["fullName"] ?? "Sans nom",
            "latitude": gp.latitude,
            "longitude": gp.longitude,
            "distance": distance,
            "fcmToken": data["fcmToken"] ?? "",
            "isAvailable": data["isAvailable"] ?? false,
          });
        }
      }

      // Trier par distance croissante
      deliverers.sort((a, b) => a["distance"].compareTo(b["distance"]));

      setState(() {
        _deliverers = deliverers;
        _loading = false;
      });
    } catch (e) {
      debugPrint("Erreur récupération livreurs: $e");
      setState(() => _loading = false);
    }
  }

  Widget _buildMapSection() {
    final LatLng startLatLng = LatLng(
      widget.startLocation.latitude,
      widget.startLocation.longitude,
    );

    final markers = <Marker>{
      Marker(
        markerId: const MarkerId("start"),
        position: startLatLng,
        infoWindow: InfoWindow(
          title: "Point de départ",
          snippet: widget.startLocation.address,
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      ),
      ..._deliverers.map(
        (d) => Marker(
          markerId: MarkerId(d["id"]),
          position: LatLng(d["latitude"], d["longitude"]),
          infoWindow: InfoWindow(
            title: d["name"],
            snippet: "${d["distance"].toStringAsFixed(2)} km",
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        ),
      ),
    };

    return Container(
      height: 300,
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: GoogleMap(
          initialCameraPosition: CameraPosition(
            target: startLatLng,
            zoom: 12,
          ),
          markers: markers,
          onMapCreated: (controller) => _mapController = controller,
        ),
      ),
    );
  }

  Widget _buildDelivererCard(Map<String, dynamic> deliverer, OrderModel order) {
    final distance = deliverer["distance"];
    final isAvailable = deliverer["isAvailable"] ?? false;
    final isAssigned = order.isDriverAssigned == true;
    final isThisDelivererAssigned = order.deliverRef?.id == deliverer["id"];

    return Card(
      elevation: 3,
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _primaryColor.withOpacity(0.1),
          ),
          child: Icon(
            Icons.delivery_dining,
            color: _primaryColor,
            size: 24,
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: TextCustom(
                TheText: deliverer["name"],
                TheTextSize: 16,
                TheTextFontWeight: FontWeight.w600,
                TheTextMaxLines: 1
              ),
            ),
            SizedBox(width: 8),
            if (!isAvailable)
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: _warningColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _warningColor.withOpacity(0.3)),
                ),
                child: Text(
                  "Occupé",
                  style: TextStyle(
                    fontSize: 10,
                    color: _warningColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.place, size: 14, color: Colors.grey),
                SizedBox(width: 4),
                Text(
                  "${distance.toStringAsFixed(2)} km",
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                ),
              ],
            ),
            SizedBox(height: 2),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: _getDistanceColor(distance).withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _getDistanceLabel(distance),
                style: TextStyle(
                  fontSize: 10,
                  color: _getDistanceColor(distance),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        trailing: _buildActionButton(deliverer, order, isThisDelivererAssigned),
      ),
    );
  }

  Color _getDistanceColor(double distance) {
    if (distance < 2) return _successColor;
    if (distance < 5) return _warningColor;
    return _errorColor;
  }

  String _getDistanceLabel(double distance) {
    if (distance < 2) return "Très proche";
    if (distance < 5) return "Proche";
    return "Loin";
  }

  Widget _buildActionButton(
      Map<String, dynamic> deliverer, OrderModel order, bool isThisDelivererAssigned) {
    final isAssigned = order.isDriverAssigned == true;
    final isAvailable = deliverer["isAvailable"] ?? false;

    if (isThisDelivererAssigned) {
      return _buildAssignedButton(deliverer);
    } else if (!isAssigned && isAvailable) {
      return _buildAssignButton(deliverer);
    } else if (!isAvailable) {
      return Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.grey.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          "Indisponible",
          style: TextStyle(
            fontSize: 10,
            color: Colors.grey,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    } else {
      return SizedBox.shrink();
    }
  }

  Widget _buildAssignButton(Map<String, dynamic> deliverer) {
    return Container(
      width: 100,
      child: ElevatedButton(
        onPressed: _isAssigning ? null : () => _assignDeliverer(deliverer),
        style: ElevatedButton.styleFrom(
          backgroundColor: _successColor,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding: EdgeInsets.symmetric(vertical: 8),
        ),
        child: _isAssigning
            ? SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.check, size: 16),
                  SizedBox(width: 4),
                  Text(
                    "Assigner",
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildAssignedButton(Map<String, dynamic> deliverer) {
    return Container(
      width: 120,
      child: OutlinedButton(
        onPressed: () => _unassignDeliverer(deliverer),
        style: OutlinedButton.styleFrom(
          foregroundColor: _errorColor,
          side: BorderSide(color: _errorColor),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding: EdgeInsets.symmetric(vertical: 8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.close, size: 16),
            SizedBox(width: 4),
            Text(
              "Désassigner",
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _assignDeliverer(Map<String, dynamic> deliverer) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => _buildConfirmationDialog(
        title: "Assigner la course",
        content: "Voulez-vous assigner cette course à ${deliverer["name"]} ?",
        confirmText: "Assigner",
        confirmColor: _successColor,
        icon: Icons.person_add,
      ),
    );

    if (confirm == true) {
      setState(() => _isAssigning = true);
      
      try {
        await firebase.collection('orders').doc(widget.orderId).update({
          'isDriverAssigned': true,
          'status': "assigned",
          'deliverRef': deliverer['ref'],
          'managerRef': FirebaseFirestore.instance
              .collection("users")
              .doc(FirebaseAuth.instance.currentUser!.uid),
        });

        final notification = NotificationModel(
          senderRef: FirebaseFirestore.instance
              .collection('users')
              .doc(FirebaseAuth.instance.currentUser!.uid),
          receiverRef: deliverer['ref'],
          title: 'Nouvelle Course 🚚',
          message: "Vous avez une nouvelle course de ${clientInfo.fullName}. Veuillez l'accepter.",
          type: "Location",
          isRead: false,
          createdAt: Timestamp.now(),
        );

        await FirebaseFirestore.instance
            .collection('notifications')
            .add(notification.toJson());

        // Notification au livreur
        if (deliverer["fcmToken"] != null && deliverer["fcmToken"].isNotEmpty) {
          NotificationServices().sendPushNotification(
            deviceToken: deliverer["fcmToken"],
            title: "Nouvelle Course 🚚",
            body: "Vous avez une nouvelle course de ${clientInfo.fullName}. Veuillez l'accepter.",
          );
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Course assignée à ${deliverer["name"]}'),
            backgroundColor: _successColor,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erreur lors de l\'assignation: $e'),
            backgroundColor: _errorColor,
          ),
        );
      } finally {
        setState(() => _isAssigning = false);
      }
    }
  }

  Future<void> _unassignDeliverer(Map<String, dynamic> deliverer) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => _buildConfirmationDialog(
        title: "Désassigner la course",
        content: "Voulez-vous désassigner la course de ${deliverer["name"]} ?",
        confirmText: "Désassigner",
        confirmColor: _errorColor,
        icon: Icons.person_remove,
      ),
    );

    if (confirm == true) {
      try {
        await firebase.collection('orders').doc(widget.orderId).update({
          'status': "neworder",
          'deliverRef': null,
          'managerRef': null,
          'isDriverAssigned': false,
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Course désassignée de ${deliverer["name"]}'),
            backgroundColor: _successColor,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erreur lors de la désassignation: $e'),
            backgroundColor: _errorColor,
          ),
        );
      }
    }
  }

  Widget _buildConfirmationDialog({
    required String title,
    required String content,
    required String confirmText,
    required Color confirmColor,
    required IconData icon,
  }) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(25),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: confirmColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 35, color: confirmColor),
            ),
            SizedBox(height: 20),
            Text(
              title,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 15),
            Text(
              content,
              style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 25),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context, false),
                    style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: EdgeInsets.symmetric(vertical: 12),
                      side: BorderSide(color: Colors.grey.shade400),
                    ),
                    child: Text('Annuler', style: TextStyle(color: Colors.grey.shade700)),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: confirmColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text(confirmText),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          /* Lottie.asset(
            'assets/images/search_deliver.json',
            height: 150,
            width: 150,
          ), */
          SizedBox(height: 20),
          Text(
            'Recherche des livreurs...',
            style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          /* Lottie.asset(
            'assets/images/no_deliver.json',
            height: 200,
            width: 200,
          ), */
          SizedBox(height: 20),
          Text(
            'Aucun livreur disponible',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey.shade600),
          ),
          SizedBox(height: 10),
          Text(
            'Aucun livreur n\'est actuellement disponible dans votre zone.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, color: Colors.grey.shade500),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Get.back(),
          icon: Container(
            width: 35,
            height: 35,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _primaryColor.withOpacity(0.1),
            ),
            child: Icon(
              LineAwesomeIcons.angle_left_solid,
              color: _primaryColor,
              size: 20,
            ),
          ),
        ),
        centerTitle: true,
        title: Text(
          "Livreurs Disponibles",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      body: StreamBuilder<OrderModel>(
        stream: fetchOrderDetails(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return _buildLoadingState();
          }

          if (!snapshot.hasData) {
            return _buildEmptyState();
          }

          final order = snapshot.data!;

          return Column(
            children: [
              // Section Carte
              _buildMapSection(),

              // En-tête de la liste
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    Icon(Icons.list, color: _primaryColor, size: 20),
                    SizedBox(width: 8),
                    Text(
                      "Livreurs à proximité (${_deliverers.length})",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: _primaryColor,
                      ),
                    ),
                  ],
                ),
              ),

              // Liste des livreurs
              Expanded(
                child: _loading
                    ? _buildLoadingState()
                    : _deliverers.isEmpty
                        ? _buildEmptyState()
                        : ListView.builder(
                            physics: BouncingScrollPhysics(),
                            itemCount: _deliverers.length,
                            itemBuilder: (context, index) {
                              return _buildDelivererCard(_deliverers[index], order);
                            },
                          ),
              ),
            ],
          );
        },
      ),
    );
  }
}