import 'dart:math';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/models/auth/user_model.dart';
import 'package:smart_admin/src/models/order_model.dart';
import 'package:smart_admin/src/repository/authentification_repository.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:smart_admin/src/utils/texts/text_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';

class OrderDetailScreen extends StatefulWidget {
  const OrderDetailScreen({
    super.key,
    required this.startLocation,
    required this.endLocation,
    required this.userCreatedId,
    required this.orderId,
  });

  final PlaceLocation startLocation;
  final PlaceLocation endLocation;
  final String userCreatedId;
  final String orderId;

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final firebase = FirebaseFirestore.instance;
  OrderModel orderData = OrderModel.empty();
  GoogleMapController? _mapController;
  double _distanceKm = 0.0;
  UserModel clientInfo = UserModel.empty();
  bool _isLoading = true;

  // Couleurs personnalisées pour le design
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _infoColor = Colors.blue;

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  double _calculateDistanceBetween(
    double lat1,
    double lon1,
    double lat2,
    double lon2,
  ) {
    const p = 0.017453292519943295;
    final a =
        0.5 -
        cos((lat2 - lat1) * p) / 2 +
        cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a));
  }

  void _initializeData() async {
    await Future.wait([
      _calculateDistance(),
      _getClientInfo(),
      _fetchOrderDetails(),
    ]);
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _calculateDistance() async {
    _distanceKm = _calculateDistanceBetween(
      widget.startLocation.latitude,
      widget.startLocation.longitude,
      widget.endLocation.latitude,
      widget.endLocation.longitude,
    );
  }

  Future<void> _getClientInfo() async {
    try {
      final data = await firebase
          .collection("users")
          .doc(widget.userCreatedId)
          .get();
      if (data.exists) {
        final client = UserModel.fromSnapshot(data);
        setState(() {
          clientInfo = client;
        });
      }
    } catch (e) {
      print('Error fetching client info: $e');
    }
  }

  Future<void> _fetchOrderDetails() async {
    try {
      final data = await firebase
          .collection('orders')
          .doc(widget.orderId)
          .get();
      if (data.exists) {
        final order = OrderModel.fromSnapshot(data);
        setState(() {
          orderData = order;
        });
      }
    } catch (e) {
      print('Error fetching order details: $e');
    }
  }

  void _callClient() async {
    if (clientInfo.phoneNumber == null || clientInfo.phoneNumber!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Numéro de téléphone non disponible'),
          backgroundColor: _warningColor,
        ),
      );
      return;
    }

    final phoneNumber = "tel:${clientInfo.phoneNumber}";
    final Uri phoneUri = Uri.parse(phoneNumber);

    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Impossible de passer l\'appel'),
          backgroundColor: _warningColor,
        ),
      );
    }
  }

  Widget _buildMapSection() {
    final LatLng startLatLng = LatLng(
      widget.startLocation.latitude,
      widget.startLocation.longitude,
    );
    final LatLng endLatLng = LatLng(
      widget.endLocation.latitude,
      widget.endLocation.longitude,
    );

    return Container(
      height: 250,
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: GoogleMap(
          initialCameraPosition: CameraPosition(
            target: LatLng(
              (startLatLng.latitude + endLatLng.latitude) / 2,
              (startLatLng.longitude + endLatLng.longitude) / 2,
            ),
            zoom: 12,
          ),
          onMapCreated: (controller) => _mapController = controller,
          markers: {
            Marker(
              markerId: const MarkerId("start"),
              position: startLatLng,
              infoWindow: InfoWindow(
                title: "Point de retrait",
                snippet: widget.startLocation.address,
              ),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueGreen,
              ),
            ),
            Marker(
              markerId: const MarkerId("end"),
              position: endLatLng,
              infoWindow: InfoWindow(
                title: "Destination",
                snippet: widget.endLocation.address,
              ),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueRed,
              ),
            ),
          },
          polylines: {
            Polyline(
              polylineId: const PolylineId("route"),
              color: _primaryColor,
              width: 4,
              points: [startLatLng, endLatLng],
            ),
          },
        ),
      ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required String value,
    Color? iconColor,
    Widget? trailing,
    bool isMultiLine = false,
  }) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: Container(
          width: 45,
          height: 45,
          decoration: BoxDecoration(
            color: (iconColor ?? _primaryColor).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: iconColor ?? _primaryColor, size: 22),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: Colors.grey.shade600,
          ),
        ),
        subtitle: isMultiLine
            ? Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text(
                  value.isEmpty ? "Aucune instruction" : value,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: THelperFunctions.isDarkMode(context)
                        ? Colors.white
                        : Colors.black87,
                  ),
                  maxLines: 3,
                ),
              )
            : Text(
                value,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: THelperFunctions.isDarkMode(context)
                      ? Colors.white
                      : Colors.black87,
                ),
              ),
        trailing: trailing,
        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
    );
  }

  Widget _buildClientSection() {
    return Card(
      elevation: 3,
      margin: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _primaryColor.withOpacity(0.1),
                  ),
                  child: Icon(Icons.person, color: _primaryColor, size: 24),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Informations Client",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _primaryColor,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        clientInfo.fullName,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text(
                        clientInfo.phoneNumber ?? "Numéro non disponible",
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),
                if (clientInfo.phoneNumber != null &&
                    clientInfo.phoneNumber!.isNotEmpty)
                  Container(
                    width: 45,
                    height: 45,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _successColor.withOpacity(0.1),
                    ),
                    child: IconButton(
                      onPressed: _callClient,
                      icon: Icon(Icons.phone, color: _successColor, size: 20),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderSummary() {
    return Card(
      elevation: 3,
      margin: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Résumé de la Course",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: _primaryColor,
              ),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildSummaryItem(
                    icon: Icons.attach_money,
                    title: "Prix",
                    value: "${orderData.amount.toInt()} FCFA",
                    color: _successColor,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: _buildSummaryItem(
                    icon: Icons.place,
                    title: "Distance",
                    value: "${orderData.distance.toStringAsFixed(1)} km",
                    color: _infoColor,
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _buildSummaryItem(
                    icon: Icons.local_shipping,
                    title: "Type",
                    value: orderData.deliveryType,
                    color: _warningColor,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: _buildSummaryItem(
                    icon: Icons.schedule,
                    title: "Statut",
                    value: _getStatusText(orderData.status),
                    color: _getStatusColor(orderData.status),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryItem({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 20, color: color),
          SizedBox(height: 8),
          Text(
            title,
            style: TextStyle(
              fontSize: 11,
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: color,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  String _getStatusText(String status) {
    switch (status.toLowerCase()) {
      case 'neworder':
        return 'Nouvelle';
      case 'assigned':
        return 'Assignée';
      case 'accepted':
        return 'Acceptée';
      case 'pending':
        return 'En cours';
      case 'delivered':
        return 'Livrée';
      case 'paymentstep':
        return 'Paiement';
      case 'finish':
        return 'Terminée';
      case 'cancelled':
        return 'Annulée';
      case 'refused':
        return 'Refusée';
      default:
        return status;
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'neworder':
        return Colors.blue;
      case 'assigned':
        return Colors.orange;
      case 'accepted':
        return Colors.lightGreen;
      case 'pending':
        return Colors.amber;
      case 'delivered':
        return Colors.green;
      case 'paymentstep':
        return Colors.purple;
      case 'finish':
        return Colors.teal;
      case 'cancelled':
        return Colors.red;
      case 'refused':
        return Colors.deepOrange;
      default:
        return Colors.grey;
    }
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: _primaryColor),
          SizedBox(height: 16),
          Text(
            'Chargement des détails...',
            style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(appBar: _buildAppBar(), body: _buildLoadingState());
    }

    return Scaffold(
      appBar: _buildAppBar(),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          children: [
            // Section Carte
            _buildMapSection(),

            // Section Client
            _buildClientSection(),

            // Résumé de la course
            _buildOrderSummary(),

            // Informations détaillées
            _buildInfoCard(
              icon: Icons.location_on_outlined,
              title: "Point de retrait",
              value: widget.startLocation.address,
              iconColor: Colors.green,
            ),

            _buildInfoCard(
              icon: Icons.location_pin,
              title: "Destination",
              value: widget.endLocation.address,
              iconColor: Colors.red,
            ),

            _buildInfoCard(
              icon: Icons.message_outlined,
              title: "Instructions du client",
              value: orderData.message ?? "Aucune instruction particulière",
              iconColor: Colors.purple,
              isMultiLine: true,
            ),

            _buildInfoCard(
              icon: Icons.local_shipping_outlined,
              title: "Type de colis",
              value: orderData.deliveryType,
              iconColor: _warningColor,
            ),

            _buildInfoCard(
              icon: Icons.calendar_today_outlined,
              title: "Date de création",
              value: DateFormat(
                'dd/MM/yyyy à HH:mm',
              ).format(orderData.createdAt.toDate()),
              iconColor: Colors.teal,
            ),

            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      leading: IconButton(
        onPressed: () => Get.back(),
        icon: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _primaryColor.withOpacity(0.1),
          ),
          child: Icon(
            LineAwesomeIcons.angle_left_solid,
            color: _primaryColor,
            size: 20,
          ),
        ),
      ),
      centerTitle: true,
      title: Text(
        "Détails de la Course",
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
    );
  }
}
