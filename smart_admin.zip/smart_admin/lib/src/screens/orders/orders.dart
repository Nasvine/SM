import 'package:lottie/lottie.dart';
import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/models/order_model.dart';
import 'package:smart_admin/src/screens/orders/order_step.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:smart_admin/src/utils/texts/text_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  // Configuration des statuts en français avec couleurs et icônes
  final Map<String, Map<String, dynamic>> _statusConfig = {
    'neworder': {
      'text': 'Nouvelle Commande',
      'color': Colors.blue,
      'icon': Icons.new_releases,
      'bgColor': Colors.blue.withOpacity(0.1)
    },
    'assigned': {
      'text': 'Assignée',
      'color': Colors.orange,
      'icon': Icons.assignment_ind,
      'bgColor': Colors.orange.withOpacity(0.1)
    },
    'accepted': {
      'text': 'Acceptée',
      'color': Colors.lightGreen,
      'icon': Icons.check_circle,
      'bgColor': Colors.lightGreen.withOpacity(0.1)
    },
    'pending': {
      'text': 'En Attente',
      'color': Colors.amber,
      'icon': Icons.access_time,
      'bgColor': Colors.amber.withOpacity(0.1)
    },
    'delivered': {
      'text': 'Livrée',
      'color': Colors.green,
      'icon': Icons.local_shipping,
      'bgColor': Colors.green.withOpacity(0.1)
    },
    'paymentstep': {
      'text': 'Paiement',
      'color': Colors.purple,
      'icon': Icons.payment,
      'bgColor': Colors.purple.withOpacity(0.1)
    },
    'finish': {
      'text': 'Terminée',
      'color': Colors.teal,
      'icon': Icons.flag,
      'bgColor': Colors.teal.withOpacity(0.1)
    },
    'cancelled': {
      'text': 'Annulée',
      'color': Colors.red,
      'icon': Icons.cancel,
      'bgColor': Colors.red.withOpacity(0.1)
    },
    'refused': {
      'text': 'Refusée',
      'color': Colors.deepOrange,
      'icon': Icons.block,
      'bgColor': Colors.deepOrange.withOpacity(0.1)
    },
    'completed': {
      'text': 'Complétée',
      'color': Colors.green,
      'icon': Icons.verified,
      'bgColor': Colors.green.withOpacity(0.1)
    },
  };

  String _getStatusText(String status) {
    return _statusConfig[status]?['text'] ?? status;
  }

  Color _getStatusColor(String status) {
    return _statusConfig[status]?['color'] ?? Colors.grey;
  }

  IconData _getStatusIcon(String status) {
    return _statusConfig[status]?['icon'] ?? Icons.info;
  }

  Color _getStatusBgColor(String status) {
    return _statusConfig[status]?['bgColor'] ?? Colors.grey.withOpacity(0.1);
  }

  Stream<List<OrderModel>> _getOrderList() {
    final firebase = FirebaseFirestore.instance;
    return firebase
        .collection('orders')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((order) => OrderModel.fromSnapshot(order))
              .toList(),
        );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: THelperFunctions.isDarkMode(context) 
            ? Colors.grey[900]
            : Colors.grey[50],
        appBar: AppBar(
         /*  title: TextCustom(
            TheText: 'Gestion des Commandes',
            TheTextSize: 20,
            TheTextFontWeight: FontWeight.bold,
          ), */
          centerTitle: true,
          elevation: 0,
          backgroundColor: Colors.transparent,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(15),
            child: Column(
              children: [
                Container(
                  height: 50,
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: THelperFunctions.isDarkMode(context)
                        ? Colors.grey[800]
                        : Colors.orange.shade50,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TabBar(
                    indicatorSize: TabBarIndicatorSize.tab,
                    dividerColor: Colors.transparent,
                    indicator: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFE9003), Color(0xFFFF6B00)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.orange.withOpacity(0.3),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    labelColor: Colors.white,
                    unselectedLabelColor: THelperFunctions.isDarkMode(context)
                        ? Colors.white70
                        : Colors.black87,
                    tabs: [
                      Tab(
                        icon: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.local_shipping, size: 18),
                            SizedBox(width: 6),
                            Text(
                              "Courses Actives",
                              style: TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                      Tab(
                        icon: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.history, size: 18),
                            SizedBox(width: 6),
                            Text(
                              "Historiques",
                              style: TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 10),
              ],
            ),
          ),
        ),
        body: StreamBuilder<List<OrderModel>>(
          stream: _getOrderList(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return _buildLoadingWidget();
            }

            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return _buildNoDataWidget("Aucune commande trouvée");
            }

            final allOrders = snapshot.data!;

            // Séparation des commandes
            final mesCourses = allOrders
                .where((order) => order.status.toLowerCase() != "completed" && 
                                 order.status.toLowerCase() != "finish")
                .toList();

            final historiques = allOrders
                .where((order) => order.status.toLowerCase() == "completed" || 
                                 order.status.toLowerCase() == "finish")
                .toList();

            return TabBarView(
              children: [
                // Onglet "Courses Actives"
                _buildOrderList(mesCourses, "Aucune course active"),
                // Onglet "Historiques"
                _buildOrderList(historiques, "Aucun historique de commande"),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildLoadingWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 60,
            width: 60,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              valueColor: AlwaysStoppedAnimation(ColorApp.tsecondaryColor),
            ),
          ),
          SizedBox(height: 16),
          TextCustom(
            TheText: 'Chargement des commandes...',
            TheTextSize: 14,
            TheTextColor: Colors.grey,
          ),
        ],
      ),
    );
  }

  Widget _buildNoDataWidget(String message) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            height: 200,
            width: 200,
            'assets/images/no_data.json',
            fit: BoxFit.cover,
          ),
          SizedBox(height: 16),
          TextCustom(
            TheText: message,
            TheTextSize: 16,
            TheTextColor: Colors.grey,
            TheTextFontWeight: FontWeight.w500,
          ),
          SizedBox(height: 8),
          TextCustom(
            TheText: 'Les nouvelles commandes apparaîtront ici',
            TheTextSize: 12,
            TheTextColor: Colors.grey,
          ),
        ],
      ),
    );
  }

  Widget _buildOrderList(List<OrderModel> orders, String emptyMessage) {
    if (orders.isEmpty) {
      return _buildNoDataWidget(emptyMessage);
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemCount: orders.length,
      itemBuilder: (_, index) {
        final order = orders[index];
        return _buildOrderItem(order);
      },
    );
  }

  Widget _buildOrderItem(OrderModel order) {
    return InkWell(
      onTap: () {
        Get.to(
          () => OrderStep(
            status: order.status,
            orderId: order.uid!,
            amount: order.amount,
            carId: '',
            userCreatedId: order.userRef!.id,
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: THelperFunctions.isDarkMode(context)
              ? Colors.grey[800]
              : Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(
            color: Colors.grey.withOpacity(0.2),
          ),
        ),
        child: Row(
          children: [
            // Badge de statut coloré
            Container(
              width: 6,
              height: 120,
              decoration: BoxDecoration(
                color: _getStatusColor(order.status),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16),
                  bottomLeft: Radius.circular(16),
                ),
              ),
            ),
            
            // Image container
            Container(
              margin: const EdgeInsets.all(12),
              height: 80,
              width: 80,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  colors: [
                    ColorApp.tPrimaryColor.withOpacity(0.8),
                    ColorApp.tsecondaryColor.withOpacity(0.6),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: ColorApp.tPrimaryColor.withOpacity(0.3),
                    blurRadius: 8,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Icon(
                Icons.local_shipping,
                color: Colors.white,
                size: 32,
              ),
            ),
            
            // Content container
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header avec numéro de commande et statut
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: TextCustom(
                            TheText: 'CMD #${order.orderId}',
                            TheTextSize: 16,
                            TheTextFontWeight: FontWeight.bold,
                            TheTextMaxLines: 1,
                          ),
                        ),
                        const SizedBox(width: 8),
                        _buildStatusBadge(order.status),
                      ],
                    ),
                    
                    SizedBox(height: 8),
                    
                    // Date et heure
                    Row(
                      children: [
                        Icon(
                          Icons.calendar_today,
                          size: 14,
                          color: Colors.grey,
                        ),
                        SizedBox(width: 4),
                        TextCustom(
                          TheText: DateFormat('dd/MM/yyyy').format(order.createdAt.toDate()),
                          TheTextSize: 12,
                          TheTextColor: Colors.grey,
                        ),
                        SizedBox(width: 12),
                        Icon(
                          Icons.access_time,
                          size: 14,
                          color: Colors.grey,
                        ),
                        SizedBox(width: 4),
                        TextCustom(
                          TheText: DateFormat('HH:mm').format(order.createdAt.toDate()),
                          TheTextSize: 12,
                          TheTextColor: Colors.grey,
                        ),
                      ],
                    ),
                    
                    SizedBox(height: 8),
                    
                    // Informations de prix et distance
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.green.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.green.withOpacity(0.3)),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.attach_money,
                                    size: 12,
                                    color: Colors.green,
                                  ),
                                  SizedBox(width: 4),
                                  TextCustom(
                                    TheText: "${order.amount.toInt()} FCFA",
                                    TheTextSize: 12,
                                    TheTextColor: Colors.green,
                                    TheTextFontWeight: FontWeight.bold,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        
                        Row(
                          children: [
                            Icon(
                              Icons.place,
                              size: 12,
                              color: Colors.blue,
                            ),
                            SizedBox(width: 4),
                            TextCustom(
                              TheText: "${order.distance.toStringAsFixed(1)} km",
                              TheTextSize: 12,
                              TheTextColor: Colors.blue,
                              TheTextFontWeight: FontWeight.w600,
                            ),
                          ],
                        ),
                      ],
                    ),
                    
                    SizedBox(height: 8),
                    
                    // Adresse de livraison (truncated)
                    Row(
                      children: [
                        Icon(
                          Icons.location_on,
                          size: 12,
                          color: Colors.orange,
                        ),
                        SizedBox(width: 4),
                        Expanded(
                          child: TextCustom(
                            TheText: order.destinationLocation.address,
                            TheTextSize: 11,
                            TheTextColor: Colors.grey,
                            TheTextMaxLines: 1,
                            
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            // Flèche de navigation
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBadge(String status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: _getStatusBgColor(status),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _getStatusColor(status).withOpacity(0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            _getStatusIcon(status),
            size: 12,
            color: _getStatusColor(status),
          ),
          SizedBox(width: 4),
          TextCustom(
            TheText: _getStatusText(status),
            TheTextSize: 10,
            TheTextColor: _getStatusColor(status),
            TheTextFontWeight: FontWeight.w600,
          ),
        ],
      ),
    );
  }
}