import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/models/auth/user_model.dart';
import 'package:smart_admin/src/models/order_model.dart';
import 'package:smart_admin/src/models/transactions/transaction_model.dart';
import 'package:smart_admin/src/screens/orders/order_detail_finish.dart';
import 'package:smart_admin/src/screens/users/deliver_list.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:smart_admin/src/utils/loaders/loaders.dart';
import 'package:smart_admin/src/utils/texts/text_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';
import 'package:badges/badges.dart' as badges;

class DeliverDetailScreen extends StatefulWidget {
  const DeliverDetailScreen({super.key, required this.userId});
  final String userId;

  @override
  State<DeliverDetailScreen> createState() => _DeliverDetailScreenState();
}

class _DeliverDetailScreenState extends State<DeliverDetailScreen> {
  final firebase = FirebaseFirestore.instance;
  bool isCharged = false;
  UserModel user = UserModel(
    fullName: "",
    email: "",
    phoneNumber: "",
    userRole: 'Deliver',
    userAdress: "",
    isAvailable: false,
    geopoint: GeoPoint(0, 0),
  );

  // Couleurs personnalisées pour le design
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _infoColor = Colors.blue;

  void fetchDataUser() async {
    setState(() {
      isCharged = true;
    });
    if (widget.userId.isEmpty) return;
    try {
      final data = await firebase.collection('users').doc(widget.userId).get();

      if (data.exists) {
        final verifyItem = UserModel.fromSnapshot(data);
        if (mounted) {
          setState(() {
            user = verifyItem;
            isCharged = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          isCharged = false;
        });
      }
      TLoaders.errorSnackBar(title: "Erreur: $e");
    }
  }

  Stream<int> getOrderFinishTodayTotal(String userId) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('status', isEqualTo: "completed")
        .where(
          'createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay),
          isLessThan: Timestamp.fromDate(endOfDay),
        )
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Stream<int> getOrderFinishTodayTotalAmount(String userId) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('status', isEqualTo: "completed")
        .where(
          'createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay),
          isLessThan: Timestamp.fromDate(endOfDay),
        )
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return 0;

          double total = 0;

          for (final doc in snapshot.docs) {
            final data = doc.data();
            final amount = (data['amount'] as num).toDouble();
            total += amount;
          }

          return total.toInt();
        });
  }

  Stream<int> getOrderPendingTotal(String userId) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('paymentStatus', isEqualTo: "Pending")
        .where(
          'createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay),
          isLessThan: Timestamp.fromDate(endOfDay),
        )
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Stream<int> getOrderFinishTotal(String userId) {
    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('status', isEqualTo: "completed")
        .where('paymentStatus', isEqualTo: "Completed")
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Stream<double> getUserBalance(String userId) {
    return FirebaseFirestore.instance
        .collection('wallets')
        .where('userId', isEqualTo: userId)
        .limit(1)
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return 0.0;
          final data = snapshot.docs.first;
          final amount = (data['amount'] as num).toDouble();
          return amount;
        });
  }

  Stream<List<TransactionModel>> getTransactions(String userId) {
    return FirebaseFirestore.instance
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .limit(10)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => TransactionModel.fromSnapshot(doc))
              .toList(),
        );
  }

  Stream<List<OrderModel>> getOrdersFinishLists(String userId) {
    return FirebaseFirestore.instance
        .collection('orders')
        .orderBy("createdAt", descending: true)
        .where('paymentStatus', isEqualTo: "Completed")
        .where('status', isEqualTo: "completed")
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .limit(10)
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) => OrderModel.fromSnapshot(doc)).toList(),
        );
  }

  Widget _buildStatCard({
    required String title,
    required Stream<dynamic> stream,
    required Color color,
    required IconData icon,
    bool isCurrency = false,
  }) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
        width: 160,
        height: 100,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [color.withOpacity(0.8), color.withOpacity(0.4)],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, size: 16, color: Colors.white),
                ),
                Spacer(),
                StreamBuilder(
                  stream: stream,
                  builder: (context, asyncSnapshot) {
                    if (!asyncSnapshot.hasData) {
                      return SizedBox(
                        height: 16,
                        width: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation(Colors.white),
                        ),
                      );
                    }
                    
                    final data = asyncSnapshot.data;
                    String displayText = data.toString();
                    
                    if (isCurrency && data is num) {
                      displayText = '${NumberFormat().format(data)} F';
                    }

                    return Text(
                      displayText,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    );
                  },
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.white.withOpacity(0.9),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserProfileCard() {
    return Card(
      elevation: 4,
      margin: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_primaryColor.withOpacity(0.8), _secondaryColor.withOpacity(0.6)],
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 3),
              ),
              child: ClipOval(
                child: user.profilePicture != null && user.profilePicture!.isNotEmpty
                    ? Image.network(
                        user.profilePicture!,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.2),
                            ),
                            child: Icon(Icons.person, color: Colors.white, size: 30),
                          );
                        },
                      )
                    : Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.2),
                        ),
                        child: Icon(Icons.person, color: Colors.white, size: 30),
                      ),
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    user.fullName,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.local_shipping, size: 14, color: Colors.white70),
                      SizedBox(width: 4),
                      Text(
                        'Livreur',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.email_outlined, size: 14, color: Colors.white70),
                      SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          user.email,
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.white70,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.phone, size: 14, color: Colors.white70),
                      SizedBox(width: 4),
                      Text(
                        user.phoneNumber ?? "Non renseigné",
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            badges.Badge(
              badgeStyle: badges.BadgeStyle(
                badgeColor: user.isAvailable ? _successColor : _errorColor,
              ),
              badgeContent: Text(
                user.isAvailable ? '✓' : '✗',
                style: TextStyle(
                  fontSize: 10,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              child: SizedBox.shrink(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: _primaryColor),
          SizedBox(height: 16),
          Text(
            'Chargement...',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoDataWidget(String message) {
    return Container(
      height: 180,
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Colors.grey.withOpacity(0.1),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset(
              height: 100,
              width: 100,
              'assets/images/no_data.json',
              fit: BoxFit.cover,
            ),
            SizedBox(height: 10),
            Text(
              message,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderItem(OrderModel order) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        onTap: () {
          Get.to(() => OrderDetailFinishScreen(
            endLocation: order.destinationLocation,
            startLocation: order.withdrawalPoint,
            orderId: order.uid!,
            userCreatedId: order.userRef!.id,
          ));
        },
        leading: Container(
          width: 45,
          height: 45,
          decoration: BoxDecoration(
            color: _primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(Icons.local_shipping, color: _primaryColor, size: 20),
        ),
        title: Text(
          "#${order.orderId}",
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 4),
            Text(
              DateFormat('dd/MM/yyyy à HH:mm').format(order.createdAt.toDate()),
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
            SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.place, size: 10, color: Colors.grey),
                SizedBox(width: 4),
                Text(
                  "${order.distance.toStringAsFixed(1)} km",
                  style: TextStyle(fontSize: 11, color: Colors.grey),
                ),
                Spacer(),
                Text(
                  "${order.amount.toInt()} FCFA",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: _successColor,
                  ),
                ),
              ],
            ),
          ],
        ),
        trailing: Container(
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: _getStatusColor(order.status).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _getStatusColor(order.status).withOpacity(0.3)),
          ),
          child: Text(
            _getStatusText(order.status),
            style: TextStyle(
              fontSize: 10,
              color: _getStatusColor(order.status),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTransactionItem(TransactionModel transaction) {
    Color typeColor = transaction.type == "payment" ? _successColor : _errorColor;
    IconData typeIcon = transaction.type == "payment" ? Icons.arrow_downward : Icons.arrow_upward;

    Color statusColor = Colors.grey;
    switch (transaction.status) {
      case "completed":
        statusColor = _successColor;
        break;
      case "failed":
        statusColor = _errorColor;
        break;
      case "pending":
        statusColor = _warningColor;
        break;
    }

    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Container(
          width: 45,
          height: 45,
          decoration: BoxDecoration(
            color: typeColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(typeIcon, color: typeColor, size: 20),
        ),
        title: Text(
          "Transaction #${transaction.reference}",
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 4),
            Text(
              DateFormat('dd/MM/yyyy à HH:mm').format(transaction.createdAt.toDate()),
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
            SizedBox(height: 4),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _getTransactionStatusText(transaction.status),
                style: TextStyle(
                  fontSize: 10,
                  color: statusColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        trailing: Text(
          "${transaction.type == "payment" ? '+' : '-'} ${transaction.amount.toStringAsFixed(2)} F",
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: typeColor,
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed': return _successColor;
      case 'pending': return _warningColor;
      case 'cancelled': return _errorColor;
      default: return _infoColor;
    }
  }

  String _getStatusText(String status) {
    switch (status.toLowerCase()) {
      case 'completed': return 'Terminée';
      case 'pending': return 'En cours';
      case 'cancelled': return 'Annulée';
      default: return status;
    }
  }

  String _getTransactionStatusText(String status) {
    switch (status) {
      case "completed": return "Complétée";
      case "failed": return "Échouée";
      case "pending": return "En attente";
      default: return status;
    }
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: _primaryColor,
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      leading: IconButton(
        onPressed: () => Get.offAll(() => const DeliverListScreen()),
        icon: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _primaryColor.withOpacity(0.1),
          ),
          child: Icon(
            LineAwesomeIcons.angle_left_solid,
            color: _primaryColor,
            size: 20,
          ),
        ),
      ),
      title: Text(
        'Détails du Livreur',
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      centerTitle: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
    );
  }

  @override
  void initState() {
    fetchDataUser();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (isCharged) {
      return Scaffold(
        appBar: _buildAppBar(),
        body: _buildLoadingIndicator(),
      );
    }

    return Scaffold(
      appBar: _buildAppBar(),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          children: [
            // Profil du livreur
            _buildUserProfileCard(),

            // Statistiques
            _buildSectionHeader("Statistiques"),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  _buildStatCard(
                    title: "Solde Total",
                    stream: getUserBalance(user.ref!.id),
                    color: _successColor,
                    icon: Icons.account_balance_wallet,
                    isCurrency: true,
                  ),
                  SizedBox(width: 12),
                  _buildStatCard(
                    title: "Courses Total",
                    stream: getOrderFinishTotal(user.ref!.id),
                    color: _infoColor,
                    icon: Icons.local_shipping,
                  ),
                  SizedBox(width: 12),
                  _buildStatCard(
                    title: "Gains du Jour",
                    stream: getOrderFinishTodayTotalAmount(user.ref!.id),
                    color: _warningColor,
                    icon: Icons.attach_money,
                    isCurrency: true,
                  ),
                  SizedBox(width: 12),
                  _buildStatCard(
                    title: "Courses Aujourd'hui",
                    stream: getOrderFinishTodayTotal(user.ref!.id),
                    color: _primaryColor,
                    icon: Icons.today,
                  ),
                ],
              ),
            ),

            SizedBox(height: 24),

            // Dernières livraisons
            _buildSectionHeader("Dernières Livraisons"),
            StreamBuilder<List<OrderModel>>(
              stream: getOrdersFinishLists(user.ref!.id),
              builder: (context, asyncSnapshot) {
                if (asyncSnapshot.connectionState == ConnectionState.waiting) {
                  return _buildLoadingIndicator();
                }

                if (!asyncSnapshot.hasData || asyncSnapshot.data!.isEmpty) {
                  return _buildNoDataWidget("Aucune livraison récente.");
                }

                final orders = asyncSnapshot.data!;

                return ListView.builder(
                  itemCount: orders.length,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return _buildOrderItem(orders[index]);
                  },
                );
              },
            ),

            SizedBox(height: 24),

            // Historique des transactions
            _buildSectionHeader("Historique des Transactions"),
            StreamBuilder<List<TransactionModel>>(
              stream: getTransactions(user.ref!.id),
              builder: (context, asyncSnapshot) {
                if (asyncSnapshot.connectionState == ConnectionState.waiting) {
                  return _buildLoadingIndicator();
                }

                if (!asyncSnapshot.hasData || asyncSnapshot.data!.isEmpty) {
                  return _buildNoDataWidget("Aucune transaction trouvée.");
                }

                final transactions = asyncSnapshot.data!;

                return ListView.builder(
                  itemCount: transactions.length,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return _buildTransactionItem(transactions[index]);
                  },
                );
              },
            ),

            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}