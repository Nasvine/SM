import 'package:cached_network_image/cached_network_image.dart';
import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/models/auth/user_model.dart';
import 'package:smart_admin/src/screens/tabs.dart';
import 'package:smart_admin/src/screens/users/user_list.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:smart_admin/src/utils/loaders/loaders.dart';
import 'package:smart_admin/src/utils/texts/button_custom.dart';
import 'package:smart_admin/src/utils/texts/dropdown_formfield_custom.dart';
import 'package:smart_admin/src/utils/texts/text_custom.dart';
import 'package:smart_admin/src/utils/texts/text_form_field_simple_custom.dart';
import 'package:smart_admin/src/utils/validators/validator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class UserCreateScreen extends StatefulWidget {
  const UserCreateScreen({super.key, required this.userId});
  final String userId;

  @override
  State<UserCreateScreen> createState() => _UserCreateScreenState();
}

class _UserCreateScreenState extends State<UserCreateScreen> {
  final firebase = FirebaseFirestore.instance;
  final userNameController = TextEditingController();
  final userEmailController = TextEditingController();
  final userAdresseController = TextEditingController();
  final userPhoneController = TextEditingController();
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  String? selectedRole;
  String? userImage;
  bool isUploading = false;
  bool isValidated = false;

  File? imageFile;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final ImagePicker _picker = ImagePicker();
  List<String> userRoles = ['Super Admin', 'Admin', 'Client', 'Deliver'];

  // Couleurs personnalisées pour le design
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _infoColor = Colors.blue;

  @override
  void initState() {
    fetchDataUser();
    super.initState();
  }

  void fetchDataUser() async {
    if (widget.userId == "") return;
    try {
      final data = await firebase.collection('users').doc(widget.userId).get();
      if (data.exists) {
        final verifyItem = UserModel.fromSnapshot(data);
        setState(() {
          userNameController.text = verifyItem.fullName;
          userAdresseController.text = verifyItem.userAdress ?? '';
          userEmailController.text = verifyItem.email;
          userPhoneController.text = verifyItem.phoneNumber ?? '';
          userImage = verifyItem.profilePicture;
          selectedRole = verifyItem.userRole;
        });
      }
    } catch (e) {
      print('Error fetching user data: $e');
    }
  }

  Future<void> _pickGalleryCarImage() async {
    final pickedFile = await _picker.pickImage(
      source: ImageSource.gallery,
      maxHeight: 675,
      maxWidth: 900,
    );
    if (pickedFile != null) {
      imageFile = File(pickedFile.path);
      uploadCarImage(imageFile!);
    }
    Get.back();
  }

  Future _pickImageCarCamera() async {
    final returnImage = await ImagePicker().pickImage(
      source: ImageSource.camera,
      maxHeight: 675,
      maxWidth: 900,
    );
    if (returnImage == null) return;
    imageFile = File(returnImage.path);
    uploadCarImage(imageFile!);
    Get.back();
  }

  Future<String> uploadCarImage(File file) async {
    try {
      setState(() {
        isUploading = true;
      });

      final storageRef = _storage.ref().child(
        'users/${DateTime.now().millisecondsSinceEpoch}',
      );
      final uploadTask = storageRef.putFile(file);
      final snapshot = await uploadTask;
      final url = await snapshot.ref.getDownloadURL();
      setState(() {
        userImage = url;
      });

      await CachedNetworkImage.evictFromCache(url);
      return url;
    } catch (e) {
      print("Erreur d'upload: $e");
      rethrow;
    } finally {
      setState(() {
        isUploading = false;
      });
    }
  }

  void showImagePickerCarOption(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (builder) {
        return Container(
          margin: EdgeInsets.only(top: 50),
          decoration: BoxDecoration(
            color: THelperFunctions.isDarkMode(context)
                ? Colors.grey[900]
                : Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(25),
              topRight: Radius.circular(25),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Choisir une photo',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _primaryColor,
                  ),
                ),
                SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: _pickGalleryCarImage,
                        child: Container(
                          height: 120,
                          decoration: BoxDecoration(
                            color: _primaryColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: _primaryColor.withOpacity(0.3)),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.photo_library, size: 40, color: _primaryColor),
                              SizedBox(height: 8),
                              Text(
                                "Galerie",
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: _primaryColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: InkWell(
                        onTap: _pickImageCarCamera,
                        child: Container(
                          height: 120,
                          decoration: BoxDecoration(
                            color: _secondaryColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: _secondaryColor.withOpacity(0.3)),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.camera_alt, size: 40, color: _secondaryColor),
                              SizedBox(height: 8),
                              Text(
                                "Caméra",
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: _secondaryColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                TextButton(
                  onPressed: () => Get.back(),
                  child: Text(
                    'Annuler',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildImageSection() {
    return Column(
      children: [
        Text(
          "Photo de profil",
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: _primaryColor,
          ),
        ),
        SizedBox(height: 16),
        Stack(
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: _primaryColor.withOpacity(0.3), width: 3),
              ),
              child: ClipOval(
                child: userImage == null || userImage!.isEmpty
                    ? Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _primaryColor.withOpacity(0.1),
                        ),
                        child: Icon(
                          Icons.person,
                          color: _primaryColor,
                          size: 40,
                        ),
                      )
                    : CachedNetworkImage(
                        imageUrl: userImage!,
                        fit: BoxFit.cover,
                        progressIndicatorBuilder: (context, url, progress) {
                          return Center(
                            child: CircularProgressIndicator(
                              value: progress.progress,
                              color: _primaryColor,
                            ),
                          );
                        },
                        errorWidget: (context, url, error) {
                          return Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _primaryColor.withOpacity(0.1),
                            ),
                            child: Icon(
                              Icons.error,
                              color: _errorColor,
                              size: 30,
                            ),
                          );
                        },
                      ),
              ),
            ),
            if (isUploading)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withOpacity(0.5),
                  ),
                  child: Center(
                    child: CircularProgressIndicator(
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                width: 35,
                height: 35,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _primaryColor,
                  boxShadow: [
                    BoxShadow(
                      color: _primaryColor.withOpacity(0.3),
                      blurRadius: 8,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: IconButton(
                  onPressed: () => showImagePickerCarOption(context),
                  icon: Icon(Icons.camera_alt, color: Colors.white, size: 16),
                  padding: EdgeInsets.zero,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 8),
        Text(
          'Cliquez sur l\'appareil photo pour modifier',
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade500,
          ),
        ),
      ],
    );
  }

  Widget _buildFormField({
    required String label,
    required TextEditingController controller,
    required String? Function(String?) validator,
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
    String? hintText,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: THelperFunctions.isDarkMode(context)
                ? Colors.white70
                : Colors.black87,
          ),
        ),
        SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 4,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            obscureText: obscureText,
            style: TextStyle(
              color: THelperFunctions.isDarkMode(context)
                  ? Colors.white
                  : Colors.black87,
            ),
            decoration: InputDecoration(
              hintText: hintText ?? label,
              hintStyle: TextStyle(color: Colors.grey.shade500),
              filled: true,
              fillColor: THelperFunctions.isDarkMode(context)
                  ? Colors.grey[800]
                  : Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: Colors.grey.withOpacity(0.3),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: _primaryColor,
                  width: 2,
                ),
              ),
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
            validator: validator,
          ),
        ),
        SizedBox(height: 16),
      ],
    );
  }

  Widget _buildRoleDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Rôle de l'utilisateur",
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: THelperFunctions.isDarkMode(context)
                ? Colors.white70
                : Colors.black87,
          ),
        ),
        SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 4,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: DropdownButtonFormField<String>(
            value: selectedRole,
            decoration: InputDecoration(
              filled: true,
              fillColor: THelperFunctions.isDarkMode(context)
                  ? Colors.grey[800]
                  : Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: Colors.grey.withOpacity(0.3),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: _primaryColor,
                  width: 2,
                ),
              ),
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            ),
            hint: Text(
              'Sélectionnez un rôle',
              style: TextStyle(color: Colors.grey.shade500),
            ),
            items: userRoles.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(
                  value,
                  style: TextStyle(
                    color: THelperFunctions.isDarkMode(context)
                        ? Colors.white
                        : Colors.black87,
                  ),
                ),
              );
            }).toList(),
            onChanged: (String? value) {
              setState(() {
                selectedRole = value;
              });
            },
            validator: (value) => TValidator.validationEmptyText("Rôle", value),
            icon: Icon(Icons.arrow_drop_down, color: _primaryColor),
            dropdownColor: THelperFunctions.isDarkMode(context)
                ? Colors.grey[800]
                : Colors.white,
          ),
        ),
        SizedBox(height: 16),
      ],
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      leading: IconButton(
        onPressed: () => Get.offAll(() => const UserListScreen()),
        icon: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _primaryColor.withOpacity(0.1),
          ),
          child: Icon(
            LineAwesomeIcons.angle_left_solid,
            color: _primaryColor,
            size: 20,
          ),
        ),
      ),
      title: Text(
        widget.userId == "" ? "Ajouter un utilisateur" : "Modifier l'utilisateur",
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      centerTitle: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
    );
  }

  Future<void> _submitForm() async {
    if (!formKey.currentState!.validate()) {
      TLoaders.warningSnackBar(
        title: 'Champs manquants',
        message: 'Veuillez remplir tous les champs obligatoires',
      );
      return;
    }

    setState(() {
      isValidated = true;
    });

    try {
      final userItem = UserModel(
        fullName: userNameController.text.trim(),
        email: userEmailController.text.trim(),
        phoneNumber: userPhoneController.text.trim(),
        userRole: selectedRole!,
        userAdress: userAdresseController.text.trim(),
        isAvailable: true,
        geopoint: GeoPoint(0, 0),
        profilePicture: userImage,
      );

      if (widget.userId.isNotEmpty) {
        await firebase
            .collection('users')
            .doc(widget.userId)
            .update(userItem.toJson());
        TLoaders.successSnackBar(
          title: 'Succès',
          message: "Utilisateur modifié avec succès",
        );
      } else {
        await firebase.collection('users').add(userItem.toJson());
        TLoaders.successSnackBar(
          title: 'Succès',
          message: "Utilisateur créé avec succès",
        );
      }

      Get.offAll(() => const UserListScreen());
    } catch (e) {
      TLoaders.errorSnackBar(
        title: 'Erreur',
        message: "Une erreur est survenue: $e",
      );
    } finally {
      setState(() {
        isValidated = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        padding: EdgeInsets.all(20),
        child: Form(
          key: formKey,
          child: Column(
            children: [
              // Section Photo
              _buildImageSection(),
              SizedBox(height: 30),

              // Formulaire
              _buildFormField(
                label: "Nom complet",
                controller: userNameController,
                validator: (value) => TValidator.validationEmptyText("Nom complet", value),
                hintText: "Entrez le nom complet",
              ),

              _buildFormField(
                label: "Adresse email",
                controller: userEmailController,
                validator: (value) => TValidator.validationEmptyText("Email", value),
                keyboardType: TextInputType.emailAddress,
                hintText: "entrez l'adresse email",
              ),

              _buildFormField(
                label: "Adresse",
                controller: userAdresseController,
                validator: (value) => TValidator.validationEmptyText("Adresse", value),
                hintText: "Entrez l'adresse",
              ),

              _buildFormField(
                label: "Numéro de téléphone",
                controller: userPhoneController,
                validator: TValidator.validationPhoneNumber,
                keyboardType: TextInputType.phone,
                hintText: "Entrez le numéro de téléphone",
              ),

              // Dropdown Rôle
              _buildRoleDropdown(),

              // Bouton de soumission
              Container(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: isValidated ? null : _submitForm,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _primaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    elevation: 3,
                    shadowColor: _primaryColor.withOpacity(0.3),
                  ),
                  child: isValidated
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              widget.userId.isEmpty ? Icons.person_add : Icons.save,
                              size: 20,
                            ),
                            SizedBox(width: 8),
                            Text(
                              widget.userId.isEmpty ? "Créer l'utilisateur" : "Modifier l'utilisateur",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    userNameController.dispose();
    userEmailController.dispose();
    userAdresseController.dispose();
    userPhoneController.dispose();
    super.dispose();
  }
}