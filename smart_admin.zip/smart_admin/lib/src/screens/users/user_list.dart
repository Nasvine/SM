import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/constants/texts.dart';
import 'package:smart_admin/src/models/auth/user_model.dart';
import 'package:smart_admin/src/screens/tabs.dart';
import 'package:smart_admin/src/screens/users/user_create.dart';
import 'package:smart_admin/src/screens/verify_account/verify_account.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:smart_admin/src/utils/loaders/loaders.dart';
import 'package:smart_admin/src/utils/texts/button_custom_outlined.dart';
import 'package:smart_admin/src/utils/texts/button_custom_outlined_icon.dart';
import 'package:smart_admin/src/utils/texts/text_custom.dart';
import 'package:smart_admin/src/utils/texts/text_form_field_simple_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:async';
import 'package:lottie/lottie.dart';
import 'package:badges/badges.dart' as badges;

class UserListScreen extends StatefulWidget {
  const UserListScreen({super.key});

  @override
  State<UserListScreen> createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  final authId = FirebaseAuth.instance.currentUser!.uid;
  String _searchQuery = '';
  Timer? _debounce;
  TextEditingController searchController = TextEditingController();

  // Couleurs personnalisées pour le design
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _infoColor = Colors.blue;

  Stream<List<UserModel>> fetchUsers() {
    return FirebaseFirestore.instance
        .collection('users')
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((document) => UserModel.fromSnapshot(document))
              .toList(),
        );
  }

  void _onRemoveUser(String userId) async {
    if (userId.isEmpty) return;

    try {
      final docRef = FirebaseFirestore.instance.collection('users').doc(userId);
      final docSnapshot = await docRef.get();

      if (!docSnapshot.exists) {
        TLoaders.warningSnackBar(
          title: 'Erreur',
          message: "Utilisateur introuvable.",
        );
        return;
      }

      final data = docSnapshot.data()!;
      final String? mainImage = data['profilePicture'];

      // Supprimer l'image principale
      if (mainImage != null && mainImage.isNotEmpty) {
        try {
          final ref = FirebaseStorage.instance.refFromURL(mainImage);
          await ref.delete();
        } catch (e) {
          print("Erreur suppression image principale : $e");
        }
      }

      // Supprimer le document Firestore
      await docRef.delete();

      // Afficher le succès
      TLoaders.successSnackBar(
        title: 'Félicitations',
        message: "tMessageDltUser".tr,
      );
    } catch (e) {
      print("Erreur suppression utilisateur : $e");
      TLoaders.warningSnackBar(title: 'Erreur', message: e.toString());
    }
  }

  Widget _buildUserRoleBadge(String role) {
    Color backgroundColor;
    Color textColor;
    String displayText;

    switch (role.toLowerCase()) {
      case 'admin':
        backgroundColor = Colors.purple.withOpacity(0.1);
        textColor = Colors.purple;
        displayText = 'Administrateur';
        break;
      case 'deliver':
        backgroundColor = Colors.orange.withOpacity(0.1);
        textColor = Colors.orange;
        displayText = 'Livreur';
        break;
      case 'client':
        backgroundColor = Colors.blue.withOpacity(0.1);
        textColor = Colors.blue;
        displayText = 'Client';
        break;
      default:
        backgroundColor = Colors.grey.withOpacity(0.1);
        textColor = Colors.grey;
        displayText = role;
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: textColor.withOpacity(0.3)),
      ),
      child: Text(
        displayText,
        style: TextStyle(
          fontSize: 10,
          color: textColor,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildUserCard(UserModel user) {
    return Card(
      elevation: 3,
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: _primaryColor.withOpacity(0.3), width: 2),
          ),
          child: ClipOval(
            child: user.profilePicture != null && user.profilePicture!.isNotEmpty
                ? Image.network(
                    user.profilePicture!,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _primaryColor.withOpacity(0.1),
                        ),
                        child: Icon(
                          Icons.person,
                          color: _primaryColor,
                          size: 24,
                        ),
                      );
                    },
                  )
                : Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _primaryColor.withOpacity(0.1),
                    ),
                    child: Icon(
                      Icons.person,
                      color: _primaryColor,
                      size: 24,
                    ),
                  ),
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                user.fullName,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (user.ref!.id == authId)
              badges.Badge(
                badgeStyle: badges.BadgeStyle(
                  badgeColor: _primaryColor,
                ),
                badgeContent: Text(
                  'Vous',
                  style: TextStyle(
                    fontSize: 8,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                child: SizedBox.shrink(),
              ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.email_outlined, size: 12, color: Colors.grey),
                SizedBox(width: 4),
                Expanded(
                  child: Text(
                    user.email,
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2),
            Row(
              children: [
                Icon(Icons.phone_outlined, size: 12, color: Colors.grey),
                SizedBox(width: 4),
                Text(
                  user.phoneNumber ?? "Non renseigné",
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
              ],
            ),
            SizedBox(height: 6),
            _buildUserRoleBadge(user.userRole),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _primaryColor.withOpacity(0.1),
              ),
              child: IconButton(
                onPressed: () {
                  Get.to(() => UserCreateScreen(userId: user.ref!.id));
                },
                icon: Icon(
                  Icons.edit_outlined,
                  color: _primaryColor,
                  size: 16,
                ),
                padding: EdgeInsets.zero,
              ),
            ),
            SizedBox(width: 8),
            if (user.ref!.id == authId)
              Container(
                width: 35,
                height: 35,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _errorColor.withOpacity(0.1),
                ),
                child: IconButton(
                  onPressed: () => _showDeleteConfirmation(user),
                  icon: Icon(
                    Icons.delete_outline,
                    color: _errorColor,
                    size: 16,
                  ),
                  padding: EdgeInsets.zero,
                ),
              ),
          ],
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
    );
  }

  void _showDeleteConfirmation(UserModel user) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _errorColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.warning_amber, color: _errorColor),
            ),
            SizedBox(width: 12),
            Text("Confirmation", style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Êtes-vous sûr de vouloir supprimer votre compte ?"),
            SizedBox(height: 8),
            Text(
              "Cette action est irréversible et supprimera toutes vos données.",
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("Annuler", style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: _errorColor,
              foregroundColor: Colors.white,
            ),
            child: Text("Supprimer"),
          ),
        ],
      ),
    );

    if (confirm == true) {
      _onRemoveUser(user.ref!.id);
    }
  }

  Widget _buildSearchBar() {
    return Container(
      margin: EdgeInsets.all(16),
      padding: EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: THelperFunctions.isDarkMode(context)
            ? Colors.grey[800]
            : Colors.grey[50],
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: Colors.grey.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: searchController,
              onChanged: (value) {
                if (_debounce?.isActive ?? false) _debounce!.cancel();
                _debounce = Timer(
                  const Duration(milliseconds: 500),
                  () {
                    setState(() {
                      _searchQuery = value.toLowerCase();
                    });
                  },
                );
              },
              decoration: InputDecoration(
                hintText: 'Rechercher un utilisateur...',
                hintStyle: TextStyle(color: Colors.grey.shade500),
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search, color: Colors.grey.shade500),
                suffixIcon: searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear, color: Colors.grey.shade500),
                        onPressed: () {
                          setState(() {
                            searchController.clear();
                            _searchQuery = '';
                          });
                        },
                      )
                    : null,
              ),
            ),
          ),
          SizedBox(width: 12),
          Container(
            width: 45,
            height: 45,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_primaryColor, _secondaryColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: _primaryColor.withOpacity(0.3),
                  blurRadius: 8,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: IconButton(
              onPressed: () {
                Get.to(() => UserCreateScreen(userId: ""));
              },
              icon: Icon(Icons.add, color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: _primaryColor),
          SizedBox(height: 16),
          Text(
            'Chargement des utilisateurs...',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/no_users.json',
            height: 200,
            width: 200,
          ),
          SizedBox(height: 20),
          Text(
            'Aucun utilisateur trouvé',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade600,
            ),
          ),
          SizedBox(height: 10),
          Text(
            'Les utilisateurs apparaîtront ici une fois créés.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade500,
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: () {
              Get.to(() => UserCreateScreen(userId: ""));
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _primaryColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
            icon: Icon(Icons.person_add, size: 18),
            label: Text('Ajouter un utilisateur'),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      leading: IconButton(
        onPressed: () => Get.offAll(() => const TabsScreen(initialIndex: 0)),
        icon: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _primaryColor.withOpacity(0.1),
          ),
          child: Icon(
            LineAwesomeIcons.angle_left_solid,
            color: _primaryColor,
            size: 20,
          ),
        ),
      ),
      title: Text(
        'Gestion des Utilisateurs',
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      centerTitle: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
    );
  }

  @override
  void dispose() {
    _debounce?.cancel();
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: Column(
        children: [
          // Barre de recherche
          _buildSearchBar(),

          // En-tête avec statistiques
          StreamBuilder<List<UserModel>>(
            stream: fetchUsers(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return SizedBox();
              
              final users = snapshot.data!;
              final filteredUsers = _searchQuery.isEmpty 
                  ? users 
                  : users.where((user) => 
                      user.fullName.toLowerCase().contains(_searchQuery) ||
                      user.email.toLowerCase().contains(_searchQuery) ||
                      user.userRole.toLowerCase().contains(_searchQuery)
                    ).toList();

              return Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Icon(Icons.people_outline, color: _primaryColor, size: 18),
                    SizedBox(width: 8),
                    Text(
                      '${filteredUsers.length} utilisateur${filteredUsers.length > 1 ? 's' : ''}',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: _primaryColor,
                      ),
                    ),
                    Spacer(),
                    if (_searchQuery.isNotEmpty)
                      Text(
                        'Résultats pour "$_searchQuery"',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade500,
                        ),
                      ),
                  ],
                ),
              );
            },
          ),

          SizedBox(height: 16),

          // Liste des utilisateurs
          Expanded(
            child: StreamBuilder<List<UserModel>>(
              stream: fetchUsers(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return _buildLoadingState();
                }

                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return _buildEmptyState();
                }

                final allUsers = snapshot.data!;
                final filteredUsers = _searchQuery.isEmpty 
                    ? allUsers 
                    : allUsers.where((user) =>
                        user.fullName.toLowerCase().contains(_searchQuery) ||
                        user.email.toLowerCase().contains(_searchQuery) ||
                        user.userRole.toLowerCase().contains(_searchQuery)
                      ).toList();

                if (filteredUsers.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_off, size: 64, color: Colors.grey),
                        SizedBox(height: 16),
                        Text(
                          'Aucun résultat trouvé',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey.shade600,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Essayez avec d\'autres termes de recherche',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey.shade500,
                          ),
                        ),
                      ],
                    ),
                  );
                }

                return ListView.builder(
                  physics: BouncingScrollPhysics(),
                  itemCount: filteredUsers.length,
                  itemBuilder: (context, index) {
                    return _buildUserCard(filteredUsers[index]);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}