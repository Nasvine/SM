import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/models/auth/user_model.dart';
import 'package:smart_admin/src/screens/tabs.dart';
import 'package:smart_admin/src/screens/users/deliver_detail.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:smart_admin/src/utils/loaders/loaders.dart';
import 'package:smart_admin/src/utils/texts/text_custom.dart';
import 'package:smart_admin/src/utils/texts/text_form_field_simple_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:async';
import 'package:lottie/lottie.dart';
import 'package:badges/badges.dart' as badges;

class DeliverListScreen extends StatefulWidget {
  const DeliverListScreen({super.key});

  @override
  State<DeliverListScreen> createState() => _DeliverListScreenState();
}

class _DeliverListScreenState extends State<DeliverListScreen> {
  final authId = FirebaseAuth.instance.currentUser!.uid;
  String _searchQuery = '';
  Timer? _debounce;
  TextEditingController searchController = TextEditingController();

  // Couleurs personnalisées pour le design
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _infoColor = Colors.blue;

  Stream<List<UserModel>> fetchUsers() {
    return FirebaseFirestore.instance
        .collection('users')
        .where('userRole', isEqualTo: 'Deliver')
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((document) => UserModel.fromSnapshot(document))
              .toList(),
        );
  }

  void _onRemoveDeliver(String userId) async {
    if (userId.isEmpty) return;

    try {
      final docRef = FirebaseFirestore.instance.collection('users').doc(userId);
      final docSnapshot = await docRef.get();

      if (!docSnapshot.exists) {
        TLoaders.warningSnackBar(
          title: 'Erreur',
          message: "Livreur introuvable.",
        );
        return;
      }

      final data = docSnapshot.data()!;
      final String? mainImage = data['profilePicture'];

      // Supprimer l'image principale
      if (mainImage != null && mainImage.isNotEmpty) {
        try {
          final ref = FirebaseStorage.instance.refFromURL(mainImage);
          await ref.delete();
        } catch (e) {
          print("Erreur suppression image principale : $e");
        }
      }

      // Supprimer le document Firestore
      await docRef.delete();

      // Afficher le succès
      TLoaders.successSnackBar(
        title: 'Félicitations',
        message: "Livreur supprimé avec succès",
      );
    } catch (e) {
      print("Erreur suppression livreur : $e");
      TLoaders.warningSnackBar(title: 'Erreur', message: e.toString());
    }
  }

  Widget _buildStatusBadge(bool isAvailable) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: isAvailable ? _successColor.withOpacity(0.1) : _errorColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isAvailable ? _successColor : _errorColor,
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isAvailable ? _successColor : _errorColor,
            ),
          ),
          SizedBox(width: 6),
          Text(
            isAvailable ? "Disponible" : "Indisponible",
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: isAvailable ? _successColor : _errorColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsCard(int totalDelivers, int availableDelivers) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_primaryColor.withOpacity(0.8), _secondaryColor.withOpacity(0.6)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: _primaryColor.withOpacity(0.3),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Livreurs',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white.withOpacity(0.9),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  '$totalDelivers',
                  style: TextStyle(
                    fontSize: 24,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 1,
            height: 40,
            color: Colors.white.withOpacity(0.3),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  'Disponibles',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white.withOpacity(0.9),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  '$availableDelivers',
                  style: TextStyle(
                    fontSize: 24,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeliverCard(UserModel user) {
    return Card(
      elevation: 3,
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        onTap: () {
          Get.to(() => DeliverDetailScreen(userId: user.ref!.id));
        },
        leading: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: _primaryColor.withOpacity(0.3), width: 2),
          ),
          child: ClipOval(
            child: user.profilePicture != null && user.profilePicture!.isNotEmpty
                ? Image.network(
                    user.profilePicture!,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _primaryColor.withOpacity(0.1),
                        ),
                        child: Icon(
                          Icons.delivery_dining,
                          color: _primaryColor,
                          size: 24,
                        ),
                      );
                    },
                  )
                : Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _primaryColor.withOpacity(0.1),
                    ),
                    child: Icon(
                      Icons.delivery_dining,
                      color: _primaryColor,
                      size: 24,
                    ),
                  ),
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                user.fullName,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (user.ref!.id == authId)
              badges.Badge(
                badgeStyle: badges.BadgeStyle(
                  badgeColor: _primaryColor,
                ),
                badgeContent: Text(
                  'Vous',
                  style: TextStyle(
                    fontSize: 8,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                child: SizedBox.shrink(),
              ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.email_outlined, size: 12, color: Colors.grey),
                SizedBox(width: 4),
                Expanded(
                  child: Text(
                    user.email,
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2),
            Row(
              children: [
                Icon(Icons.phone_outlined, size: 12, color: Colors.grey),
                SizedBox(width: 4),
                Text(
                  user.phoneNumber ?? "Non renseigné",
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
              ],
            ),
            SizedBox(height: 6),
            _buildStatusBadge(user.isAvailable),
          ],
        ),
        trailing: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _primaryColor.withOpacity(0.1),
          ),
          child: Icon(
            Icons.arrow_forward_ios,
            color: _primaryColor,
            size: 16,
          ),
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: EdgeInsets.all(16),
      padding: EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: THelperFunctions.isDarkMode(context)
            ? Colors.grey[800]
            : Colors.grey[50],
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: Colors.grey.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: searchController,
              onChanged: (value) {
                if (_debounce?.isActive ?? false) _debounce!.cancel();
                _debounce = Timer(
                  const Duration(milliseconds: 500),
                  () {
                    setState(() {
                      _searchQuery = value.toLowerCase();
                    });
                  },
                );
              },
              decoration: InputDecoration(
                hintText: 'Rechercher un livreur...',
                hintStyle: TextStyle(color: Colors.grey.shade500),
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search, color: Colors.grey.shade500),
                suffixIcon: searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear, color: Colors.grey.shade500),
                        onPressed: () {
                          setState(() {
                            searchController.clear();
                            _searchQuery = '';
                          });
                        },
                      )
                    : null,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: _primaryColor),
          SizedBox(height: 16),
          Text(
            'Chargement des livreurs...',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            'assets/images/no_deliverers.json',
            height: 200,
            width: 200,
          ),
          SizedBox(height: 20),
          Text(
            'Aucun livreur trouvé',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade600,
            ),
          ),
          SizedBox(height: 10),
          Text(
            'Les livreurs apparaîtront ici une fois inscrits.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoResultsState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search_off, size: 64, color: Colors.grey.shade400),
          SizedBox(height: 16),
          Text(
            'Aucun résultat trouvé',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey.shade600,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Essayez avec d\'autres termes de recherche',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      leading: IconButton(
        onPressed: () => Get.offAll(() => const TabsScreen(initialIndex: 0)),
        icon: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _primaryColor.withOpacity(0.1),
          ),
          child: Icon(
            LineAwesomeIcons.angle_left_solid,
            color: _primaryColor,
            size: 20,
          ),
        ),
      ),
      title: Text(
        'Gestion des Livreurs',
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      centerTitle: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
    );
  }

  @override
  void dispose() {
    _debounce?.cancel();
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: Column(
        children: [
          // Barre de recherche
          _buildSearchBar(),

          // Statistiques et liste
          Expanded(
            child: StreamBuilder<List<UserModel>>(
              stream: fetchUsers(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return _buildLoadingState();
                }

                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return _buildEmptyState();
                }

                final allDelivers = snapshot.data!;
                final filteredDelivers = _searchQuery.isEmpty 
                    ? allDelivers 
                    : allDelivers.where((deliver) =>
                        deliver.fullName.toLowerCase().contains(_searchQuery) ||
                        deliver.email.toLowerCase().contains(_searchQuery) ||
                        (deliver.phoneNumber ?? '').contains(_searchQuery)
                      ).toList();

                final availableDelivers = allDelivers.where((d) => d.isAvailable).length;

                return Column(
                  children: [
                    // Carte de statistiques
                    _buildStatsCard(allDelivers.length, availableDelivers),

                    // En-tête de la liste
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.delivery_dining, color: _primaryColor, size: 18),
                          SizedBox(width: 8),
                          Text(
                            '${filteredDelivers.length} livreur${filteredDelivers.length > 1 ? 's' : ''}',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: _primaryColor,
                            ),
                          ),
                          Spacer(),
                          if (_searchQuery.isNotEmpty)
                            Text(
                              'Résultats pour "$_searchQuery"',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade500,
                              ),
                            ),
                        ],
                      ),
                    ),

                    // Liste des livreurs
                    Expanded(
                      child: filteredDelivers.isEmpty
                          ? _buildNoResultsState()
                          : ListView.builder(
                              physics: BouncingScrollPhysics(),
                              itemCount: filteredDelivers.length,
                              itemBuilder: (context, index) {
                                return _buildDeliverCard(filteredDelivers[index]);
                              },
                            ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}