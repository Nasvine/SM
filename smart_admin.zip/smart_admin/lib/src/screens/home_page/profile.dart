import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/constants/images.dart';
import 'package:smart_admin/src/constants/sizes.dart';
import 'package:smart_admin/src/controllers/auth/avis_contoller.dart';
import 'package:smart_admin/src/models/auth/user_model.dart';
import 'package:smart_admin/src/repository/authentification_repository.dart';
import 'package:smart_admin/src/repository/user_repository.dart';
import 'package:smart_admin/src/screens/auth/login_screen.dart';
import 'package:smart_admin/src/screens/auth/update_profile_screen.dart';
import 'package:smart_admin/src/screens/gain.dart';
import 'package:smart_admin/src/screens/home_page/settings_screen.dart';
import 'package:smart_admin/src/screens/settings/about_page.dart';
import 'package:smart_admin/src/screens/settings/policy_page.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:text_custom/text_custom.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:lottie/lottie.dart';

final _auth = FirebaseAuth.instance.currentUser!;

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.userFullName,
    required this.userEmail,
  });

  final String userFullName;
  final String userEmail;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final repository = Get.put(AuthentificationRepository());
  final user_repository = Get.put(UserRepository());
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  // Couleurs personnalisées pour le design
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _infoColor = Colors.blue;

  Future<void> deleteUserAccount() async {
    final user = FirebaseAuth.instance.currentUser;

    if (user != null) {
      final uid = user.uid;

      try {
        // Supprimer les données de Firestore (ex: collection users)
        await FirebaseFirestore.instance.collection('users').doc(uid).delete();

        // Supprimer le compte de Firebase Auth
        await user.delete();
      } on FirebaseAuthException catch (e) {
        if (e.code == 'requires-recent-login') {
          throw FirebaseAuthException(
            code: 'requires-recent-login',
            message: 'Vous devez vous reconnecter pour supprimer votre compte.',
          );
        } else {
          rethrow;
        }
      }
    }
  }

  void showAvisModal(BuildContext context) async {
    final AvisController avisController = Get.put(AvisController());
    await avisController.loadUserAvis();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          margin: EdgeInsets.only(top: 50),
          decoration: BoxDecoration(
            color: THelperFunctions.isDarkMode(context) 
                ? Colors.grey[900] 
                : Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(25),
              topRight: Radius.circular(25),
            ),
          ),
          child: Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
              left: 20,
              right: 20,
              top: 30,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header avec animation
                Container(
                  height: 60,
                  child: Lottie.asset(
                    'assets/images/review.json',
                    height: 50,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 10),
                
                Text(
                  avisController.existingAvisDoc != null
                      ? "Modifier votre avis"
                      : "Donnez votre avis",
                  style: TextStyle(
                    fontSize: 20, 
                    fontWeight: FontWeight.bold,
                    color: _primaryColor,
                  ),
                ),
                SizedBox(height: 20),

                // ⭐ Étoiles avec style amélioré
                Obx(
                  () => Container(
                    padding: EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: Colors.amber.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.amber.withOpacity(0.3)),
                    ),
                    child: Column(
                      children: [
                        Text(
                          'Notez votre expérience',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.amber.shade800,
                          ),
                        ),
                        SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(5, (index) {
                            return GestureDetector(
                              onTap: () =>
                                  avisController.selectedStars.value = index + 1,
                              child: Container(
                                margin: EdgeInsets.symmetric(horizontal: 4),
                                child: Icon(
                                  index < avisController.selectedStars.value
                                      ? Icons.star
                                      : Icons.star_border,
                                  color: Colors.amber,
                                  size: 35,
                                ),
                              ),
                            );
                          }),
                        ),
                        SizedBox(height: 5),
                        Text(
                          '${avisController.selectedStars.value}/5 étoiles',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.amber.shade700,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(height: 20),

                // 💬 Commentaire avec style amélioré
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: THelperFunctions.isDarkMode(context)
                        ? Colors.grey[800]
                        : Colors.grey[50],
                  ),
                  child: TextField(
                    controller: avisController.commentController,
                    maxLines: 4,
                    decoration: InputDecoration(
                      labelText: "Votre commentaire (optionnel)",
                      labelStyle: TextStyle(color: Colors.grey.shade600),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.all(16),
                      hintText: "Partagez votre expérience...",
                      hintStyle: TextStyle(color: Colors.grey.shade400),
                    ),
                  ),
                ),

                SizedBox(height: 25),

                // 📤 Bouton d'envoi stylisé
                Container(
                  width: double.infinity,
                  height: 55,
                  child: ElevatedButton(
                    onPressed: avisController.submitAvis,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _secondaryColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      elevation: 3,
                      shadowColor: _secondaryColor.withOpacity(0.3),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          avisController.existingAvisDoc != null
                              ? Icons.edit
                              : Icons.send,
                          size: 20,
                        ),
                        SizedBox(width: 8),
                        Text(
                          avisController.existingAvisDoc != null
                              ? "Modifier mon avis"
                              : "Publier mon avis",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildProfileHeader(UserModel user) {
    return Column(
      children: [
        // Carte de profil avec dégradé
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(25),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                _primaryColor.withOpacity(0.8),
                _secondaryColor.withOpacity(0.6),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: _primaryColor.withOpacity(0.3),
                blurRadius: 15,
                offset: Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            children: [
              // Avatar avec badge
              Stack(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(50),
                      child: user.profilePicture == null
                          ? Image(
                              image: AssetImage(ImageApp.tCover),
                              fit: BoxFit.cover,
                            )
                          : Image.network(
                              user.profilePicture!,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  color: Colors.grey[300],
                                  child: Icon(
                                    Icons.person,
                                    size: 40,
                                    color: Colors.grey[600],
                                  ),
                                );
                              },
                            ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white,
                        border: Border.all(color: _primaryColor, width: 2),
                      ),
                      child: Icon(
                        Icons.verified,
                        color: _successColor,
                        size: 15,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              
              // Informations utilisateur
              Text(
                "${user.fullName}",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 5),
              Text(
                "${user.email}",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.white.withOpacity(0.9),
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 5),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  "Administrateur",
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 20),
        
        // Bouton d'édition
        Container(
          width: 200,
          child: ElevatedButton(
            onPressed: () => Get.to(() => UpdateUserProfileScreen(user: user)),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: _primaryColor,
              side: BorderSide(color: _primaryColor, width: 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              elevation: 3,
              padding: EdgeInsets.symmetric(vertical: 12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.edit, size: 18),
                SizedBox(width: 8),
                Text(
                  "Modifier le profil",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMenuCard({
    required String title,
    required IconData icon,
    required VoidCallback onTap,
    Color? iconColor,
    Color? backgroundColor,
    bool isDanger = false,
  }) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          width: 45,
          height: 45,
          decoration: BoxDecoration(
            color: backgroundColor ?? (isDanger ? _errorColor.withOpacity(0.1) : _primaryColor.withOpacity(0.1)),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: iconColor ?? (isDanger ? _errorColor : _primaryColor),
            size: 22,
          ),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: isDanger ? _errorColor : null,
          ),
        ),
        trailing: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            color: Colors.grey.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(
            Icons.arrow_forward_ios,
            size: 14,
            color: Colors.grey,
          ),
        ),
      ),
    );
  }

  Future<void> _showLogoutConfirmation() async {
    await showDialog(
      context: context,
      builder: (context) => _buildConfirmationDialog(
        title: "Déconnexion",
        content: "Voulez-vous vraiment vous déconnecter ?",
        confirmText: "Se déconnecter",
        confirmColor: _warningColor,
        icon: Icons.logout,
      ),
    );
  }

  Future<void> _showDeleteAccountConfirmation() async {
    await showDialog(
      context: context,
      builder: (context) => _buildConfirmationDialog(
        title: "Supprimer le compte",
        content: "Cette action est irréversible. Toutes vos données seront perdues.",
        confirmText: "Supprimer",
        confirmColor: _errorColor,
        icon: Icons.warning_amber_rounded,
        isDanger: true,
      ),
    );
  }

  Widget _buildConfirmationDialog({
    required String title,
    required String content,
    required String confirmText,
    required Color confirmColor,
    required IconData icon,
    bool isDanger = false,
  }) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(25),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: confirmColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                size: 35,
                color: confirmColor,
              ),
            ),
            SizedBox(height: 20),
            Text(
              title,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDanger ? _errorColor : null,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 15),
            Text(
              content,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 25),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context, false),
                    style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12),
                      side: BorderSide(color: Colors.grey.shade400),
                    ),
                    child: Text(
                      'Annuler',
                      style: TextStyle(color: Colors.grey.shade700),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context, true);
                      if (isDanger) {
                        _performAccountDeletion();
                      } else {
                        _performLogout();
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: confirmColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text(confirmText),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _performLogout() async {
    try {
      await _googleSignIn.disconnect();
      repository.logout();
      Get.offAll(() => LoginScreen());
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Erreur lors de la déconnexion : $e"),
          backgroundColor: _errorColor,
        ),
      );
    }
  }

  void _performAccountDeletion() async {
    try {
      await deleteUserAccount();
      Get.offAll(() => LoginScreen());
    } catch (e) {
      if (e is FirebaseAuthException && e.code == 'requires-recent-login') {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Reconnectez-vous pour supprimer votre compte.'),
            backgroundColor: _warningColor,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erreur: ${e.toString()}'),
            backgroundColor: _errorColor,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: THelperFunctions.isDarkMode(context) 
          ? Colors.grey[900]
          : Colors.grey[50],
      body: StreamBuilder<UserModel>(
        stream: user_repository.fetchUserDetailsRealTime(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: _primaryColor),
                  SizedBox(height: 16),
                  Text(
                    'Chargement du profil...',
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ],
              ),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 64, color: _errorColor),
                  SizedBox(height: 16),
                  Text(
                    'Une erreur est survenue',
                    style: TextStyle(fontSize: 16, color: _errorColor),
                  ),
                ],
              ),
            );
          } else if (!snapshot.hasData || snapshot.data == UserModel.empty()) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.person_off, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text(
                    'Aucun utilisateur trouvé',
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ],
              ),
            );
          } else {
            final user = snapshot.data!;
            return SingleChildScrollView(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  _buildProfileHeader(user),
                  SizedBox(height: 30),
                  
                  // Section menu
                  Text(
                    "Paramètres et Préférences",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: THelperFunctions.isDarkMode(context)
                          ? Colors.white
                          : Colors.black87,
                    ),
                  ),
                  SizedBox(height: 15),
                  
                  _buildMenuCard(
                    title: "Modifier le profil",
                    icon: Icons.person_outline,
                    onTap: () => Get.to(() => UpdateUserProfileScreen(user: user)),
                    iconColor: _infoColor,
                    backgroundColor: _infoColor.withOpacity(0.1),
                  ),
                  
                  _buildMenuCard(
                    title: "Paramètres",
                    icon: Icons.settings,
                    onTap: () => Get.to(() => SettingsScreen()),
                    iconColor: Colors.purple,
                    backgroundColor: Colors.purple.withOpacity(0.1),
                  ),
                  
                  _buildMenuCard(
                    title: "À propos",
                    icon: Icons.info,
                    onTap: () => Get.to(() => AboutOwnerPage()),
                    iconColor: _infoColor,
                    backgroundColor: _infoColor.withOpacity(0.1),
                  ),
                  
                  _buildMenuCard(
                    title: "Politique de confidentialité",
                    icon: Icons.privacy_tip,
                    onTap: () => Get.to(() => PrivacyPolicyOwnerPage()),
                    iconColor: Colors.teal,
                    backgroundColor: Colors.teal.withOpacity(0.1),
                  ),
                  
                  _buildMenuCard(
                    title: "Donner mon avis",
                    icon: LineAwesomeIcons.notes_medical_solid,
                    onTap: () => showAvisModal(context),
                    iconColor: Colors.amber,
                    backgroundColor: Colors.amber.withOpacity(0.1),
                  ),
                  
                  // Section actions critiques
                  SizedBox(height: 20),
                  Text(
                    "Actions",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: THelperFunctions.isDarkMode(context)
                          ? Colors.white70
                          : Colors.grey.shade700,
                    ),
                  ),
                  SizedBox(height: 10),
                  
                  _buildMenuCard(
                    title: "Se déconnecter",
                    icon: Icons.logout,
                    onTap: _showLogoutConfirmation,
                    iconColor: _warningColor,
                    backgroundColor: _warningColor.withOpacity(0.1),
                    isDanger: true,
                  ),
                  
                  _buildMenuCard(
                    title: "Supprimer mon compte",
                    icon: Icons.delete_forever,
                    onTap: _showDeleteAccountConfirmation,
                    iconColor: _errorColor,
                    backgroundColor: _errorColor.withOpacity(0.1),
                    isDanger: true,
                  ),
                  
                  SizedBox(height: 30),
                  
                  // Footer
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.security, size: 16, color: Colors.grey),
                        SizedBox(width: 8),
                        Text(
                          "Compte sécurisé • ${user.email}",
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}