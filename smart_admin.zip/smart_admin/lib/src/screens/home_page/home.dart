import 'package:get/get.dart';
import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/models/auth/user_model.dart';
import 'package:smart_admin/src/models/order_model.dart';
import 'package:smart_admin/src/screens/orders/order_step.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:text_custom/text_custom.dart';
import 'package:intl/intl.dart';
import 'package:smart_admin/src/models/transactions/transaction_model.dart';
import 'package:lottie/lottie.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.userFullName,
    required this.userEmail,
  });

  final String userFullName;
  final String userEmail;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final User? _currentUser = FirebaseAuth.instance.currentUser;
  UserModel clientInfo = UserModel.empty();
  bool _hasFetchedClientInfo = false;
  bool _isDateFormatInitialized = false;

  // Cache pour éviter les reconstructions inutiles
  final Map<String, dynamic> _streamCache = {};

  // Mapping des statuts en français avec couleurs
  final Map<String, Map<String, dynamic>> _statusConfig = {
    'NewOrder': {
      'text': 'Nouvelle Commande',
      'color': Colors.blue,
      'icon': Icons.new_releases,
    },
    'assigned': {
      'text': 'Assignée',
      'color': Colors.orange,
      'icon': Icons.assignment_ind,
    },
    'accepted': {
      'text': 'Acceptée',
      'color': Colors.lightGreen,
      'icon': Icons.check_circle,
    },
    'pending': {
      'text': 'En Attente',
      'color': Colors.amber,
      'icon': Icons.access_time,
    },
    'delivered': {
      'text': 'Livrée',
      'color': Colors.green,
      'icon': Icons.local_shipping,
    },
    'paymentstep': {
      'text': 'Paiement',
      'color': Colors.purple,
      'icon': Icons.payment,
    },
    'finish': {'text': 'Terminée', 'color': Colors.teal, 'icon': Icons.flag},
    'cancelled': {'text': 'Annulée', 'color': Colors.red, 'icon': Icons.cancel},
    'refused': {
      'text': 'Refusée',
      'color': Colors.deepOrange,
      'icon': Icons.block,
    },
  };

  @override
  void initState() {
    super.initState();
    _initializeDateFormatting();
  }

  Future<void> _initializeDateFormatting() async {
    // Cette initialisation est nécessaire pour le package intl
    await _loadLocaleData();
    setState(() {
      _isDateFormatInitialized = true;
    });
  }

  Future<void> _loadLocaleData() async {
    // Simuler le chargement des données de locale
    await Future.delayed(const Duration(milliseconds: 100));
  }

  String _formatDate(DateTime date, {String format = 'dd/MM/yy - HH:mm'}) {
    if (!_isDateFormatInitialized) {
      return 'Chargement...';
    }
    try {
      return DateFormat(format, 'fr_FR').format(date);
    } catch (e) {
      // Format de secours si l'initialisation échoue
      return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    }
  }

  String _formatDateLong(DateTime date) {
    if (!_isDateFormatInitialized) {
      return 'Chargement...';
    }
    try {
      return DateFormat('EEEE d MMMM y - HH:mm', 'fr_FR').format(date);
    } catch (e) {
      // Format de secours
      final days = [
        'Lundi',
        'Mardi',
        'Mercredi',
        'Jeudi',
        'Vendredi',
        'Samedi',
        'Dimanche',
      ];
      final months = [
        'Janvier',
        'Février',
        'Mars',
        'Avril',
        'Mai',
        'Juin',
        'Juillet',
        'Août',
        'Septembre',
        'Octobre',
        'Novembre',
        'Décembre',
      ];
      return '${days[date.weekday - 1]} ${date.day} ${months[date.month - 1]} ${date.year} - ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    }
  }

  @override
  void dispose() {
    _streamCache.clear();
    super.dispose();
  }

  String _getStatusText(String status) {
    return _statusConfig[status]?['text'] ?? status;
  }

  Color _getStatusColor(String status) {
    return _statusConfig[status]?['color'] ?? Colors.grey;
  }

  IconData _getStatusIcon(String status) {
    return _statusConfig[status]?['icon'] ?? Icons.info;
  }

  Stream<double> getBalanceTotale() {
    const key = 'balance_totale';
    if (!_streamCache.containsKey(key)) {
      _streamCache[key] = FirebaseFirestore.instance
          .collection('transactions')
          .where('status', isEqualTo: 'completed')
          .snapshots()
          .map((snapshot) {
            if (snapshot.docs.isEmpty) return 0.0;

            double totalPayments = 0;
            double totalWithdrawals = 0;

            for (var doc in snapshot.docs) {
              final data = doc.data();
              final amount = (data['amount'] as num).toDouble();
              final type = data['type'];

              if (type == 'payment' || type == 'cash') {
                totalPayments += amount;
              } else if (type == 'withdrawal') {
                totalWithdrawals += amount;
              }
            }

            return totalPayments - totalWithdrawals;
          });
    }
    return _streamCache[key];
  }

  Stream<double> getUserBalanceToday() {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return FirebaseFirestore.instance
        .collection('transactions')
        .where('status', isEqualTo: 'completed')
        .where(
          'createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay),
          isLessThan: Timestamp.fromDate(endOfDay),
        )
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return 0.0;

          double totalPayments = 0;
          double totalWithdrawals = 0;

          for (var doc in snapshot.docs) {
            final data = doc.data();
            final amount = (data['amount'] as num).toDouble();
            final type = data['type'];

            if (type == 'payment') {
              totalPayments += amount;
            } else if (type == 'withdrawal') {
              totalWithdrawals += amount;
            }
          }

          return totalPayments - totalWithdrawals;
        });
  }

  Stream<int> getOrderPendingTotal(String userId) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('paymentStatus', isEqualTo: "Pending")
        .where(
          'createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay),
          isLessThan: Timestamp.fromDate(endOfDay),
        )
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Stream<int> getTotalDeliver() {
    const key = 'total_deliver';
    if (!_streamCache.containsKey(key)) {
      _streamCache[key] = FirebaseFirestore.instance
          .collection('users')
          .where('userRole', isEqualTo: 'Deliver')
          .snapshots()
          .map((snapshot) => snapshot.docs.length);
    }
    return _streamCache[key];
  }

  Stream<int> getTotalDeliverAvailable() {
    const key = 'total_deliver_available';
    if (!_streamCache.containsKey(key)) {
      _streamCache[key] = FirebaseFirestore.instance
          .collection('users')
          .where('userRole', isEqualTo: 'Deliver')
          .where('isAvailable', isEqualTo: true)
          .snapshots()
          .map((snapshot) => snapshot.docs.length);
    }
    return _streamCache[key];
  }

  Stream<int> getTotalClient() {
    const key = 'total_client';
    if (!_streamCache.containsKey(key)) {
      _streamCache[key] = FirebaseFirestore.instance
          .collection('users')
          .where('userRole', isEqualTo: 'Client')
          .snapshots()
          .map((snapshot) => snapshot.docs.length);
    }
    return _streamCache[key];
  }

  Stream<int> getTotalOrders() {
    const key = 'total_orders';
    if (!_streamCache.containsKey(key)) {
      _streamCache[key] = FirebaseFirestore.instance
          .collection('orders')
          .snapshots()
          .map((snapshot) => snapshot.docs.length);
    }
    return _streamCache[key];
  }

  Stream<OrderModel?> getOrderPendingFirstTotal(String userId) {
    return FirebaseFirestore.instance
        .collection('orders')
        .orderBy("createdAt", descending: true)
        .where('paymentStatus', isEqualTo: "Pending")
        .limit(1)
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return null;
          return OrderModel.fromSnapshot(snapshot.docs.first);
        });
  }

  Stream<List<OrderModel>> getOrdersFinishLists(String userId) {
    return FirebaseFirestore.instance
        .collection('orders')
        .orderBy("createdAt", descending: true)
        .where('paymentStatus', isEqualTo: "Completed")
        .limit(5)
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) => OrderModel.fromSnapshot(doc)).toList(),
        );
  }

  Stream<int> getOrderFinishTodayTotal(String userId) {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('status', isEqualTo: "completed")
        .where(
          'createdAt',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay),
          isLessThan: Timestamp.fromDate(endOfDay),
        )
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Stream<int> getOrderFinishTotal(String userId) {
    return FirebaseFirestore.instance
        .collection('orders')
        .where(
          'deliverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('status', isEqualTo: "completed")
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  Stream<List<TransactionModel>> getTransactions() {
    return FirebaseFirestore.instance
        .collection('transactions')
        .orderBy('createdAt', descending: true)
        .limit(10)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => TransactionModel.fromSnapshot(doc))
              .toList(),
        );
  }

  void _getClientInfo(String userId) async {
    if (_hasFetchedClientInfo) return;

    final firebase = FirebaseFirestore.instance;
    final data = await firebase.collection("users").doc(userId).get();
    if (data.exists) {
      final client = UserModel.fromSnapshot(data);
      if (mounted) {
        setState(() {
          clientInfo = client;
          _hasFetchedClientInfo = true;
        });
      }
    }
  }

  Widget _buildStatCard({
    required String title,
    required Stream<dynamic> stream,
    required Color color,
    String? suffix,
    bool isCurrency = false,
    IconData? icon,
  }) {
    return Container(
      width: _getCardWidth(context),
      height: 90,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 16, color: Colors.white70),
                const SizedBox(width: 4),
              ],
              Expanded(
                child: TextCustom(
                  TheText: title,
                  TheTextSize: _getResponsiveTextSize(context, baseSize: 12),
                  TheTextFontWeight: FontWeight.w600,
                  TheTextColor: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          StreamBuilder(
            stream: stream,
            builder: (context, asyncSnapshot) {
              if (!asyncSnapshot.hasData) {
                return SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation(Colors.white70),
                  ),
                );
              }

              final data = asyncSnapshot.data;
              String displayText = data.toString();

              if (isCurrency && data is num) {
                displayText = '${NumberFormat().format(data.toInt())} F';
              }

              if (suffix != null && !isCurrency) {
                displayText += suffix;
              }

              return TextCustom(
                TheText: displayText,
                TheTextSize: _getResponsiveTextSize(context, baseSize: 16),
                TheTextFontWeight: FontWeight.bold,
                TheTextColor: Colors.white,
              );
            },
          ),
        ],
      ),
    );
  }

  double _getCardWidth(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    if (screenWidth > 600) {
      return (screenWidth - 48) / 2; // Pour tablettes
    }
    return (screenWidth - 40) / 2; // Pour mobiles
  }

  double _getResponsiveTextSize(
    BuildContext context, {
    required double baseSize,
  }) {
    final screenWidth = MediaQuery.of(context).size.width;
    if (screenWidth > 600) {
      return baseSize + 2; // Plus grand sur tablettes
    }
    return baseSize;
  }

  Widget _buildStatusBadge(String status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: _getStatusColor(status).withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _getStatusColor(status)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            _getStatusIcon(status),
            size: 14,
            color: _getStatusColor(status),
          ),
          const SizedBox(width: 4),
          Flexible(
            child: TextCustom(
              TheText: _getStatusText(status),
              TheTextSize: _getResponsiveTextSize(context, baseSize: 12),
              TheTextFontWeight: FontWeight.w600,
              TheTextColor: _getStatusColor(status),
              TheTextMaxLines: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    return Center(
      child: SizedBox(
        height: 30,
        width: 30,
        child: CircularProgressIndicator(strokeWidth: 3),
      ),
    );
  }

  Widget _buildNoDataWidget(String message) {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: THelperFunctions.isDarkMode(context)
            ? Colors.grey[800]!.withOpacity(0.3)
            : Colors.grey[100]!,
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset(
              height: 120,
              width: 120,
              'assets/images/no_data.json',
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: TextCustom(
                TheText: message,
                TheTextSize: _getResponsiveTextSize(context, baseSize: 14),
                TheTextColor: Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, {String? subtitle}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: TextCustom(
                TheText: title,
                TheTextSize: _getResponsiveTextSize(context, baseSize: 18),
                TheTextFontWeight: FontWeight.bold,
              ),
            ),
            if (subtitle != null)
              TextCustom(
                TheText: subtitle,
                TheTextSize: _getResponsiveTextSize(context, baseSize: 12),
                TheTextColor: Colors.grey,
              ),
          ],
        ),
        const SizedBox(height: 8),
        Divider(color: Colors.grey[300]),
        const SizedBox(height: 12),
      ],
    );
  }

  Widget _buildCurrentDeliverySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader('📦 Livraison en cours'),
        Container(
          width: double.infinity,
          constraints: const BoxConstraints(minHeight: 320),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                ColorApp.tPrimaryColor.withOpacity(0.1),
                ColorApp.tsecondaryColor.withOpacity(0.05),
              ],
            ),
            border: Border.all(color: ColorApp.tPrimaryColor.withOpacity(0.2)),
          ),
          child: StreamBuilder<OrderModel?>(
            stream: getOrderPendingFirstTotal(_currentUser!.uid),
            builder: (context, asyncSnapshot) {
              if (asyncSnapshot.connectionState == ConnectionState.waiting) {
                return _buildLoadingIndicator();
              }

              if (!asyncSnapshot.hasData || asyncSnapshot.data == null) {
                return _buildNoDataWidget("Aucune livraison en cours");
              }

              final order = asyncSnapshot.data!;
              if (!_hasFetchedClientInfo) {
                _getClientInfo(order.userRef!.id);
              }

              return InkWell(
                onTap: () {
                  Get.to(
                    () => OrderStep(
                      status: order.status,
                      orderId: order.uid!,
                      amount: order.amount,
                      carId: '',
                      userCreatedId: order.userRef!.id,
                    ),
                  );
                },
                child: _buildOrderDetails(order),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildOrderDetails(OrderModel order) {
    return Column(
      children: [
        // Header avec statut et date
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: TextCustom(
                      TheText: 'Commande #${order.orderId}',
                      TheTextSize: _getResponsiveTextSize(
                        context,
                        baseSize: 16,
                      ),
                      TheTextFontWeight: FontWeight.bold,
                    ),
                  ),
                  _buildStatusBadge(
                    order.status,
                  ), // ICI le statut est maintenant affiché en français
                ],
              ),
              const SizedBox(height: 8),
              TextCustom(
                TheText: _formatDateLong(order.createdAt.toDate()),
                TheTextSize: _getResponsiveTextSize(context, baseSize: 12),
                TheTextColor: Colors.grey[700],
              ),
            ],
          ),
        ),

        const SizedBox(height: 16),

        // Informations client
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: ColorApp.tPrimaryColor.withOpacity(0.2),
                ),
                child: Icon(Icons.person, color: ColorApp.tPrimaryColor),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextCustom(
                      TheText: 'Client',
                      TheTextSize: _getResponsiveTextSize(
                        context,
                        baseSize: 12,
                      ),
                      TheTextColor: Colors.grey,
                    ),
                    TextCustom(
                      TheText: clientInfo.fullName,
                      TheTextSize: _getResponsiveTextSize(
                        context,
                        baseSize: 14,
                      ),
                      TheTextFontWeight: FontWeight.w600,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 16),

        // Informations de livraison
        Row(
          children: [
            Expanded(
              child: _buildInfoCard(
                icon: Icons.attach_money,
                title: 'Montant',
                value: '${order.amount.toInt()} F',
                color: Colors.green,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildInfoCard(
                icon: Icons.directions,
                title: 'Distance',
                value: '${order.distance.toStringAsFixed(1)} km',
                color: Colors.blue,
              ),
            ),
          ],
        ),

        const SizedBox(height: 16),

        // Points de livraison
        _buildLocationSection(
          icon: Icons.store,
          title: "Point de retrait",
          address: order.withdrawalPoint.address,
          phoneNumber: "${order.numeroWithdrawal}",
        ),

        const SizedBox(height: 12),

        _buildLocationSection(
          icon: Icons.location_pin,
          title: "Point de destination",
          address: order.destinationLocation.address,
          phoneNumber: clientInfo.phoneNumber,
        ),
      ],
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(height: 4),
          TextCustom(
            TheText: title,
            TheTextSize: _getResponsiveTextSize(context, baseSize: 10),
            TheTextColor: Colors.grey,
          ),
          TextCustom(
            TheText: value,
            TheTextSize: _getResponsiveTextSize(context, baseSize: 14),
            TheTextFontWeight: FontWeight.bold,
            TheTextColor: color,
          ),
        ],
      ),
    );
  }

  Widget _buildLocationSection({
    required IconData icon,
    required String title,
    required String address,
    required String phoneNumber,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: ColorApp.tsecondaryColor.withOpacity(0.2),
            ),
            child: Icon(icon, color: ColorApp.tsecondaryColor),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextCustom(
                  TheText: title,
                  TheTextSize: _getResponsiveTextSize(context, baseSize: 12),
                  TheTextFontWeight: FontWeight.w600,
                ),
                const SizedBox(height: 4),
                TextCustom(
                  TheText: address,
                  TheTextSize: _getResponsiveTextSize(context, baseSize: 12),
                  TheTextMaxLines: 2,
                  TheTextColor: Colors.grey[700],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          _buildPhoneButton(phoneNumber),
        ],
      ),
    );
  }

  Widget _buildPhoneButton(String phoneNumber) {
    return InkWell(
      onTap: () async {
        final formattedNumber = "tel:+229$phoneNumber";
        final Uri phoneUri = Uri.parse(formattedNumber);

        if (await canLaunchUrl(phoneUri)) {
          await launchUrl(phoneUri);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Impossible d\'appeler le $phoneNumber'),
              backgroundColor: Colors.red,
            ),
          );
        }
      },
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.green.withOpacity(0.2),
          border: Border.all(color: Colors.green),
        ),
        child: Icon(Icons.phone, color: Colors.green, size: 20),
      ),
    );
  }

  Widget _buildRecentDeliveriesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader('📋 Livraisons récentes', subtitle: '5 commandes'),
        StreamBuilder<List<OrderModel>>(
          stream: getOrdersFinishLists(_currentUser!.uid),
          builder: (context, asyncSnapshot) {
            if (asyncSnapshot.connectionState == ConnectionState.waiting) {
              return _buildLoadingIndicator();
            }

            if (!asyncSnapshot.hasData || asyncSnapshot.data!.isEmpty) {
              return _buildNoDataWidget("Aucune livraison récente");
            }

            final orders = asyncSnapshot.data!;

            return ListView.builder(
              itemCount: orders.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                final orderItem = orders[index];


                
                return InkWell(
                  onTap: (){
                    Get.to(
                    () => OrderStep(
                      status: orderItem.status,
                      orderId: orderItem.uid!,
                      amount: orderItem.amount,
                      carId: '',
                      userCreatedId: orderItem.userRef!.id,
                    ),
                  );
                  },
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: THelperFunctions.isDarkMode(context)
                          ? Colors.grey[800]!.withOpacity(0.3)
                          : Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.blue.withOpacity(0.1),
                          ),
                          child: Icon(
                            Icons.local_shipping,
                            color: Colors.blue,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Flexible(
                                    child: TextCustom(
                                      TheText: "#${orderItem.orderId}",
                                      TheTextSize: _getResponsiveTextSize(
                                        context,
                                        baseSize: 14,
                                      ),
                                      TheTextFontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  TextCustom(
                                    TheText: "${orderItem.amount.toInt()} F",
                                    TheTextSize: _getResponsiveTextSize(
                                      context,
                                      baseSize: 14,
                                    ),
                                    TheTextFontWeight: FontWeight.bold,
                                    TheTextColor: ColorApp.tPrimaryColor,
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Flexible(
                                    child: TextCustom(
                                      TheText: _formatDate(
                                        orderItem.createdAt.toDate(),
                                      ),
                                      TheTextSize: _getResponsiveTextSize(
                                        context,
                                        baseSize: 12,
                                      ),
                                      TheTextColor: Colors.grey,
                                    ),
                                  ),
                                  TextCustom(
                                    TheText:
                                        "${orderItem.distance.toStringAsFixed(1)} km",
                                    TheTextSize: _getResponsiveTextSize(
                                      context,
                                      baseSize: 12,
                                    ),
                                    TheTextColor: Colors.grey,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }

  Widget _buildTransactionHistorySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          '💳 Historique des transactions',
          subtitle: '10 transactions',
        ),
        StreamBuilder<List<TransactionModel>>(
          stream: getTransactions(),
          builder: (context, asyncSnapshot) {
            if (asyncSnapshot.connectionState == ConnectionState.waiting) {
              return _buildLoadingIndicator();
            }

            if (!asyncSnapshot.hasData || asyncSnapshot.data!.isEmpty) {
              return _buildNoDataWidget("Aucune transaction trouvée");
            }

            final transactions = asyncSnapshot.data!;

            return ListView.builder(
              itemCount: transactions.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                final transactionItem = transactions[index];
                return _buildTransactionItem(transactionItem);
              },
            );
          },
        ),
      ],
    );
  }

  Widget _buildTransactionItem(TransactionModel transaction) {
    Color typeColor = transaction.type == "payment" ? Colors.green : Colors.red;
    IconData typeIcon = transaction.type == "payment"
        ? Icons.arrow_downward
        : Icons.arrow_upward;

    Color statusColor = Colors.grey;
    switch (transaction.status) {
      case "completed":
        statusColor = Colors.green;
        break;
      case "failed":
        statusColor = Colors.red;
        break;
      case "pending":
        statusColor = Colors.orange;
        break;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: THelperFunctions.isDarkMode(context)
            ? Colors.grey[800]!.withOpacity(0.3)
            : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: typeColor.withOpacity(0.1),
            ),
            child: Icon(typeIcon, color: typeColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextCustom(
                  TheText: "Transaction #${transaction.reference}",
                  TheTextSize: _getResponsiveTextSize(context, baseSize: 14),
                  TheTextFontWeight: FontWeight.w600,
                ),
                const SizedBox(height: 4),
                TextCustom(
                  TheText: _formatDate(transaction.createdAt.toDate()),
                  TheTextSize: _getResponsiveTextSize(context, baseSize: 12),
                  TheTextColor: Colors.grey,
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TextCustom(
                TheText:
                    "${transaction.type == "payment" ? '+' : '-'} ${transaction.amount.toStringAsFixed(2)} F",
                TheTextSize: _getResponsiveTextSize(context, baseSize: 16),
                TheTextColor: typeColor,
                TheTextFontWeight: FontWeight.bold,
              ),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TextCustom(
                  TheText: _getTransactionStatusText(transaction.status),
                  TheTextSize: _getResponsiveTextSize(context, baseSize: 10),
                  TheTextColor: statusColor,
                  TheTextFontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getTransactionStatusText(String status) {
    switch (status) {
      case "completed":
        return "Complétée";
      case "failed":
        return "Échouée";
      case "pending":
        return "En attente";
      default:
        return status;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_currentUser == null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.error_outline, size: 64, color: Colors.red),
              const SizedBox(height: 16),
              TextCustom(
                TheText: 'Utilisateur non connecté',
                TheTextSize: 18,
                TheTextColor: Colors.red,
              ),
            ],
          ),
        ),
      );
    }

    if (!_isDateFormatInitialized) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 60,
                width: 60,
                child: CircularProgressIndicator(strokeWidth: 4),
              ),
              const SizedBox(height: 20),
              TextCustom(
                TheText: 'Chargement...',
                TheTextSize: 16,
                TheTextColor: Colors.grey,
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: THelperFunctions.isDarkMode(context)
          ? Colors.grey[900]
          : Colors.grey[50],
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Header Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.purple.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              TextCustom(
                                TheText:
                                    "Bonjour, ${widget.userFullName.split(' ').first}!",
                                TheTextSize: _getResponsiveTextSize(
                                  context,
                                  baseSize: 18,
                                ),
                                TheTextFontWeight: FontWeight.bold,
                                TheTextColor: Colors.white,
                              ),
                              const SizedBox(height: 4),
                              TextCustom(
                                TheText: "Revenu Total",
                                TheTextSize: _getResponsiveTextSize(
                                  context,
                                  baseSize: 14,
                                ),
                                TheTextColor: Colors.white70,
                              ),
                              const SizedBox(height: 8),
                              StreamBuilder(
                                stream: getBalanceTotale(),
                                builder: (context, asyncSnapshot) {
                                  if (!asyncSnapshot.hasData) {
                                    return SizedBox(
                                      height: 24,
                                      width: 24,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor: AlwaysStoppedAnimation(
                                          Colors.white70,
                                        ),
                                      ),
                                    );
                                  }
                                  return TextCustom(
                                    TheText:
                                        "${NumberFormat().format(asyncSnapshot.data!.toInt())} F",
                                    TheTextSize: _getResponsiveTextSize(
                                      context,
                                      baseSize: 24,
                                    ),
                                    TheTextFontWeight: FontWeight.bold,
                                    TheTextColor: Colors.white,
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 60,
                          width: 60,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.2),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.3),
                            ),
                          ),
                          child: Icon(
                            Icons.bar_chart,
                            color: Colors.white,
                            size: 30,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Statistics Grid - Layout responsive
              LayoutBuilder(
                builder: (context, constraints) {
                  final isTablet = constraints.maxWidth > 600;
                  final crossAxisCount = isTablet ? 4 : 2;
                  final childAspectRatio = isTablet ? 1.2 : 1.6;

                  return StreamBuilder(
                    stream: getTotalClient(),
                    builder: (context, snapshot) {
                      return GridView(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: crossAxisCount,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                          childAspectRatio: childAspectRatio,
                        ),
                        children: [
                          _buildStatCard(
                            title: "Clients",
                            stream: getTotalClient(),
                            color: const Color(0xFF667eea),
                            icon: Icons.people,
                          ),
                          _buildStatCard(
                            title: "Livreurs",
                            stream: getTotalDeliver(),
                            color: const Color(0xFFf093fb),
                            icon: Icons.delivery_dining,
                          ),
                          _buildStatCard(
                            title: "Commandes",
                            stream: getTotalOrders(),
                            color: const Color(0xFF4facfe),
                            icon: Icons.shopping_cart,
                          ),
                          _buildStatCard(
                            title: "Livreurs Disponibles",
                            stream: getTotalDeliverAvailable(),
                            color: const Color(0xFF43e97b),
                            icon: Icons.verified_user,
                          ),
                          _buildStatCard(
                            title: "Gains Aujourd'hui",
                            stream: getUserBalanceToday(),
                            color: const Color(0xFFfa709a),
                            isCurrency: true,
                            icon: Icons.today,
                          ),
                          _buildStatCard(
                            title: "Courses Aujourd'hui",
                            stream: getOrderFinishTodayTotal(_currentUser!.uid),
                            color: const Color.fromARGB(255, 237, 107, 7),
                            icon: Icons.local_shipping,
                          ),
                        ],
                      );
                    },
                  );
                },
              ),

              const SizedBox(height: 24),

              // Current Delivery Section
              _buildCurrentDeliverySection(),

              const SizedBox(height: 24),

              // Recent Deliveries Section
              _buildRecentDeliveriesSection(),

              const SizedBox(height: 24),

              // Transaction History Section
              _buildTransactionHistorySection(),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
