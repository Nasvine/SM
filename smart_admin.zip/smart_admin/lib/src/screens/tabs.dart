import 'package:smart_admin/src/constants/colors.dart';
import 'package:smart_admin/src/models/auth/notification_model.dart';
import 'package:smart_admin/src/repository/authentification_repository.dart';
import 'package:smart_admin/src/screens/chat/chat_list_screen.dart';
import 'package:smart_admin/src/screens/drawer/drawer_listTile.dart';
import 'package:smart_admin/src/screens/home_page/home.dart';
import 'package:smart_admin/src/screens/home_page/profile.dart';
import 'package:smart_admin/src/screens/home_page/settings_screen.dart';
import 'package:smart_admin/src/screens/notification.dart';
import 'package:smart_admin/src/screens/orders/orders.dart';
import 'package:smart_admin/src/screens/users/deliver_list.dart';
import 'package:smart_admin/src/screens/users/user_list.dart';
import 'package:smart_admin/src/utils/helpers/helper_function.dart';
import 'package:smart_admin/src/utils/texts/text_custom.dart';
import 'package:smart_admin/src/utils/widget_theme/circle_icon_custom.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:line_icons/line_icons.dart';
import 'package:lottie/lottie.dart';
import 'drawer/drawer_header.dart';

class TabsScreen extends StatefulWidget {
  const TabsScreen({super.key, this.initialIndex = 0});
  final int initialIndex;

  @override
  State<TabsScreen> createState() => _TabsScreenState();
}

class _TabsScreenState extends State<TabsScreen> {
  final controller = Get.put(TabsScreenController());
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Couleurs personnalisées pour le design
  final Color _primaryColor = ColorApp.tPrimaryColor;
  final Color _secondaryColor = ColorApp.tsecondaryColor;
  final Color _successColor = Colors.green;
  final Color _warningColor = Colors.orange;
  final Color _errorColor = Colors.red;
  final Color _infoColor = Colors.blue;

  Stream<int> getNotificationTotal(String userId) {
    return FirebaseFirestore.instance
        .collection('notifications')
        .where(
          'receiverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(userId),
        )
        .where('isRead', isEqualTo: false)
        .snapshots()
        .map((snapshot) {
          if (snapshot.docs.isEmpty) return 0;
          return snapshot.docs.length;
        });
  }

  PreferredSizeWidget  _buildCustomAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: Padding(
        padding: const EdgeInsets.only(left: 10),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _primaryColor.withOpacity(0.1),
          ),
          child: IconButton(
            onPressed: () => _scaffoldKey.currentState?.openDrawer(),
            icon: Icon(
              Icons.menu_rounded,
              color: _primaryColor,
              size: 22,
            ),
          ),
        ),
      ),
      title: Obx(() {
        final index = controller._selectedIndex.value;
        String title;

        switch (index) {
          case 0:
            title = 'Tableau de Bord';
            break;
          case 1:
            title = 'Gestion des Courses';
            break;
          case 2:
            title = 'Messages';
            break;
          case 3:
            title = 'Mon Profil';
            break;
          default:
            title = 'SmartService Admin';
        }

        return Text(
          title,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: THelperFunctions.isDarkMode(context)
                ? Colors.white
                : Colors.black87,
          ),
        );
      }),
      actions: [
        // Bouton notifications avec badge stylisé
        Padding(
          padding: const EdgeInsets.only(right: 15),
          child: StreamBuilder(
            stream: getNotificationTotal(FirebaseAuth.instance.currentUser!.uid),
            builder: (context, asyncSnapshot) {
              final count = asyncSnapshot.data ?? 0;
              return Stack(
                children: [
                  Container(
                    width: 45,
                    height: 45,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _primaryColor.withOpacity(0.1),
                    ),
                    child: IconButton(
                      onPressed: () async {
                        final notifications = await FirebaseFirestore.instance
                            .collection('notifications')
                            .where(
                              'receiverRef',
                              isEqualTo: FirebaseFirestore.instance
                                  .collection('users')
                                  .doc(FirebaseAuth.instance.currentUser!.uid),
                            )
                            .get();

                        for (final doc in notifications.docs) {
                          final data = NotificationModel.fromSnapshot(doc);
                          if (data.isRead == false) {
                            await FirebaseFirestore.instance
                                .collection('notifications')
                                .doc(doc.id)
                                .update({'isRead': true});
                          }
                        }
                        Get.to(() => NotificationScreen());
                      },
                      icon: Icon(
                        Icons.notifications_outlined,
                        color: _primaryColor,
                        size: 22,
                      ),
                    ),
                  ),
                  if (count > 0)
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _errorColor,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 20,
                          minHeight: 20,
                        ),
                        child: Text(
                          count > 9 ? '9+' : count.toString(),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildCustomBottomNavBar() {
    return Container(
      margin: EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: THelperFunctions.isDarkMode(context)
            ? Colors.grey[900]
            : Colors.white,
        borderRadius: BorderRadius.circular(25),
        boxShadow: [
          BoxShadow(
            blurRadius: 20,
            spreadRadius: 1,
            color: Colors.black.withOpacity(0.1),
          ),
        ],
        border: Border.all(
          color: Colors.grey.withOpacity(0.2),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
        child: GNav(
          rippleColor: _primaryColor.withOpacity(0.1),
          hoverColor: _primaryColor.withOpacity(0.1),
          gap: 8,
          activeColor: Colors.white,
          iconSize: 22,
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          duration: Duration(milliseconds: 400),
          tabBackgroundColor: _primaryColor,
          color: THelperFunctions.isDarkMode(context)
              ? Colors.white70
              : Colors.grey[700]!,
          tabs: [
            GButton(
              icon: LineIcons.home,
              text: 'Accueil',
              textStyle: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            GButton(
              icon: Icons.local_shipping,
              text: 'Courses',
              textStyle: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            GButton(
              icon: LineIcons.comments,
              text: 'Messages',
              textStyle: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            GButton(
              icon: LineIcons.user,
              text: 'Profil',
              textStyle: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
          selectedIndex: controller._selectedIndex.value,
          onTabChange: (index) {
            controller._selectedIndex.value = index;
          },
        ),
      ),
    );
  }

  Widget _buildCustomDrawer() {
    return Obx(() {
      if (controller.user.isEmpty) {
        return Drawer(
          child: Center(
            child: CircularProgressIndicator(color: _primaryColor),
          ),
        );
      }

      return Drawer(
        backgroundColor: THelperFunctions.isDarkMode(context)
            ? Colors.grey[900]
            : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(
            right: Radius.circular(20),
          ),
        ),
        child: Column(
          children: [
            // Header du drawer
            Expanded(
              flex: 2,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      _primaryColor.withOpacity(0.9),
                      _secondaryColor.withOpacity(0.7),
                    ],
                  ),
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(20),
                  ),
                ),
                child: DrawerHeaderCustom(
                  displayName: controller.user['fullName'],
                  email: "${controller.user['email']}",
                  photo: controller.user['profilePicture'],
                ),
              ),
            ),

            // Corps du drawer
            Expanded(
              flex: 5,
              child: ListView(
                padding: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                children: [
                  // Section Gestion
                  _buildDrawerSectionHeader("Gestion"),
                  _buildDrawerTile(
                    title: "Tableau de Bord",
                    icon: Icons.dashboard_outlined,
                    color: _infoColor,
                    onTap: () {
                      Get.offAll(() => TabsScreen(initialIndex: 0));
                      _scaffoldKey.currentState?.closeDrawer();
                    },
                  ),
                  _buildDrawerTile(
                    title: "Commandes",
                    icon: Icons.local_shipping_outlined,
                    color: Colors.purple,
                    onTap: () {
                      Get.offAll(() => TabsScreen(initialIndex: 1));
                      _scaffoldKey.currentState?.closeDrawer();
                    },
                  ),
                  _buildDrawerTile(
                    title: "Livreurs",
                    icon: Icons.delivery_dining,
                    color: Colors.orange,
                    onTap: () {
                      Get.offAll(() => DeliverListScreen());
                      _scaffoldKey.currentState?.closeDrawer();
                    },
                  ),
                  _buildDrawerTile(
                    title: "Utilisateurs",
                    icon: Icons.people_outline,
                    color: Colors.teal,
                    onTap: () {
                      Get.offAll(() => UserListScreen());
                      _scaffoldKey.currentState?.closeDrawer();
                    },
                  ),

                  SizedBox(height: 20),

                  // Section Communication
                  _buildDrawerSectionHeader("Communication"),
                  _buildDrawerTile(
                    title: "Messages",
                    icon: Icons.chat_outlined,
                    color: Colors.green,
                    onTap: () {
                      Get.offAll(() => TabsScreen(initialIndex: 2));
                      _scaffoldKey.currentState?.closeDrawer();
                    },
                  ),
                  _buildDrawerTile(
                    title: "Notifications",
                    icon: Icons.notifications_active_outlined,
                    color: Colors.amber,
                    badgeCount: controller.notificationCount.value,
                    onTap: () {
                      Get.offAll(() => NotificationScreen());
                      _scaffoldKey.currentState?.closeDrawer();
                    },
                  ),

                  SizedBox(height: 20),

                  // Section Paramètres
                  _buildDrawerSectionHeader("Paramètres"),
                  _buildDrawerTile(
                    title: "Mon Profil",
                    icon: Icons.person_outline,
                    color: _primaryColor,
                    onTap: () {
                      Get.offAll(() => TabsScreen(initialIndex: 3));
                      _scaffoldKey.currentState?.closeDrawer();
                    },
                  ),
                  _buildDrawerTile(
                    title: "Paramètres",
                    icon: Icons.settings_outlined,
                    color: Colors.grey,
                    onTap: () {
                      Get.to(() => SettingsScreen());
                      _scaffoldKey.currentState?.closeDrawer();
                    },
                  ),

                  SizedBox(height: 30),

                  // Déconnexion
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 15),
                    child: ElevatedButton.icon(
                      onPressed: () => _showLogoutConfirmation(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _errorColor.withOpacity(0.1),
                        foregroundColor: _errorColor,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 15),
                      ),
                      icon: Icon(Icons.logout, size: 20),
                      label: Text(
                        "Se Déconnecter",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    });
  }

  Widget _buildDrawerSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: Colors.grey.shade500,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _buildDrawerTile({
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    int badgeCount = 0,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
        trailing: badgeCount > 0
            ? Container(
                padding: EdgeInsets.all(6),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _errorColor,
                ),
                child: Text(
                  badgeCount > 9 ? '9+' : badgeCount.toString(),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )
            : Icon(
                Icons.chevron_right,
                color: Colors.grey.shade400,
                size: 20,
              ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  Future<void> _showLogoutConfirmation() async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _warningColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.logout, color: _warningColor),
            ),
            SizedBox(width: 12),
            Text(
              "Déconnexion",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Text("Voulez-vous vraiment vous déconnecter ?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Annuler", style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              AuthentificationRepository.instance.logout();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _warningColor,
              foregroundColor: Colors.white,
            ),
            child: Text("Se déconnecter"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        final shouldExit = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Row(
              children: [
                Icon(Icons.exit_to_app, color: _warningColor),
                SizedBox(width: 10),
                Text("Quitter l'application"),
              ],
            ),
            content: Text("Voulez-vous vraiment quitter SmartService Admin ?"),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text("Annuler"),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _warningColor,
                  foregroundColor: Colors.white,
                ),
                child: Text("Quitter"),
              ),
            ],
          ),
        );
        return shouldExit ?? false;
      },
      child: Scaffold(
        key: _scaffoldKey,
        appBar: _buildCustomAppBar(),
        body: Obx(() {
          if (controller.user.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Lottie.asset(
                    'assets/images/success_register.json',
                    height: 100,
                    width: 100,
                  ),
                  SizedBox(height: 20),
                  Text(
                    'Chargement...',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            );
          }

          return AnimatedSwitcher(
            duration: Duration(milliseconds: 300),
            child: controller.screens[controller._selectedIndex.value],
          );
        }),
        bottomNavigationBar: _buildCustomBottomNavBar(),
        drawer: _buildCustomDrawer(),
      ),
    );
  }
}

class TabsScreenController extends GetxController {
  static TabsScreenController get to => Get.find();

  final _selectedIndex = 0.obs;
  final userConnectName = ''.obs;
  final user = <String, dynamic>{}.obs;
  final notificationCount = 0.obs;
  final auth = FirebaseAuth.instance.currentUser!;
  RxBool accountVerified = false.obs;

  @override
  void onInit() {
    super.onInit();
    _getUserInfo();
    _setupNotificationListener();
  }

  void _setupNotificationListener() {
    FirebaseFirestore.instance
        .collection('notifications')
        .where(
          'receiverRef',
          isEqualTo: FirebaseFirestore.instance.collection('users').doc(auth.uid),
        )
        .where('isRead', isEqualTo: false)
        .snapshots()
        .listen((snapshot) {
      notificationCount.value = snapshot.docs.length;
    });
  }

  void _getUserInfo() async {
    final data = await AuthentificationRepository.instance.getUserInfo(auth.uid);
    if (data.isNotEmpty) {
      user.value = data;
      userConnectName.value = data['fullName'];
      List<String> parts = userConnectName.value.trim().split(" ");
      userConnectName.value = parts.length >= 2 ? parts[1] : '';
    }
  }

  List<Widget> get screens => [
        HomeScreen(
          userFullName: user['fullName'],
          userEmail: user['email'],
        ),
        OrdersScreen(),
        ChatListScreen(),
        ProfileScreen(
          userFullName: user['fullName'],
          userEmail: user['email'],
        ),
      ];
}